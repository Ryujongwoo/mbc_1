package com.mbcit.k20250117_1_springBoot_InitBinder;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class ContentValidator implements Validator {

	@Override
	public boolean supports(Class<?> clazz) {
		return ContentVO.class.isAssignableFrom(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {
		ContentVO vo = (ContentVO) target;
		
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "writer", "작성자가 null이거나 비어있습니다.");
		String writer = vo.getWriter();
		if (writer.length() < 3) {
			errors.rejectValue("writer", "작성자는 3글자 이상 입력해야 합니다.");
		}
		
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "content", "내용이 null이거나 비어있습니다.");
	}

}













