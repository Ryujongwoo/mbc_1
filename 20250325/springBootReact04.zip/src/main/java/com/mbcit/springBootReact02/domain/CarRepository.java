package com.mbcit.springBootReact02.domain;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

@RepositoryRestResource
public interface CarRepository extends CrudRepository<Car, Long> {
	
	public List<Car> findByBrand(@Param("brand") String brand);
	public List<Car> findByColor(@Param("color")String color);
	public List<Car> findByYear(int year);
	public List<Car> findByBrandAndModel(String brand, String model);
	public List<Car> findByBrandOrColor(String brand, String color);
	public List<Car> findByBrandOrColorOrderByPrice(String brand, String color);
	@Query("select c from Car c where c.brand = ?1")
	public List<Car> brandEqual(String brand);
	@Query("select c from Car c where c.brand like %?1%")
	public List<Car> brandImport(String brand);
	
}












