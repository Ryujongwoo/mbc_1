package com.mbcit.springBootReact02;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;

import com.mbcit.springBootReact02.service.UserDetailServiceImpl;

//	스프링 시큐리티가 작동하는 방법을 구성하려면 WebSecurityConfigurerAdapter 클래스를 상속받아
//	새 클래스를 추가해야 한다.
//	WebSecurityConfigurerAdapter 클래스는 springBoot 2.7에서 지원이 중단되었다.
//	@Configuration, @EnableWebSecurity 어노테이션으로 이 클래스에서 기본 웹 보안 구성을 비활성화하고
//	자체 구성을 정의할 수 있다.
@Configuration
@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter {

	@Autowired
	private UserDetailServiceImpl userDetailServiceImpl;
	
//	애플리케이션의 보호되는 엔드포인트와 보호되지 않는 엔드포인트 configure(HttpSecurity http)
//	메소드로 정의할 수 있다.
//	모든 엔드포인트를 보호하는 기본 설정을 이용해도 되므로 아직은 이 메소드를 사용하지 않는다.
//	@Override
//	protected void configure(HttpSecurity http) throws Exception {
//		super.configure(http);
//	}

	/*
//	userDetailsService() 메소드를 Override해서 인메모리 사용자를 애플리케이션에 추가할 수 있다.
//	애플리케이션 개발 과정에서는 인메모리 사용자를 이용해도 되지만 실제 애플리케이션에서는
//	사용자를 데이터베이스에 저장해야 한다.
	@Bean
	@Override
	protected UserDetailsService userDetailsService() {
//		withDefaultPasswordEncoder() 메소드는 시연 목적에만 적합하며 실제 운영 단계에서는 안전
//		문제로 적합하지 않다.
		UserDetails user = User.withDefaultPasswordEncoder()
				.username("user") // 사용자 이름
				.password("password") // 비밀 번호
				.roles("USER") // 사용자 권한
				.build();
		return new InMemoryUserDetailsManager(user);
	}
	*/
	
//	인메모리 사용자를 만들어주는 userDetailsService() 메소드를 비활성화하고 데이터베이스에서
//	사용자를 활성화하는 메소드를 추가한다.
	@Autowired
	public void configureGlobal(AuthenticationManagerBuilder auth) throws Exception {
//		암호는 일반 텍스트로 데이터베이스에 저장하면 안되므로 BCryptPasswordEncoder 클래스를 이용하여
//		bcrypt 알고리즘으로 인코딩한다.
		auth.userDetailsService(userDetailServiceImpl).passwordEncoder(new BCryptPasswordEncoder());
	}
	
}

















