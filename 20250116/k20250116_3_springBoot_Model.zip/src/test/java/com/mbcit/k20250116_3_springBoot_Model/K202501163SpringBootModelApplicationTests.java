package com.mbcit.k20250116_3_springBoot_Model;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class K202501163SpringBootModelApplicationTests {

	@Test
	void contextLoads() {
	}

}
