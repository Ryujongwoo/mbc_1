function alertTest() {
//	alert('메시지')
	alert('경고 메시지');
}

function confirmTest() {
//	confirm('질문')
//	확인 버튼을 클릭하면 true가 취소 버튼을 클릭하면 false가 리턴된다.
	let result = confirm('브라우저 배경색을 바꿀래?');
//	console.log(result);

	if (result) { // 확인 버튼이 클릭되었나?
		// 브라우저 배경색과 글자색을 반전시킨다.
		document.body.style.backgroundColor = 'black';
		document.body.style.color = 'white';
	}
}

function promptTest() {
//	prompt('메시지')
//	prompt('메시지', '안내 메시지')
//	확인 버튼을 클릭하면 입력한 문자열을 취소 버튼을 클릭하면 null을 리턴한다.
	let menu = prompt('점심은 뭘 먹을까요?\n(1.짜장면, 2.양장피, 3.팔보채)', '나는 짜장면');
//	console.log(menu);

	if (menu) {
		switch (menu) {
			case '1':
				console.log('짜장면');
				break;
			case '2':
				console.log('양장피');
				break;
			case '3':
				console.log('팔보채');
				break;
			default:
				alert('짜장면, 양장피, 팔보채 중에서 선택하세요.');
				break;
		}
	} else {
		alert('점심 메뉴를 선택하세요');
	}
}

