package com.mbcit.k20250117_3_springBoot_JdbcTemplate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class K202501173SpringBootJdbcTemplateApplication {

	public static void main(String[] args) {
		SpringApplication.run(K202501173SpringBootJdbcTemplateApplication.class, args);
	}

}
