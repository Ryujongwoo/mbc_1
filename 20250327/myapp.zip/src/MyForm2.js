import React, { useState } from "react";

function MyForm2() {
  // useState hook로 text라는 상태를 만든다.
  const [text, setText] = useState('');

  const submitHandler = event => {
    event.preventDefault();
    alert(`입력한 값: ${text}`);
  }

  // 텍스트 상자의 내용이 변경(onChange 이벤트가 실행)되면 변경된 값으로 text 상태를 수정한다.
  const inputChanged = event => {
    // console.log('onChange 이벤트가 실행됨');
    // console.log(event);
    // console.log(event.target);
    // console.log(event.target.value);
    setText(event.target.value);
  }

  return (
    <div align='center'>
      <h1>MyForm2</h1>
      {/* 입력 필드와 전송 버튼을 하나씩 포함하는 간단한 폼을 만든다. */}
      {/* 이 폼의 데이터를 리액트가 처리하므로 이러한 컴포넌트를 제어되는 컴포넌트라 한다. */}
      <form onSubmit={submitHandler}>
        {/* 입력 필드의 값을 얻으려면 onChange 이벤트를 이용한다. */}
        <input type="text" onChange={inputChanged} value={text} placeholder="이름"/>
        <input type="submit" value="눌러봐" />
      </form>
    </div>
  );
}

export default MyForm2;
