import React from 'react';
import './App.css';

const divStyle = {
  backgroundColor: 'dodgerblue', 
  height: 200, 
  width: 500
};

function App() {
  return (
    // <div className='App' style={{ backgroundColor: 'tomato', height: 200, width: 500 }}>
    <div className='App' style={divStyle}>
      Hello World
    </div>
  );
}

export default App;

