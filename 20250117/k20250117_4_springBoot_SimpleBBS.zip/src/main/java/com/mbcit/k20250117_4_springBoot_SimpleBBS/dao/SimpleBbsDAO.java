package com.mbcit.k20250117_4_springBoot_SimpleBBS.dao;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.stereotype.Repository;

import com.mbcit.k20250117_4_springBoot_SimpleBBS.vo.SimpleBbsVO;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Repository
public class SimpleBbsDAO implements ISimpleBbsDAO {

	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	@Override
	public void insert(SimpleBbsVO simpleBbsVO) {
		log.info("SimpleBbsDAO 클래스의 insert() 메소드 실행");
		String sql = "insert into simplebbs (idx, name, title, content) " + 
				"values (simplebbs_idx_seq.nextval, ?, ?, ?)";
		jdbcTemplate.update(sql, new PreparedStatementSetter() {
			@Override
			public void setValues(PreparedStatement ps) throws SQLException {
				ps.setString(1, simpleBbsVO.getName());
				ps.setString(2, simpleBbsVO.getTitle());
				ps.setString(3, simpleBbsVO.getContent());
			}
		});
	}

	@Override
	public List<SimpleBbsVO> selectList() {
		log.info("SimpleBbsDAO 클래스의 selectList() 메소드 실행");
		String sql = "select * from simplebbs order by idx desc";
		List<SimpleBbsVO> list = jdbcTemplate.query(sql, new BeanPropertyRowMapper(SimpleBbsVO.class));
//		log.info("list: {}", list);
		return list;
	}

	@Override
	public SimpleBbsVO select(int idx) {
		log.info("SimpleBbsDAO 클래스의 select() 메소드 실행");
		String sql = "select * from simplebbs where idx = " + idx;
//		SimpleBbsVO vo = (SimpleBbsVO) jdbcTemplate.queryForObject(sql, new BeanPropertyRowMapper(SimpleBbsVO.class));
		SimpleBbsVO vo = jdbcTemplate.queryForObject(sql, new BeanPropertyRowMapper<SimpleBbsVO>(SimpleBbsVO.class));
//		log.info("vo: {}", vo);
		return vo;
	}

	@Override
	public void update(SimpleBbsVO simpleBbsVO) {
		log.info("SimpleBbsDAO 클래스의 update() 메소드 실행");
		String sql = "update simplebbs set title = ?, content = ? where idx = ?";
		jdbcTemplate.update(sql, new PreparedStatementSetter() {
			@Override
			public void setValues(PreparedStatement ps) throws SQLException {
				ps.setString(1, simpleBbsVO.getTitle());
				ps.setString(2, simpleBbsVO.getContent());
				ps.setInt(3, simpleBbsVO.getIdx());
			}
		});
	}

	@Override
	public void delete(int idx) {
		log.info("SimpleBbsDAO 클래스의 delete() 메소드 실행");
		String sql = "delete from simplebbs where idx = " + idx;
		jdbcTemplate.update(sql);
	}

}










