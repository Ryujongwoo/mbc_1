//	인수로 넘겨받은 시간이 경과된 후 넘겨받은 시간을 리턴하는 Promise를 리턴하는 함수
/*
function timer(time) {
	return new Promise(function (resolve, reject) {
		setTimeout(function () {
			resolve(time);
		}, time);
	});
}

timer(2000)
	.then(function (time) {
		console.log(time);
	});
*/

function timer(time) {
	return new Promise((resolve, reject) => setTimeout(() => resolve(time), time));
}

timer(2000).then(time => console.log('1. time:', time));

//	1. ==================================================================================

//	timer() 실행 전에 start, 실행 후에 end를 표시한다.
console.log('2. start');
timer(1000)
	.then(function (time) {
		console.log('2. time 1:', time);
		return timer(time + 1000);
	})
	.then(function (time) {
		console.log('2. time 2:', time);
		return timer(time + 1000);
	})
	.then(function (time) {
		console.log('2. time 3:', time);
		console.log('2. end'); // 여기에 코딩해야 모두 완료된 후 출력된다.
	})

//	2. ==================================================================================

//	위에서 실행한 것과 동일한 결과를 가지게끔 async와 await를 사용하는 함수로 수정
async function run() {
	console.log('3. start');
	let time = await timer(1000);
	console.log('3. time 1:', time);
	time = await timer(time + 1000);
	console.log('3. time 2:', time);
	time = await timer(time + 1000);
	console.log('3. time 3:', time);
	console.log('3. end');
	return '꺄~~~~~~~~~~';
}

run()
	.then(function (value) {
		console.log('3. value:', value);
	});

