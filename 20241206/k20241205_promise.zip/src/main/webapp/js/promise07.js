//	jsonplaceholder를 검색
//	https://jsonplaceholder.typicode.com/ 아래쪽으로 이동하면 /posts 클릭
//	https://jsonplaceholder.typicode.com/posts

//	javascript fetch API 검색
//	https://developer.mozilla.org/ko/docs/Web/API/Fetch_API

//	fetch()의 리턴 값은 Promise 이다. => then(), catch()로 결과를 받아서 처리한다.

console.log('1. ==============================================================================');
fetch('https://jsonplaceholder.typicode.com/posts')
//	then()이 사용가능하다는 것은 fetch() 실행 후 리턴 값이 Promise라는 의미이다.
	.then(function (response) {
		// console.log(response);
		// console.log(response.json()); // json 타입의 데이터를 javascript 객체로 변환한다.
		return response.json();
	})
	.then(function (data) {
		// console.log(typeof data);
		console.log('1. data: ' + JSON.stringify(data));
	});
console.log('1. ==============================================================================');

//	===============================================================================================

//	fetch(url) 함수의 리턴 값은 Promise이며 response(응답) 객체이다.
let fetched = fetch('https://jsonplaceholder.typicode.com/posts');

console.log('2. ' + fetched); // 2. [object Promise]
console.log('2. ', fetched); // 2. Promise {<pending>}

//	fetch() 함수의 리턴 값은 Promise 객체이므로 then()과 catch() 함수를 사용할 수 있다.
//	then() 함수는 fetch() 함수가 성공적으로 실행되면 호출되고 catch() 함수는 fetch() 함수가 정상적으로
//	실행되지 않으면 호출된다.
//	fetch()가 실행되면 Promise가 리턴되고 then() 함수도 실행되면 Promise를 리턴한다.

fetched
	.then(function (response) {
		console.log('2.', response); // 2. Response {type: 'cors', url: ~~~~~
	})

fetched = fetch('https://jsonplaceholder1.typicode.com/posts'); // 주소 틀림
fetched
	.catch(function (error) {
		console.log('2.', error); // 2. TypeError: Failed to fetch
	})

//	===============================================================================================

fetch('https://jsonplaceholder.typicode.com/posts')
	.then(function (response) {
		console.log('3.', response);
		// then() 함수 내부에 또 then() 함수가 나오는 방식을 nested 방식이라 한다.
		/*
		response.json()
			.then(function (data) {
				console.log('3.', data);
			})
		*/
		return response.json(); // Promise가 리턴된다.
	})
	.then(function (data) {
		// then() 함수에서 Promise를 리턴시키고 외부 then() 함수로 받아 사용하는 방식을 chaining 방식이라
		// 하고 nested 방식보다 더 많이 사용한다.
		console.log('3.', data);
	})
	.catch(function (error) {
		console.log('3.', error);
	});

