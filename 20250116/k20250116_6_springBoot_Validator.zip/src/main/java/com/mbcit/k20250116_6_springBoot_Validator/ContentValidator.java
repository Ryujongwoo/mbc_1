package com.mbcit.k20250116_6_springBoot_Validator;

import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import lombok.extern.slf4j.Slf4j;

//	유효성 검사를 하기 위해서 Validator 인터페이스를 구현받는다.
//	Validator 인터페이스를 구현받으면 supports() 메소드와 validate() 메소드를 반드시 override 해서
//	사용해야 한다.
@Slf4j
public class ContentValidator implements Validator {

//	유효성을 검사할 객체(커맨드 객체)의 클래스 타입 정보를 리턴한다.
	@Override
	public boolean supports(Class<?> clazz) {
		return ContentVO.class.isAssignableFrom(clazz);
	}

//	유효성을 검사하는 메소드
	@Override
	public void validate(Object target, Errors errors) {
//		어떤 커맨드 객체가 validate() 메소드로 넘어올지 모르기 때문에 Object 타입으로 선언된 객체로
//		커맨드 객체를 받아서 형변환 시켜 사용한다.
		ContentVO vo = (ContentVO) target;
		
//		writer 유효성 검사
		String writer = vo.getWriter();
		if (writer == null || writer.trim().length() == 0) {
			log.info("작성자가 null이거나 비어있습니다.");
			errors.rejectValue("writer", "writer 오류");
		}
		
//		content 유효성 검사
		String content = vo.getContent();
		if (content == null || content.trim().isEmpty()) {
			log.info("내용이 null이거나 비어있습니다.");
			errors.rejectValue("content", "content 오류");
		}
	}

}













