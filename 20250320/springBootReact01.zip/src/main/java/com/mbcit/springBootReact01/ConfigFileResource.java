package com.mbcit.springBootReact01;

import java.io.File;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ConfigFileResource {

	@Bean
	public File configFile() {
		File file = new File("configFIle.xml");
		return file;
	}
	
}
