import React from "react";
import AuthContext from "./AuthContext";
import UserComponent from "./UserComponent";

function Context() {
  const userName = '임꺽정';

  return (
    <div align="center">
      <h1>Context</h1>
      {/*
        컨텍스트 공급자 컴포넌트(AuthContext)에는 이를 소비하는 컴포넌트(UserComponent)로
        전달되는 value prop이 있다.
      */}
      <AuthContext.Provider value={userName}>
        <UserComponent />
      </AuthContext.Provider>
    </div> 
  );
}

export default Context;
