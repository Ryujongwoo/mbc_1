package com.mbcit.k20250117_1_springBoot_InitBinder;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import lombok.Data;

@Data
public class ContentVO {

//	유효성을 검사할 데이터를 받는 커맨드 객체에 유효성을 검사하는 어노테이션을 추가한다.
	
	private int id;
	
	@NotNull(message = "작성자가 null 입니다.")
	@NotEmpty(message = "작성자가 공백 입니다.")
	@Size(min = 3, max = 10, message = "작성자는 3글자 이상 10글자 이하로 입력해야 합니다.")
	private String writer;
	
	@NotNull(message = "내용이 null 입니다.")
	@NotEmpty(message = "내용이 공백 입니다.")
	private String content;
	
}
