package com.mbcit.k20250115_3_springBoot_AnnotationDI.bean;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class MyController {

	@Autowired
	private Member member1;
	
	@Autowired
	private Member member2;
	
	@RequestMapping("/")
//	@ResponseBody 어노테이션은 html 태그 없이 순수하게 스트링 데이터만으로 응답할 경우 사용한다.
	public @ResponseBody String root() {
//		member1 bean 가져오기 확인
		member1.print();
		
//		member2 bean 가져오기 확인
		member2.print();
		
		return "Annotation 사용하기";
	}
	
}
