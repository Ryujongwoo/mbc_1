package com.mbcit.k20250116_6_springBoot_Validator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class K202501166SpringBootValidatorApplication {

	public static void main(String[] args) {
		SpringApplication.run(K202501166SpringBootValidatorApplication.class, args);
	}

}
