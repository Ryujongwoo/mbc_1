package com.mbcit.k20250117_3_springBoot_JdbcTemplate;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

//	@Component, @Service, @Repository 어노테이션은 스테레오 타입(stereotype)의 일종이다.
//	스테레오 타입이라는 것은 bean을 등록하고 사용할 때 개발자가 내부적으로 의미를 파악하기 쉽게 하기 위해서
//	사용하는 별칭이라 보면 된다.
//	스테레오 타입의 어노테이션을 붙여서 선언한 클래스는 springBoot 서버가 실행될 때 자동으로 bean이 생성된다.
//	@Component: 일반 클래스의 bean을 자동으로 생성할 때 붙여준다.
//	@Service: 서비스 클래스의 bean을 자동으로 생성할 때 붙여준다.
//	@Repository: 데이터베이스 처리와 관련된 용도로 사용하는 클래스의 bean을 자동으로 생성할 때 붙여준다.
@Repository
public class MyUserDAO {

//	JdbcTemplate 클래스 객체에는 application.properties 파일에서 설정한 데이터베이스 연결 정보를 바탕으로
//	오라클 드라이버를 로드하고 데이터베이스에 접속한 후 커넥션 풀까지 생성된 정보가 자동으로 들어온다.
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	public List<MyUserVO> list() {
		String sql = "select * from myuser";
		List<MyUserVO> list = jdbcTemplate.query(sql, new BeanPropertyRowMapper(MyUserVO.class));
		return list;
	}
	
}
