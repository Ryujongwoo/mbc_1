package com.mbcit.springBootReact02.domain;

//	JWT 인증을 위한 자격 증명을 저장하는 클래스를 만든다.
//	자격 증명을 데이터베이스에 저장하지는 않으므로 @Entity 어노테이션을 지정하지 않는다.
public class AccountCredentials {

	private String username;
	private String password;
	
	public AccountCredentials() { }
	public AccountCredentials(String username, String password) {
		this.username = username;
		this.password = password;
	}
	
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	@Override
	public String toString() {
		return "AccountCredentials [username=" + username + ", password=" + password + "]";
	}
	
}
