package com.mbcit.k20250121_1_springBoot_JPA01.domain;

import java.time.LocalDateTime;

import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;

public class MyEntityListener {

	@PrePersist
	public void prePersist(Object object) {
		System.out.println("MyEntityListener 리스너의 prePersist() 메소드 실행됨");
		if (object instanceof Auditable) {
			((Auditable) object).setCreateDate(LocalDateTime.now());
			((Auditable) object).setUpdateDate(LocalDateTime.now());
		}
	}
	
	@PreUpdate
	public void preUpdate(Object object) {
		System.out.println("MyEntityListener 리스너의 preUpdate() 메소드 실행됨");
		if (object instanceof Auditable) {
			((Auditable) object).setUpdateDate(LocalDateTime.now());
		}
	}

}









