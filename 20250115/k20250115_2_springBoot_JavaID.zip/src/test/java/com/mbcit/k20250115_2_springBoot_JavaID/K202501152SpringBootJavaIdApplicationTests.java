package com.mbcit.k20250115_2_springBoot_JavaID;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class K202501152SpringBootJavaIdApplicationTests {

	@Test
	void contextLoads() {
	}

}
