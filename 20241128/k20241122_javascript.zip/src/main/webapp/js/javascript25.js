function intTest(value) {
	console.log(value);
	console.log(typeof value);
	console.log(value + 100);
	console.log(parseInt(value) + 100);
}

function floatTest(value) {
	console.log(value);
	console.log(typeof value);
	console.log(value + 100);
	console.log(parseFloat(value) + 100);
}

function numTest(value) {
//	let num = document.getElementById('num').value;
//	let num = document.querySelector('#num').value;
//	console.log(num);

	console.log(value);
	console.log(typeof value); // string
	
	console.log('123' + value); // string + string => 문자열 연결
	console.log(123 + value); // number + string => 문자열 연결
	console.log(value + 123); // string + number => 문자열 연결
	console.log(100 + 123); // string + number => 덧셈
	
//	덧셈을 제외한 나머지 산술 연산은 문자열과 숫자를 연산해도 결과가 숫자로 리턴된다.
	console.log(value - 5);
	console.log(value * 5);
	console.log(value / 5);
	console.log(value % 5);
	console.log(value ** 5);

//	자바스크립트는 문자열과 문자열, 문자열과 숫자, 숫자와 문자열의 덧셈은 무조건 문자열로 처리되므로
//	덧셈을 하기 위해서는 숫자로 변환한 후 연산을 해야한다.
//	Number() 함수는 인수로 지정된 문자열을 숫자로 바꿔준다. => 정수, 실수를 구분하지 않는다.
	console.log(Number('123') + Number(value));
	console.log(Number('3.14') + Number(value));
	
//	'123a'와 같이 인수로 지정된 문자열에 숫자로 변환할 수 없는 문자가 있는 경우 parseInt() 함수나
//	parseFloat() 함수는 변환 시킬 수 있는데 까지 변환을 하지만 Number() 함수는 숫자로 변환할 수 없는
//	문자열이 있수에 포함되면 NaN을 리턴한다.
	console.log(Number('123a') + Number(value));
	console.log(Number('3.14a') + Number(value));
}

