package com.mbcit.k20250121_1_springBoot_JPA01.domain;

import java.time.LocalDateTime;

import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.ToString;

@NoArgsConstructor
@Data
@Entity
//	@EntityListeners 어노테이션으로 사용할 엔티티 리스너를 2개 이상 지정하려면 {}로 묶어준다.
//	@EntityListeners(value = {MyEntityListener.class})
//	기본 리스너가 동작되게 하려면 @EntityListeners 어노테이션에 AuditingEntityListener를 지정한다.
//	@EntityListeners(value = {AuditingEntityListener.class})
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class MemberHistory extends BaseEntity /* implements Auditable */ {

	@Id
	@GeneratedValue
	private Long id;
	private Long memberId; // 내용이 입력 또는 수정된 Member 엔티티의 id
	private String name;
	private String email;
//	@CreatedDate
//	private LocalDateTime createDate;
//	@LastModifiedDate
//	private LocalDateTime updateDate;

}










