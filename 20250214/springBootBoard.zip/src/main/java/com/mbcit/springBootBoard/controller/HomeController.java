package com.mbcit.springBootBoard.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller // 이 클래스는 컨트롤러임을 나타낸다.
public class HomeController {

//	브라우저에 "/"라는 요청이 들어오면 home() 메소드가 실행된다.
	@RequestMapping("/")
	public @ResponseBody String home() {
		return "springBoot를 이용한 간단 게시판";
	}
	
//	브라우저에 "/hello"라는 요청이 들어오면 hello() 메소드가 실행된다.
//	@RequestMapping("/hello")
	@GetMapping("/hello")
//	viewpage로 데이터를 넘길 때 Model 인터페이스 객체를 사용한다.
	public String hello(Model model) {
//		Model 인터페이스 객체에 addAttribute() 메소드로 viewpage로 전달할 데이터를 넣어준다.
		model.addAttribute("username", "홍길동");
		return "greetings"; // viewpage 이름
	}
	
	@GetMapping("/bye")
	public String bye(Model model) {
		model.addAttribute("nickname", "임꺽정");
		return "goodbye";
	}
	
}














