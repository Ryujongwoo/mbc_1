package com.mbcit.k20250116_5_springBoot_Lombok;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class K202501165SpringBootLombokApplicationTests {

	@Test
	void contextLoads() {
	}

}
