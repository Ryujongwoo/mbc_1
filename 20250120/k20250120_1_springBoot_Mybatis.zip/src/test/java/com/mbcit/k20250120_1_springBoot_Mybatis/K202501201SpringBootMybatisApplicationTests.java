package com.mbcit.k20250120_1_springBoot_Mybatis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class K202501201SpringBootMybatisApplicationTests {

	@Test
	void contextLoads() {
	}

}
