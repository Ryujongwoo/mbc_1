package com.mbcit.k20250120_1_springBoot_Mybatis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class K202501201SpringBootMybatisApplication {

	public static void main(String[] args) {
		SpringApplication.run(K202501201SpringBootMybatisApplication.class, args);
	}

}
