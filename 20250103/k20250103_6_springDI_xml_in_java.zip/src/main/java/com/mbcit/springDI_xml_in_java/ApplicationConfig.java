package com.mbcit.springDI_xml_in_java;

import java.util.ArrayList;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

//	@Configuration
public class ApplicationConfig {

	@Bean
	public Student student2() {
		ArrayList<String> hobbies = new ArrayList<String>();
		hobbies.add("볼링");
		hobbies.add("골프");
		hobbies.add("당구");
		Student student = new Student("임꺽정", 35, hobbies);
		student.setHeight(185);
		student.setWeight(85);
		return student;
	}
	
}













