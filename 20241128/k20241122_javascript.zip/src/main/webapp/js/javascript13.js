//	falsy: 조건을 비교하지 않아도 무조건 거짓이 되는 값 => false, 0, null, undefined, NaN, ''
//	truthy: 조건을 비교하지 않아도 무조건 참이 되는 값 => falsy를 제외한 나머지

//	단축 평가 논리 계산법
//	'&&' 논리 연산에서 앞의 조건이 truthy한 값이면 '&&' 뒤의 내용이 출력된다.
console.log(true && 'hello');
//	'&&' 논리 연산에서 앞의 조건이 falsy한 값이면 falsy한 값이 출력된다.
console.log(false && 'hello');
console.log(0 && 'hello');
console.log(null && 'hello');
console.log(undefined && 'hello');
console.log(NaN && 'hello');
console.log('' && 'hello');
console.log('1. =================================');

const dog = {
	name: '멍멍이'
}

function getName(animal) {
//	console.log(animal);
	if (animal) {
		return animal.name;
	}
	return undefined;
}

console.log(getName(dog));
console.log(getName());

function getName2(animal) {
	return animal && animal.name;
}

console.log(getName2(dog));
console.log(getName2());
console.log('2. =================================');

//	'||' 논리 연산에서 앞의 조건이 truthy한 값이면 '||' 앞의 내용이 출력된다.
console.log(true || 'hello');
//	'||' 논리 연산에서 앞의 조건이 falsy한 값이면 '||' 뒤의 내용이 출력된다.
console.log(false || 'hello');
console.log(0 || 'hello');
console.log(null || 'hello');
console.log(undefined || 'hello');
console.log(NaN || 'hello');
console.log('' || 'hello');
console.log('3. =================================');

function getName3(animal) {
	return animal || animal.name;
}

console.log(getName3(dog)); // 인수로 넘겨준 객체가 출력된다.
console.log(getName3()); // 에러
console.log('4. =================================');

