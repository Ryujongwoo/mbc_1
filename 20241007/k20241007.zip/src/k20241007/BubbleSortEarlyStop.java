package k20241007;

import java.util.Arrays;

public class BubbleSortEarlyStop {

	public static void main(String[] args) {
		
//		int[] data = {8, 3, 4, 9, 1};
		int[] data = {9, 1, 3, 4, 8};
		
		for (int i = 0; i < data.length - 1; i++) {
			
//			정렬 작업이 조기 종료되었나 판단할 변수를 true로 초기화한다.
			boolean isFlag = true;
			
			for (int j = 0; j < data.length - 1 - i; j++) {
				if (data[j] > data[j + 1]) {
					int temp = data[j];
					data[j] = data[j + 1];
					data[j + 1] = temp;
					
//					값 교환(정렬 작업)이 이루어지면 조기 종료되었나 판단할 변수 값을 false로 변경한다.
					isFlag = false;
				}
			}
			
//			정렬이 완료된 데이터는 값 교환 작업이 이루어지지 않기때문에 isFlag 변수는 true가 유지된다.
			if (isFlag) {
//				정렬이 완료된 상태라면 더 이상 회전할 필요 없으므로 i반복을 탈출한다.
				break;
			}
			
			System.out.println(i + 1 + "회전 결과: " + Arrays.toString(data));
			
		}
		
		System.out.println("정렬 결과: " + Arrays.toString(data));
		
	}
	
}









