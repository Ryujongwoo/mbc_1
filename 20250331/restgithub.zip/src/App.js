import { useState } from 'react';
import './App.css';

// AG Gird(https://www.ag-grid.com/)는 리액트 앱의 유연한 표 컴포넌트이며 필터링, 정렬,
// 피벗과 같은 여러 유용한 기능을 제공한다.
// ag-grid 컴포넌트와 스타일 시트를 가져온다.
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-material.css';

function App() {
  // 사용자가 입력 필드에 키워드를 입력하고 검색 버튼을 누르면 REST API 호출을 수행한다.
  // 이를 위해 사용자 입력에 대한 상태와 JSON 응답에 대한 상태가 필요하다.
  const [keyword, setKeyword] = useState(''); // 사용자 입력에 대한 상태
  // 리포지터리 응답에서 JSON 배열로 리턴되므로 data 상태의 타입은 배열이다.
  const [data, setData] = useState([]); // JSON 응답에 대한 상태

  // 입력 필드에서 onChange 이벤트가 발생되면 실행할 함수를 정의한다.
  const inputKeyword = event => setKeyword(event.target.value);
  // REST API 호출을 수행하는 함수
  const fetchData = function () {
    fetch(`https://api.github.com/search/repositories?q=${keyword}`)
      .then(response => response.json())
      .then(data => setData(data.items))
      .catch(error => console.log(error))
  }

  // ag-grid의 열을 정의해야 한다. 열 객체에서는 field prop으로 데이터 접근자를 정의한다.
  // 응답 데이터에 owner 객체가 포함되어 있으며 owner.필드이름으로 값에 접근할 수 있다.
  // 정렬과 필터링은 기본값으로 비활성화된 상태지만 sortable, filter prop으로 활성화 할 수 있다.
  const columns = [
    { field: 'full_name', sortable: true, filter: true },
    { field: 'html_url', sortable: true, filter: true },
    { field: 'owner.login', sortable: true, filter: true },
    // 버튼을 렌더링 한다.
    {
      field: 'html_url',
      cellRenderer: function (params) {
        return (
          <button type='button' onClick={
            function () {
              alert(params.value);
              window.location.href=params.value;
            }
          }>Press Me</button>
        )
      },
      headerName: '눌러봐'
    }
  ];

  return (
    <div className="App">
      {/* 입력 필드와 버튼을 만든다. */}
      <input type='text' value={keyword} onChange={inputKeyword}/>
      <button type='button' onClick={fetchData}>Github Fetch</button>
      {/* github API의 응답 결과를 출력한다. */}
      {/*
      <table>
        <tbody>
          {
            data.map(repo => 
              <tr>
                <td>{repo.full_name}</td>
                <td>
                  <a href={repo.html_url}>{repo.html_url}</a>
                </td>
              </tr>
            )
          }
        </tbody>
      </table>
      */}

      {/* ad-grid 컴포넌트는 스타일을 정의하는 div 요소 안에 포함해야 한다. */}
      <div className='ag-theme-material' style={{height: 500, width: '90%'}}>
        {/* AgGridReact 컴포넌트를 return 문에 추가한다. */}
        <AgGridReact
          // ag-grid 컴포넌트를 데이터로 채우려면 rowData prop으로 컴포넌트에 전달해야 한다.
          rowData={data} 
          // ag-grid의 columnDefs prop으로 열을 정의한다.
          columnDefs={columns} 
          // ag-grid의 pagination prop으로 페이지 매김을 활성화 한다.
          pagination={true} 
          // ag-grid의 paginationPageSize prop으로 페이지 크기를 설정한다.
          paginationPageSize={8}
        />
      </div>

    </div>
  );
}

export default App;
