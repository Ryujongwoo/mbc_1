package com.mbcit.springBootBoard.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.mbcit.springBootBoard.dto.ArticleForm;
import com.mbcit.springBootBoard.dto.CommentDto;
import com.mbcit.springBootBoard.entity.Article;
import com.mbcit.springBootBoard.repository.ArticleRepository;
import com.mbcit.springBootBoard.service.CommentService;

import lombok.extern.slf4j.Slf4j;

@Controller
@Slf4j
public class ArticleController {

//	article 테이블에 JPA를 이용해서 sql 명령을 실행해야 하므로 ArticleRepository 인터페이스 객체를
//	선언하고 @Autowired 어노테이션을 이용해서 초기화 한다.
//	@Autowired 어노테이션은 springBoot가 미리 생성해놓은 bean(객체)을 가져다 자동으로 초기화 시킨다.
	@Autowired
	private ArticleRepository articleRepository;
	
//	답변글 목록을 가져오기 위해 CommentService 클래스의 bean을 얻어온다.
	@Autowired
	private CommentService commentService;
	
//	데이터를 입력하는 폼을 띄우는 요청
	@GetMapping("/articles/new")
	public String newArticleForm() {
//		@Slf4j 어노테이션 로그 레벨, 로그는 반드시 문자열로 지정한다.
//		log.trace("가장 디테일한 로그");
//		log.warn("경고 로그");
//		log.info("정보성 로그");
//		log.debug("디버깅용 로그");
//		log.error("에러 로그");
		log.info("ArticleController의 newArticleForm() 메소드 실행");
		return "articles/new";
	}
	
//	폼에 입력한 데이터를 테이블에 저장하는 요청
	@PostMapping("/articles/create")
//	form에서 넘어오는 데이터는 커맨드 객체로 받으면 편리하다.
	public String createArticle(/* HttpServletRequest request, */ArticleForm articleForm, Model model) {
		log.info("ArticleController의 createArticle() 메소드 실행");
//		log.info("title: " + request.getParameter("title"));
//		log.info("content: " + request.getParameter("content"));
//		model.addAttribute("title", request.getParameter("title"));
//		model.addAttribute("content", request.getParameter("content"));
//		log.info("articleForm: " + articleForm);
//		log.info("articleRepository: " + articleRepository);
		
//		new.mustache의 form에 입력한 데이터를 넘겨받은 커맨드 객체(ArticleForm)의 데이터를 테이블(article)에
//		저장해야 하므로 Article 엔티티로 변환한다.
		Article article = articleForm.toEntity();
//		log.info("article: " + article);
		
//		ArticleRepository 인터페이스 객체에서 article 테이블에 데이터를 저장하기 위해서 save() 메소드를
//		실행한다.
//		save() 메소드는 id에 저장된 데이터가 null이면 insert sql 명령을 실행하고 null이 아니면 update sql
//		명령을 실행한다.
//		save() 메소드는 insert나 update sql 명령 실행 결과를 리턴한다.
		Article saved = articleRepository.save(article);
//		log.info("saved: " + saved);
		
//		return "goodbye";
//		return "articles/new";
		
//		글이 테이블에 저장되면 전체 글목록을 얻어오는 @GetMapping("/articles") 어노테이션이 지정된
//		메소드를 호출한다.
//		return "redirect:/articles";
		
//		글이 테이블에 저장되면 저장된 글 1건을 얻어오는 @GetMapping("/articles/{id}") 어노테이션이
//		지정된 메소드를 호출한다.
		return "redirect:/articles/" + saved.getId();
	}
	
//	테이블에 저장된 전체 글 목록을 얻어오는 요청
	@GetMapping("/articles")
	public String index(Model model) {
		log.info("ArticleController의 index() 메소드 실행");
		
//		findAll() 메소드로 테이블에 저장된 전체 글목록을 얻어온다. => id의 오름차순
//		List<Article> articleList = articleRepository.findAll();
//		findAllByOrderByIdDesc() 메소드로 테이블에 저장된 전체 글목록을 얻어온다. => id의 내림차순
		List<Article> articleList = articleRepository.findAllByOrderByIdDesc();
//		log.info("articleList: " + articleList);
//		articleList.forEach(System.out::println);
		
//		질문글 줄바꿈 처리를 한다.
		for (Article article : articleList) {
			article.setContent(article.getContent().replace("\r\n", "<br/>"));
		}
		
//		테이블에서 얻어온 데이터를 viewpage로 넘겨주기 위해서 Model 인터페이스 객체에 저장한다.
		model.addAttribute("articleList", articleList);
		
		return "/articles/index";
	}
	
//	테이블에 저장된 글 1건을 얻어오는 요청
//	브라우저에 "/articles/글번호(id)" 형태의 요청을 받아서 처리한다.
//	{}의 의미는 /articles/1, /articles/2, ...와 같이 변화되는 데이터를 변수에 받겠다는 의미이다.
	@GetMapping("/articles/{id}")
//	@PathVariable 어노테이션을 붙여서 요청 경로에 {}를 통해서 받는 데이터를 저장할 변수를 선언한다.
	public String show(@PathVariable Long id, Model model) {
		log.info("ArticleController의 show() 메소드 실행");
//		log.info("id: " + id);
		
//		findById() 메소드로 테이블에 저장된 질문글을 얻어온다.
		Article article = articleRepository.findById(id).orElse(null);
//		log.info("article: " + article);
		
//		질문글 줄바꿈 처리를 한다.
		article.setContent(article.getContent().replace("\r\n", "<br/>"));
		
//		article 테이블에서 얻어온 질문글 목록을 viewpage로 넘겨주기 위해서 Model 인터페이스 객체에 저장한다.
		model.addAttribute("article", article);
		
//		답변글 목록을 얻어온다.
		List<CommentDto> comments = commentService.comments(id);
//		log.info("comments: " + comments);
//		comment 테이블에서 얻어온 답변글 목록을 viewpage로 넘겨주기 위해서 Model 인터페이스 객체에 저장한다.
		model.addAttribute("comments", comments);
		
		return "/articles/show";
	}
	
//	수정할 글을 얻어와서 글을 수정하는 폼을 띄우는 요청
	@GetMapping("/articles/{id}/edit")
	public String edit(@PathVariable Long id, Model model) {
		log.info("ArticleController의 edit() 메소드 실행");
//		log.info("id: " + id);
		
//		findById() 메소드로 수정할 글을 얻어온다.
		Article article = articleRepository.findById(id).orElse(null);
//		테이블에서 얻어온 데이터를 viewpage로 넘겨주기 위해서 Model 인터페이스 객체에 저장한다.
		model.addAttribute("article", article);
		
		return "/articles/edit";
	}
	
//	글을 수정하는 요청
	@PostMapping("/articles/update")
	public String update(ArticleForm articleForm) {
		log.info("ArticleController의 update() 메소드 실행");
		
//		수정할 데이터가 저장된 커맨드 객체의 데이터를 엔티티로 변환한다.
		Article article = articleForm.toEntity();
//		log.info("article: " + article);
		
//		article 테이블에 저장된 수정할 데이터를 얻어와서 수정할 데이터가 존재하면 커맨드 객체를
//		엔티티로 변환환 객체를 article 테이블에 다시 저장한다.
//		엔티티 객체의 id 필드에 저장된 값이 null이면 insert sql 명령이 실행되고 null이 아니면
//		update sql 명령이 실행된다.
		Article target = articleRepository.findById(article.getId()).orElse(null);
		if (target != null) {
			Article saved = articleRepository.save(article);
//			log.info("saved: " + saved);
		}
		
//		return "redirect:/articles";
		return "redirect:/articles/" + article.getId();
	}
	
//	글을 삭제하는 요청
	@GetMapping("/articles/{id}/delete")
//	RedirectAttributes 인터페이스 객체는 viewpage로 1회성 메시지를 전달할 때 사용한다.
	public String delete(@PathVariable Long id, RedirectAttributes redirectAttributes) {
		log.info("ArticleController의 delete() 메소드 실행");
//		log.info("id: " + id);

//		article 테이블에 저장된 삭제할 데이터를 얻어와서 삭제할 데이터가 존재하면 삭제한다.
		Article target = articleRepository.findById(id).orElse(null);
		if (target != null) {
//			delete() 메소드로 테이블에 저장된 데이터를 삭제한다.
//			delete() 메소드의 인수는 삭제할 데이터가 저장된 엔티티 객체를 넘겨줘야 한다.
			articleRepository.delete(target);
//			addFlashAttribute() 메소드로 1회성 메시지를 viewpage로 전달한다.
			redirectAttributes.addFlashAttribute("msg", id + "번 글 삭제완료");
		}
		
		return "redirect:/articles";
	}
	
}


















