package com.mbcit.k20250121_1_springBoot_JPA01.repository;

import java.util.Map;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.mbcit.k20250121_1_springBoot_JPA01.domain.Member;

public interface MemberRepository extends JpaRepository<Member, Long> {

	@Query(value = "select * from member2 limit 1;", nativeQuery = true)
	Map<String, Object> findRecord();
	
}
