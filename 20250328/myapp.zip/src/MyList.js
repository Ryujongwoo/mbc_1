import React from "react";

function MyList() {
  const data = [1, 2, 3, 4, 5, 1];
  return (
    <div align="center">
      <h1>MyList</h1>
      <ul>
        {
          // map() 함수는 익명 함수의 첫 번째 인수로 배열의 각 인덱스에 해당되는 데이터를 전달하고
          // 생략 가능한 두 번째 인수로 인덱스를 전달한다.
          data.map((number, index) => <li key={index}>ListItem {number}</li>)
        }
      </ul>
    </div>
  );
}

export default MyList;
