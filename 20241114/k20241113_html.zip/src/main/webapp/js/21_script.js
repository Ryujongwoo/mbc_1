const mySite = document.getElementById('my-site')
console.log(mySite) // null
console.log(mySite.innerText) // 에러