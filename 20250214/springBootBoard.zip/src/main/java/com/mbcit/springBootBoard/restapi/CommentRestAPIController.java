package com.mbcit.springBootBoard.restapi;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mbcit.springBootBoard.dto.CommentDto;
import com.mbcit.springBootBoard.entity.Comment;
import com.mbcit.springBootBoard.service.CommentService;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
public class CommentRestAPIController {

//	CommentService 클래스의 메소드를 사용하기 위해 @Service 어노테이션을 붙여서 선언한
//	CommentService 클래스의 bean을 얻어온다.
	@Autowired
	private CommentService commentService;
	
//	질문글의 id에 따른 답변글 목록 조회
//	Talend API Tester(GET) => http://localhost:9090/restapi/comments/1
	@GetMapping("/restapi/comments/{articleId}")
	public ResponseEntity<List<CommentDto>> comments(@PathVariable Long articleId) {
		log.info("CommentRestAPIController의 comments() 메소드 실행");
//		log.info("commentService: " + commentService);
//		log.info("articleId: " + articleId);
		
//		서비스에 위임
		List<CommentDto> commentDtos = commentService.comments(articleId);
		commentDtos.forEach(System.out::println);
		
//		결과 응답
		return ResponseEntity.status(HttpStatus.OK).body(commentDtos);
	}
	
//	답변글 입력
//	Talend API Tester(POST) => http://localhost:9090/restapi/comments/1
//	Talend API Tester body 데이터
//	{
//	  "nickname": "손오공",
//	  "body": "5등 입니다.",
//	  "articleId": 1
//	}
	@PostMapping("/restapi/comments/{articleId}")
	public ResponseEntity<CommentDto> create(@PathVariable Long articleId, @RequestBody CommentDto commentDto) {
		log.info("CommentRestAPIController의 create() 메소드 실행");
//		log.info("articleId: {}, commentDto: {}", articleId, commentDto);
		
//		서비스에 위임
		CommentDto createDto = commentService.create(articleId, commentDto);
		
//		결과 응답
		return ResponseEntity.status(HttpStatus.OK).body(createDto);
	}
	
//	답변글 수정
//	Talend API Tester(PATCH) => http://localhost:9090/restapi/comments/1
//	Talend API Tester body 데이터
//	{
//	  "id": 1
//	  "nickname": "손오공",
//	  "body": "5등 입니다.",
//	  "articleId": 1
//	}
	@PatchMapping("/restapi/comments/{id}")
	public ResponseEntity<CommentDto> update(@PathVariable Long id, @RequestBody CommentDto commentDto) {
		log.info("CommentRestAPIController의 update() 메소드 실행");
//		log.info("id: {}, commentDto: {}", id, commentDto);
		
//		서비스에 위임
		CommentDto createDto = commentService.update(id, commentDto);
		
//		결과 응답
		return ResponseEntity.status(HttpStatus.OK).body(createDto);
	}
	
//	답변글 삭제
//	Talend API Tester(DELETE) => http://localhost:9090/restapi/comments/1
	@DeleteMapping("/restapi/comments/{id}")
	public ResponseEntity<CommentDto> delete(@PathVariable Long id) {
		log.info("CommentRestAPIController의 delete() 메소드 실행");
//		log.info("id: " + id);
		
//		서비스에 위임
		CommentDto createDto = commentService.delete(id);
		
//		결과 응답
		return ResponseEntity.status(HttpStatus.OK).body(createDto);
	}
	
}















