# insert into 테이블이름(필드이름, ...) values (데이터, ...)
INSERT INTO memolist(NAME, PASSWORD, memo, ip) VALUES ('홍길동', '1111', '1등 입니다.', '192.168.200.1');
INSERT INTO memolist(NAME, PASSWORD, memo, ip) VALUES ('임꺽정', '2222', '2등 입니다.', '192.168.200.2');
INSERT INTO memolist(NAME, PASSWORD, memo, ip) VALUES ('장길산', '3333', '3등 입니다.', '192.168.200.3');
INSERT INTO memolist(NAME, PASSWORD, memo, ip) VALUES ('일지매', '4444', '4등 입니다.', '192.168.200.4');

DELETE FROM memolist;
ALTER TABLE memolist AUTO_INCREMENT = 1;

SELECT * FROM memolist;

SELECT * FROM memolist ORDER BY idx DESC;
SELECT COUNT(*) FROM memolist;

