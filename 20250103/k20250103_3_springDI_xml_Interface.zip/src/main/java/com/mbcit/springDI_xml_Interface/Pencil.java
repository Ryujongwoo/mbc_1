package com.mbcit.springDI_xml_Interface;

public interface Pencil {

//	public abstract void use();
	void use();
	
}
