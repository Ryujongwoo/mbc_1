import React, { useEffect, useState } from 'react';

// Counter라는 컴포넌트를 만든다.
function Counter() {
  // useState() hook 함수가 실행되면 인수로 지정된 상태 값의 초기치와 상태 값을 변경하는 함수가 
  // 배열로 리턴된다.
  // const state = useState(0);
  // console.log('useState:', state);

  // const [상태 값을 기억할 변수, 상태 값을 변경할 함수] = useState(상태 값의 초기치);
  // count라는 상태를 초기치를 0을 지정해서 선언하고 count라는 상태 값을 변경할 함수는 setCount로
  // 선언한다.
  const [count1, setCount1] = useState(0);
  const [count2, setCount2] = useState(0);

  // useEffect() hook 함수는 렌더링이 완료되면 인수로 지정한 콜백 함수가 호출된다.
  // useEffect(콜백 함수, [의존성을 포함하는 배열])
  // 두 번째 인수로 지정하는 의존성을 포함하는 배열에는 상태 값을 기억하는 변수를 적어주며 적어준 
  // 변수에 저장된 상태 값이 변경되서 다시 렌더링이 되면 콜백 함수가 실행된다.
  // 두 번째 인수는 생략할 수 있고 생략하면 모든 상태 값이 변경될 때 콜백 함수가 실행된다.
  // 두 번째 인수로 빈 배열을 사용하면 첫 번째 렌더링 후에만 콜백 함수가 실행된다.
  useEffect(() => {
    console.log('렌더링이 완료되면 useEffect 함수의 콜백 함수가 실행됨');

    // useEffect() 함수는 함수를 리턴할 수 있다.
    // 리턴하는 함수는 렌더링이 완료되기 전에 실행해야 할 작업이 있을 경우 사용한다.
    return () => {
      console.log('콜백 함수가 실행되기 전에 useEffect() 함수가 리턴하는 함수가 실행됨');
    }

  }, [count1]);

  return (
    <div align="center">
      <h1>Counter</h1>
      <p>Count1 = {count1}, Count2 = {count2}</p>
      <button type='button' onClick={
        () => {
          console.log('count1 상태값 변경');
          // 상태 값이 변경되면 리액트는 컴포넌트를 다시 렌더링(함수가 실행) 한다.
          setCount1(count1 + 1);
        }
      }>Increment1</button>
      <button type='button' onClick={
        () => {
          console.log('count2 상태값 변경');
          setCount2(count2 + 1);
        }
      }>Increment2</button>
    </div>
  );
}

// 컴포넌트를 다른 js 파일에서 사용하려면 반드시 export를 시켜야 한다.
export default Counter;



