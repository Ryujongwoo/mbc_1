package com.mbcit.k20250116_4_springBoot_Form;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class K202501164SpringBootFormApplicationTests {

	@Test
	void contextLoads() {
	}

}
