$(() => {
//	input 태그 중에서 type 속성의 속성 값이 text인 모든 요소를 선택해서 배경색 변경하기
//	javascript
	/*
//	let inputs = document.getElementsByTagName('input');
	let inputs = document.querySelectorAll('input');
//	console.log(inputs.length);
	for (let input of inputs) {
		// getAttribute() 함수는 인수로 지정된 속성의 속성 값을 얻어올 수 있다.
		// console.log(input.getAttribute('type'));
		if (input.getAttribute('type') === 'text') {
			input.style.backgroundColor = 'yellowgreen';
		}
	}
	*/
	/*
	let inputs = document.querySelectorAll('input[type="text"]');
	console.log(inputs.length);
	for (let input of inputs) {
		input.style.backgroundColor = 'hotpink';
	}
	*/
	
//	jQuery
//	$('input[type=text]').css('backgroundColor', 'tomato');
	$('input:text').css('backgroundColor', 'dodgerblue');
	
//	select 태그의 id 속성 값이 email인 요소에서 change 이벤트가 발생되면 선택된 option의 value 값을
//	id 속성 값이 addr인 텍스트 상자에 넣어준다.
	
//	javascript
	/*
	let email = document.getElementById('email');
	// console.log(email);
	email.onchange = () => {
		let emailValue = email.options[email.selectedIndex].value;
		// console.log(emailValue);
		document.getElementById('addr').value = emailValue;
	}
	*/
	
//	jQuery
	$('#email').change(() => {
		let emailValue = $('#email > option:selected').val();
		// console.log(emailValue);
		$('#addr').val(emailValue);
	});
});
















