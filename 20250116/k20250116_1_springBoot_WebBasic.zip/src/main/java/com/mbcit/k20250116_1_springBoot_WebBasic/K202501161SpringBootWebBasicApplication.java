package com.mbcit.k20250116_1_springBoot_WebBasic;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class K202501161SpringBootWebBasicApplication {

	public static void main(String[] args) {
		SpringApplication.run(K202501161SpringBootWebBasicApplication.class, args);
	}

}
