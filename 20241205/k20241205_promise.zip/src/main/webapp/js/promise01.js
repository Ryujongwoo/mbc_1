//	JSON(JavaScript Object Natation)

//	javascript 객체를 json으로 변환하기
//	JSON.stringify(javascript 객체): 인수로 지정된 javascript 객체를 json으로 변환한다.
let json = JSON.stringify(true);
console.log(true, typeof true);
console.log(json, typeof json);
console.log('1. ====================================================');

json = JSON.stringify(['apple', 'banana']);
console.log(['apple', 'banana'], typeof ['apple', 'banana']);
console.log(json, typeof json);
console.log('2. ====================================================');

//	javascript 객체
const rabbit = {
//	key: value
	name: '토오끼',
	color: '회색',
	size: '겁나큼',
//	javascript 객체나 함수는 stringify() 함수를 사용해서 json 형태로 변환할 수 없다.
	birthDate: new Date(),
	jump: () => console.log('javascript 객체는 key에 객체와 함수를 할당할 수 있다.')
}
console.log(rabbit, typeof rabbit);
rabbit.jump();

//	json은 javascript 객체와 달리 key 부분을 반드시 큰따옴표를 사용하는 문자열로 만든다.
json = JSON.stringify(rabbit);
console.log(json, typeof json);
console.log('3. ====================================================');

//	stringify() 함수의 2번째 인수로 json으로 변환할 javascript 객체의 속성을 배열로 지정할 수 있다.
json = JSON.stringify(rabbit, ['name', 'color']);
console.log(json);
console.log('4. ====================================================');

//	더 세밀한 제어를 하려면 stringify() 함수의 2번째 인수로 함수를 지정할 수 있다.
//	2번째 인수로 지정한 함수에 1번째 인수로 지정된 javascript 객체의 key와 value가 인수로 넘어온다.
json = JSON.stringify(rabbit, function (key, value) {
	console.log('stringify() 함수의 2번째 인수로 지정한 함수가 실행됨');
	console.log('key: ' + key + ', value: ' + value);
//	2번째 인수로 지정한 함수에서 인수에 저장된 내용을 처리하려면 반드시 value 값을 리턴시켜야 한다.
//	return value;
	return key == 'name' ? '별주부' : value;
});
console.log(json);
console.log('5. ====================================================');

//	json을 javascript 객체로 변환하기
//	JSON.parse(json): 인수로 지정된 json을 javascript 객체로 변환한다.
//	console.clear(); // 콘솔 창에 출력된 모든 내용을 지운다.

//	rabbit javascript 객체를 json으로 변환 후 다시 javascript 객체로 변환해보자.
json = JSON.stringify(rabbit);
console.log(json);
let obj = JSON.parse(json);
console.log(obj);
console.log('6. ====================================================');

//	rabbit는 javascript 객체이므로 birthDate에서 getFullYear() 함수가 실행된다.
console.log(rabbit.birthDate.getFullYear());
//	rabbit 객체에 stringify() 함수를 실행하면 문자열로 구성된 json으로 변경되기 때문에 getFullYear() 함수가
//	실행되지 않는다.
//	console.log(json.birthDate.getFullYear());
//	json에 저장된 json 데이터를 javascript 객체로 바꿔도 문자열로 처리되므로 getFullYear() 함수가 실행되지
//	않는다.
//	console.log(obj.birthDate.getFullYear());
console.log('7. ====================================================');

//	더 세밀한 제어를 하기 위해서 parse() 함수의 2번째 인수로 함수를 지정할 수 있다.
//	2번째 인수로 지정한 함수에 1번째 인수로 지정된 javascript 객체의 key와 value가 인수로 넘어온다.

obj = JSON.parse(json, function (key, value) {
	console.log('parse() 함수의 2번째 인수로 지정한 함수가 실행됨');
	console.log('key: ' + key + ', value: ' + value);
	return key == 'birthDate' ? new Date() : value;
});
console.log(obj);

