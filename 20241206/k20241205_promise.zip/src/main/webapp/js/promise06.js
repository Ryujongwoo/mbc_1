//	콜백 지옥 => promise

const id = prompt('아이디를 입력하세요');
const pw = prompt('비밀번호를 입력하세요');

class UserStorage {
	
//	로그인 처리함수
	/*
//	loginUser(아이디, 비밀번호, 로그인 성공시 실행할 callback 함수, 로그인 실패시 실행할 callback 함수)
	loginUser(id, pw, onSuccess, onError) {
		setTimeout(() => {
			if (id === '홍길동' && pw === '1111' || id === '임꺽정' && pw === '2222') {
				onSuccess(id);
			} else {
				onError('로그인 실패');
			}
		}, 2000);
	}
	*/
	
//	콜백 지옥에 빠진 이유는 성공시 실행할 함수와 실패시 실행할 함수를 인수로 받았기 때문이다.
//	promise를 사용하면 성공시 resolve() 함수로 실패시 reject() 함수로 처리하면 된다.
	
//	loginUser(아이디, 비밀번호)
	loginUser(id, pw) {
		// 함수가 호출되면 promise를 만들어서 리턴시킨다.
		return new Promise(function (resolve, reject) {
			// 기존 코드를 Promise의 executor 함수에서 실행한다.
			setTimeout(() => {
				if (id === '홍길동' && pw === '1111' || id === '임꺽정' && pw === '2222') {
					// onSuccess(id);
					resolve(id);
				} else {
					// onError('로그인 실패');
					reject('로그인 실패');
				}
			}, 2000);
		})
	}
	
//	로그인 후 아이디에 따른 역할을 받아오는 함수
	/*
//	getRoles(아이디, 역할을 받아오면 실행할 callback 함수, 역할을 받아오지 못하면 실행할 callback 함수)
	getRoles(id, onSuccess, onError) {
		setTimeout(function () {
			if (id === '홍길동') {
				onSuccess({
					name: '홍길동',
					role: '관리자'
				});
			} else {
				onError('역할을 받아오지 못함');
			}
		}, 1000);
	}
	*/
	
//	getRoles(아이디)
	getRoles(id) {
		// 함수가 호출되면 promise를 만들어서 리턴시킨다.
		return new Promise(function (resolve, reject) {
			// 기존 코드를 Promise의 executor 함수에서 실행한다.
			setTimeout(function () {
				if (id === '홍길동') {
					// onSuccess({ name: '홍길동', role: '관리자' });
					resolve({ name: '홍길동', role: '관리자' });
				} else {
					// onError('역할을 받아오지 못함');
					reject('역할을 받아오지 못함');
				}
			}, 1000);
		});
	}	
}

const userStorage = new UserStorage();

/*
userStorage.loginUser(
	id, 
	pw, 
	id => {
		console.log(id + '님 로그인 성공');
		userStorage.getRoles(
			id, 
			role => console.log(`안녕하세요 ${role.name}님 당신의 권한은 ${role.role} 입니다.`), 
			error => console.log(error));
	}, 
	error => console.log(error)
);
*/

/*
userStorage.loginUser(id, pw)
	.then(function (id) {
		console.log(id + '님 로그인 성공');
		return userStorage.getRoles(id);
	})
	.then(function (role) {
		// console.log(role);
		console.log(`안녕하세요 ${role.name}님 당신의 권한은 ${role.role} 입니다.`);
	})
	.catch(function (error) {
		console.log(error);
	});
*/

userStorage.loginUser(id, pw)
	.then(id => {
		alert(id + '님 로그인 성공');
		return userStorage.getRoles(id);
	})
	.then(role => alert(`안녕하세요 ${role.name}님 당신의 권한은 ${role.role} 입니다.`))
	.catch(error => alert(error));

