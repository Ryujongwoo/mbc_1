import React, { useContext } from "react";
import AuthContext from "./AuthContext";

function UserComponent() {
  // useContext hook를 사용하면 어떤 컴포넌트에서든지 제공되는 값에 접근할 수 있다.
  const authContext = useContext(AuthContext);
  return (
    <div>
      Welcome {authContext}
    </div>
  );
}

export default UserComponent;
