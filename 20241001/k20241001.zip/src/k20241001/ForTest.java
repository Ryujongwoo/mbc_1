package k20241001;

public class ForTest {

	public static void main(String[] args) {
		
//		자바의 반복문은 for, while, do ~ while이 있다.
//		일반적으로 for는 반복 횟수를 알고있을때 사용하고 while, do ~ while은 반복 횟수를 모를때 사용한다.
		
//		일반 for
//		for (자료형 변수이름 = 초기치; 조건식; 증감치) {
//			조건식이 참인 동안 반복할 문장;
//			...;
//		}
		
		int sum = 0;
//		먼저 변수 i를 선언하고 1로 초기화한 후 조건식을 실행해서 참일 경우 반복이 시작된다.
//		조건이 참일 경우 {} 블록을 실행하고 i값을 증감치 만큼 변경한 후 조건을 비교해 참일 경우
//		{} 블록을 실행하고 거짓일 경우 반복을 종료한다.
		for (int i = 1; i <= 10; i++) {
//			System.out.println("i: " + i);
//			대입 연산자는 "="와 같이 사용된다. +=, -=, *=, /=, %=, ...
			sum += i; // sum = sum + i와 같은 기능이 실행된다.
		}
		System.out.println("1 ~ 10의 합계: " + sum);
		
//		증감 연산자: ++(1증가), --(1감소) => 단항 연산자
//		i++: 사용 후 증가, 변수 i에 저장된 값을 사용(연산)하고 ";"을 만나서 문장이 종료될 때 1증가시킨다.
//		++i: 증가 후 사용, 변수 i에 저장된 값을 1증가시키고 사용한다.
//		i--: 사용 후 감소, 변수 i에 저장된 값을 사용(연산)하고 ";"을 만나서 문장이 종료될 때 1감소시킨다.
//		--i: 감소 후 사용, 변수 i에 저장된 값을 1감소시키고 사용한다.
		
		int a = 1, b, c;
		b = a++;
		c = ++a;
		System.out.printf("a = %d, b = %d, c = %d\n", a, b, c);
		
		int d = 1, e;
		e = ++d + ++d + ++d + ++d;
		System.out.printf("d = %d, e = %d\n", d, e);
		
		int f = 1, g;
		g = f++ + f++ + f++ + f++;
		System.out.printf("f = %d, g = %d\n", f, g);
		
	}
	
}





















