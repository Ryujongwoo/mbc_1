package com.mbcit.k20250116_3_springBoot_Model;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class K202501163SpringBootModelApplication {

	public static void main(String[] args) {
		SpringApplication.run(K202501163SpringBootModelApplication.class, args);
	}

}
