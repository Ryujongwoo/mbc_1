package com.mbcit.customer;

import java.text.DecimalFormat;
import java.text.NumberFormat;

//	부모 클래스
//	일반 고객 정보를 기억하는 클래스
public class Customer {

//	모든 고객 정보를 기억하는 멤버 변수
	private int customerID; // 고객 ID
	private String customerName; // 고객 이름
	private String customerGrade; // 고객 등급
	private int bonusPoint; // 보너스 포인트
	private double bonusRatio; // 보너스 포인트 적립 비율
	
//	기본 생성자에서 멤버 변수 초기화
//	고객 등급은 SILVER로 보너스 포인트 적립 비율은 1%로 초기화 시킨다.
	public Customer() {
		customerGrade = "SILVER";
		bonusRatio = 0.01;
	}
	
//	getters & setters
	public int getCustomerID() {
		return customerID;
	}
	public void setCustomerID(int customerID) {
		this.customerID = customerID;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getCustomerGrade() {
		return customerGrade;
	}
	public void setCustomerGrade(String customerGrade) {
		this.customerGrade = customerGrade;
	}
	public int getBonusPoint() {
		return bonusPoint;
	}
	public void setBonusPoint(int bonusPoint) {
		this.bonusPoint = bonusPoint;
	}
	public double getBonusRatio() {
		return bonusRatio;
	}
	public void setBonusRatio(double bonusRatio) {
		this.bonusRatio = bonusRatio;
	}
	
//	toString() 메소드 override
	@Override
	public String toString() {
		return "Customer [customerID=" + customerID + ", customerName=" + customerName + ", customerGrade="
				+ customerGrade + ", bonusPoint=" + bonusPoint + ", bonusRatio=" + bonusRatio + "]";
	}

//	회원 정보를 리턴하는 메소드
//	이몽룡님의 등급은 SILVER이며, 보너스 포인트는 1,000점 입니다.
	public String showCustomerInfo() {
//		NumberFormat nf = NumberFormat.getNumberInstance();
		DecimalFormat df = new DecimalFormat("#,##0");
		return customerName + "님의 등급은 " + customerGrade + "이며, 보너스 포인트는 " + 
			df.format(bonusPoint) + "점 입니다.";
	}

//	구매 금액을 인수로 넘겨받아 보너스 포인트를 계산해서 리턴하는 메소드
	public int calcBonus(int price) {
		return (int) (price * bonusRatio);
	}
	
//	구매 금액을 인수로 넘겨받아 누적 보너스 포인트를 계산해서 리턴하는 메소드
	public int calcPrice(int price) {
//		bonusPoint += price * bonusRatio; // 정상
//		bonusPoint = bonusPoint + price * bonusRatio; // 에러
		
//		대입 연산자는 오라클 공식 문서를 살펴보면 아래와 같이 처리된다.
//		bonusPoint += price * bonusRatio 연산을 실행하면 아래와 같이 자동으로 형변환 된다.
//		bonusPoint = (결과를 기억할 변수의 자료형) (bonusPoint + price * bonusRatio);
//		bonusPoint = (int) (bonusPoint + price * bonusRatio);
		
//		보너스 포인트를 계산하는 메소드가 있으므로 메소드를 사용해서 계산해도 된다.
		bonusPoint += calcBonus(price);
		return bonusPoint;
	}
	
}









