package com.mbcit.k20250116_6_springBoot_Validator;

import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
public class HomeController {

	@RequestMapping("/")
	public @ResponseBody String home() {
		log.info("HomeController 클래스의 home() 메소드 실행");
		return "ValidatorUtil 테스트";
	}
	
	@RequestMapping("/insertForm")
	public String insertForm() {
		log.info("HomeController 클래스의 insertForm() 메소드 실행");
		return "insertForm";
	}
	
	@RequestMapping("/create")
	public String create(@ModelAttribute("vo") ContentVO contentVO, BindingResult bindingResult) {
		log.info("HomeController 클래스의 create() 메소드 실행");
		log.info("{}", contentVO);
	
		ContentValidator contentValidator = new ContentValidator();
		contentValidator.validate(contentVO, bindingResult);
		
		String viewpage = "createDone";
		if (bindingResult.hasErrors()) {
			
//			log.info("getAllErrors(): {}", bindingResult.getAllErrors());
			if (bindingResult.getFieldError("writer") != null) {
				log.info("writer: {}", bindingResult.getFieldError("writer").getCode());
			}
			if (bindingResult.getFieldError("content") != null) {
				log.info("content: {}", bindingResult.getFieldError("content").getCode());
			}
			
			viewpage = "insertForm";
		}
		
		return viewpage;
	}
	
}









