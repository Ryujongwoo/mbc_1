-- 주석
CREATE TABLE "GUESTBOOK" (
    "IDX" NUMBER(*,0) NOT NULL, 
	"NAME" CHAR(20 BYTE) NOT NULL, 
	"PASSWORD" CHAR(20 BYTE) NOT NULL, 
	"MEMO" VARCHAR2(3000 BYTE) NOT NULL, 
	"WRITEDATE" TIMESTAMP (6) DEFAULT sysdate, 
	"IP" CHAR(20 BYTE), 
	CONSTRAINT "GUESTBOOK_PK" PRIMARY KEY ("IDX")
);

-- 오라클은 자동 증가 기능을 사용하려면 sequence를 만들어 사용해야 한다.
-- 시퀀스 초기화 => 시퀀스가 다시 1부터 시작되게 한다.
-- 모든 데이터를 제거하고 시퀀스를 삭제하고 다시 만든다.
delete from guestbook;
-- 시퀀스 지우기: drop sequence 시퀀스이름;
drop sequence guestbook_idx_seq;
-- 시퀀스 만들기: create sequence 시퀀스이름;
create sequence guestbook_idx_seq;

-- 시퀀스이름.nextval: 시퀀스 값을 1증가 시킨다.
-- 시퀀스이름.currval: 현재 시퀀스 값을 의미한다.
insert into guestbook(idx, name, password, memo, ip) 
values (guestbook_idx_seq.nextval, '홍길동', '1111', '1등 입니다.', '162.168.300.101');
insert into guestbook(idx, name, password, memo, ip) 
values (guestbook_idx_seq.nextval, '임꺽정', '2222', '2등 입니다.', '162.168.300.102');
insert into guestbook(idx, name, password, memo, ip) 
values (guestbook_idx_seq.nextval, '장길산', '3333', '3등 입니다.', '162.168.300.103');
insert into guestbook(idx, name, password, memo, ip) 
values (guestbook_idx_seq.nextval, '일지매', '4444', '4등 입니다.', '162.168.300.104');

select * from guestbook;








