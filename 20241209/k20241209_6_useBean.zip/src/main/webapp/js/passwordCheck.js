function passwordCheck(obj) {
//	console.log(obj);

	/*
//	입력한 비밀번호가 8글자 이상이고 12글자 이하인가 검사한다.
 	let len = obj.password.value.trim().length;
	if (len < 8 || len > 12) {
		alert('비밀번호는 8글자 이상 12글자 이하로 입력해야 합니다.');
		obj.password.value = '';
		obj.repassword.value = '';
		obj.password.focus();
		return false;
	}
	
//	영문자, 숫자, 특수문자가 각각 1개 이상씩 입력되었나 검사한다.
	let alphaCount = 0; // 영문자 개수
	let numberCount = 0; // 숫자 개수
	let etcCount = 0; // 특수문자 개수
	
//	입력된 비밀번호의 문자 개수만큼 반복하며 영문자, 숫자, 특수문자의 개수를 센다.
	let pw = obj.password.value.trim();
	for (let i = 0; i < len; i++) {
		if (pw.charAt(i) >= 'a' && pw.charAt(i) <= 'z' || pw.charAt(i) >= 'A' && pw.charAt(i) <= 'Z') {
			alphaCount++;
		} else if(pw.charAt(i) >= '0' && pw.charAt(i) <= '9') {
			numberCount++;
		} else {
			etcCount++;
		}
		console.log(`영문자: ${alphaCount}, 숫자: ${numberCount}, 특수문자: ${etcCount}`);
	}
	
	if (alphaCount == 0 || numberCount == 0 || etcCount == 0) {
		alert('비밀번호는 영문자, 숫자, 특수문자를 각각 1글자 이상 포함해야 합니다.');
		obj.password.value = '';
		obj.repassword.value = '';
		obj.password.focus();
		return false;
	}
	*/
	
	let pw = obj.password.value.trim();
	
//	정규 표현식(정규식, Regular Expression)을 사용한 영문자, 숫자, 특수문자(!@#$%^&)가 각각 1개 이상 입력되었고
//	8글자 이상 12글자 이하로 입력되었나 검사한다.


	
	return true;
}

function pwCheck() {
	let password = document.getElementsByName('password')[0].value.trim();
	let repassword = document.getElementsByName('repassword')[0].value.trim();
	if (password == repassword) {
		document.getElementById('checkMsg').innerHTML = 
			'<span style="color: blue;">비밀번호가 일치합니다.</span>';
	} else {
		document.getElementById('checkMsg').innerHTML = 
			'<span style="color: red;">비밀번호가 일치하지 않습니다.</span>';
	}
}

