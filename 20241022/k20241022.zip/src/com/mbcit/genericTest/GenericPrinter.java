package com.mbcit.genericTest;

//	재료로 Plastic과 Powder를 모두 사용하는 3D 프린터 => 겸용 프린터 => generic
//	generic은 자료형을 기억하는 변수로 데이터가 아니라 데이터의 타입을 받는다.
//	코딩 단계에서는 사용할 클래스가 지정되지 않고 클래스를 사용하는 시점에서 실제로 사용할 
//	자료형을 지정한다. static에는 사용할 수 없다.
//	E(Element), K(Key), V(Value), T(Template) 등 여러 알파벳을 의미에 따라 사용할 수 있다.
public class GenericPrinter<M> {

	private M material;

	public M getMaterial() {
		return material;
	}

	public void setMaterial(M material) {
		this.material = material;
	}

	@Override
	public String toString() {
		return material + "을(를) 재료로 사용하는 3D 프린터 사용중";
	}
	
}
