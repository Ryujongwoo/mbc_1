package com.mbcit.k20250121_1_springBoot_JPA01.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mbcit.k20250121_1_springBoot_JPA01.domain.MemberHistory;

public interface MemberHistoryRepository extends JpaRepository<MemberHistory, Long> {

//	특정 memberId에 해당되는 데이터만 가져오는 쿼리 메소드를 만든다.
	List<MemberHistory> findByMemberId(Long memberId);
	
}
