package com.mbcit.k20250117_1_springBoot_InitBinder;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class K202501171SpringBootInitBinderApplication {

	public static void main(String[] args) {
		SpringApplication.run(K202501171SpringBootInitBinderApplication.class, args);
	}

}
