package com.mbcit.springBootReact02.domain;

import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

//	REST 리소스로 노출하지 않으려면 리포지토리로 사용하는 인터페이스에 @RepositoryRestResource
//	어노테이션을 지정하고 exported 속성값을 false로 설정한다.
@RepositoryRestResource(exported = false)
public interface UserRepository extends CrudRepository<User, Long> {

//	username으로 검색하는 메소드
	public User findByUsername(@Param("username") String username);
	
}
