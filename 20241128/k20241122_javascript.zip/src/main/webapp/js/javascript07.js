//	객체 배열
const obj = [
	{
		name: '멍멍이'
	},
	{
		name: '야옹이'
	}
]

console.log(obj);
console.log(obj.length);
console.log(obj[0]);
console.log(obj[1]);
console.log(obj[0].name);
console.log(obj[1].name);
console.log('============================');

//	push(): 배열의 맨 뒤에 데이터를 추가한다.
const hong = {
	name: '홍길동'
}
obj.push(hong);
console.log(obj);

obj.push({
	name: '임꺽정'
});
console.log(obj);

//	pop(): 배열의 맨 뒤의 데이터를 얻어온 후 제거한다.

nickname = obj.pop();
console.log(nickname);
console.log(obj);

console.log(obj.pop());
console.log(obj);
console.log('============================');

const doggy = {
	name: '멍멍이',
	sound: '멍멍',
	age: 2
}

//	Object.keys(): 인수로 지정된 객체의 key 목록 배열을 얻어온다.
keys = Object.keys(doggy);
console.log(keys);

for (let i = 0; i < keys.length; i++) { // 일반 for
	console.log(keys[i]);
}
console.log('============================');

//	Object.values(): 인수로 지정된 객체의 value 목록 배열을 얻어온다.
const values = Object.values(doggy);
console.log(values);

for (let value of values) {
	console.log(value);
}
console.log('============================');

//	Object.entries(): 인수로 지정된 객체의 key와 key에 할당된 value를 배열로 묶은 배열을 얻어온다.
const entries = Object.entries(doggy);
console.log(entries);

for (let i in entries) {
	console.log(entries[i][0]);
	console.log(entries[i][1]);
}
console.log('============================');

//	객체의 멤버에 접근하는 방법은 객체 이름에 '.'을 찍어서 접근하는 방법과 []안에 key를 입력해서
//	접근하는 방법이 있다.
console.log(doggy.name);
console.log(doggy.sound);
console.log(doggy.age);

console.log(doggy['name']);
console.log(doggy['sound']);
console.log(doggy['age']);
console.log('============================');

for (let key of keys) {
	console.log(doggy[key]);
}

