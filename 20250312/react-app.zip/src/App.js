import './App.css';
import { useState } from 'react';

// 사용자 정의 컴포넌트(사용자 정의 함수, 이하 컴포넌트)를 만든다.
// 컴포넌트 이름은 반드시 대문자로 시작해야 한다.
// 컴포넌트의 인수로 컴포넌트가 호출될 때 전달되는 데이터(prop)를 받는다.
// 인수 이름은 props라고 지정했는데 인수 이름은 반드시 props라고 할 필요는 없다.
// 남들다 props로 하니까 우리도 props라고 했다.
function Header(props) {
  // props로 넘어온 속성에 할당된 속성 값은 '.'을 찍어서 얻어온다.
  // console.log(`props: ${props}, props.title: ${props.title}`)
  // console.log(props, props.title, props.onChangeMode)
  // 컴포넌트는 반드시 html 코드를 return 시켜야 한다.
  return (
    <header>
      {/* props로 넘어온 데이터를 사용하려면 {}로 묶어준다. */}
      <h1><a href='/' onClick={
        event => {
          // <a> 태그가 실행하는 기본 동작을 실행하지 않는다.
          event.preventDefault()
          // Header 컴포넌트가 호출될 때 넘겨받은 onChangeMode prop에 저장된 함수를 실행한다.
          props.onChangeMode()
        }
      }>{props.title}</a></h1>
    </header>
  )
}

function Nav(props) {
  let lis = [] // return할 결과를 저장할 빈 배열을 선언한다.
  for (let i=0; i<props.topics.length; i++) {
    // console.log(props.topics[i])
    let topic = props.topics[i]

    // Each child in a list should have a unique "key" prop. 메시지가 출력되는 경우 아래와 같이 처리한다.
    // 반복문을 사용해서 동적으로 만든 <li> 태그는 key라는 prop을 가지고 있어야 하고,
    // key라는 prop은 반복문 내부에서 고유한 값을 가져야 한다.
    lis.push(
      <li key={topic.id}>
        <a id={topic.id} href={'/read/' + topic.id} onClick={
          event => {
            event.preventDefault()
            // onChangeMode prop에 저장되서 넘어오는 함수를 호출할 때 id 값을 전달해야 한다.
            // 이벤트 함수 안에서 <a> 태그의 id 속성값을 얻어내려면 event 객체를 사용한다.
            // event.target이라고 하면 target은 이벤트를 발생시킨 태그, 즉 <a> 태그를 의미한다.
            // <a> 태그가 가지고 있는 id 속성값은 event.target.id와 같은 형태로 얻어올 수 있다.
            props.onChangeMode(Number(event.target.id))
          }
        }>{topic.title}</a><br/>
        {topic.body}
      </li>
    )
  }

  return (
    <nav>
      <ol>
        {/*
        <li><a href='/read/1'>html</a></li>
        <li><a href='/read/2'>css</a></li>
        <li><a href='/read/3'>js</a></li>
        */}
        {lis}
      </ol>
    </nav>
  )
}

function Article(props) {
  return (
    <article>
      <h2>{props.title}</h2>
      {props.body}
    </article>
  )
}

function Create(props) {
  return (
    <article>
      <h2>Create</h2>
      {/* onSubmit은 submit 버튼이 클릭되면 form에서 발생되는 이벤트이다. */}
      <form onSubmit={function (event) {
        // form 태그는 submit 버튼이 클릭되면 페이지가 reload 되므로 페이지가 reload 되는 것을
        // 방지하기 위해 preventDefault() 함수를 실행한다.
        event.preventDefault()
        // form 태그 내부의 name 속성이 title, body인 태그의 value 값을 가져와야 한다.
        // event.target은 onSubmit 이벤트가 발생된 태그, 즉 form 태그를 의미한다.
        // event.target.title은 name 속성 값이 title인 <input> 태그를 의미하므로 <input> 태그의
        // value 값을 얻어와야 하므로 event.target.title.value를 사용해서 title을 얻어낸다.
        const title = event.target.title.value
        // body는 event.target.body.value를 사용해서 얻어낸다.
        const body = event.target.body.value
        // console.log('title: ' + title + ', body: ' + body)
        props.onCreate(title, body)
      }}>
        <p><input type='text' name='title' placeholder='title' /></p>
        <p><textarea name='body' placeholder='body'></textarea></p>
        <p><input type='submit' value='Create' /></p>
      </form>
    </article>
  )
}

function Update(props) {
  // 수정을 하기 위해서 폼에 수정할 내용을 입력해도 입력한 값이 props의 title과 body를
  // 바꾸지 못한다.
  // 따라서 Update 컴포넌트에서 title과 body의 state를 만들고 props로 전달된 title과 body를
  // 넣어준 다음에 props.title, props.body를 state로 만든 title과 body를 사용한다.
  const [title, setTitle] = useState(props.title)
  const [body, setBody] = useState(props.body)
  return (
    <article>
      <h2>Update</h2>
      <form onSubmit={
        function (event) {
          event.preventDefault()
          const title = event.target.title.value
          const body = event.target.body.value
          // console.log('title: ' + title + ', body: ' + body)
          // props로 넘겨받은 내용으로 수정하는 함수를 실행한다.
          props.onUpdate(title, body)
        }
      }>
        {/* HTML의 onChange 이벤트는 값이 변경되거나 마우스 포인터가 밖으로 나가면 실행되지만 */}
        {/* 리액트의 onChange 이벤트는 HTML과 달리 값을 입력할 때 마다 실행된다. */}
        <p><input type='text' name='title' placeholder='title' value={title} 
          onChange={
            function (event) {
              // console.log(event.target.value)
              setTitle(event.target.value)
            }
          }
        /></p>
        <p><textarea name='body' placeholder='body' value={body} 
          onChange={
            function (event) {
              setBody(event.target.value)
            }
          }
        ></textarea></p>
        <p><input type='submit' value='Update' /></p>
      </form>
    </article>
  )
}

function App() {
  // Nav 컴포넌트에 전달할 정보가 저장된 배열을 만든다.
  // const topics = [
  //   {id: 1, title: 'html', body: 'html is ...'},
  //   {id: 2, title: 'css', body: 'css is ...'},
  //   {id: 3, title: 'js', body: 'js is ...'},
  //   ]
   
  // let mode = 'WELCOME'
  // useState는 배열을 리턴하는데 리턴되는 배열의 0번째 인덱스 요소는 상태값을 읽을 때 쓰이는 데이터이고,
  // 1번째 인덱스 요소는 상태값을 변경하는 함수이다.
  // const [상태의 초기값을 기억할 변수, 상태값이 변경되면 실행할 함수] = useState('상태의 초기값')
  const [mode, setMode] = useState('WELCOME')
  // Nav 컴포넌트의 어떤 글이 선택되었나 기억할 state를 만든다.
  const [id, setId] = useState(null)
  // <Create> 컴포넌트에서 입력한 데이터를 topics 배열에 추가해야 하므로 배열 상태인 topics를 useState를
  // 이용해서 state로 변경한다.
  const [topics, setTopics] = useState([
    {id: 1, title: 'html', body: 'html is ...'},
    {id: 2, title: 'css', body: 'css is ...'},
    {id: 3, title: 'js', body: 'js is ...'},
  ])
  // id 값을 관리할 state를 만든다.
  // topics 상태에 저장된 마지막 요소의 id 값이 3이므로 새로 생성되는 요소의 id는 4가 되어야하므로 4로 
  // 상태의 초기값을 지정한다.
  const [nextId, setNextId] = useState(4)

  let content = null
  let contextControl = null
  if (mode === 'WELCOME') {
    content = <Article title="Welcome" body="Hello, WEB" />
  } else if (mode === 'READ') {
    // topics 배열의 값 중에서 선택한 id와 일치하는 요소를 찾는다.
    let title = null
    let body = null
    for (let i=0; i<topics.length; i++) {
      // console.log(topics[i], id)
      // console.log('title: ' + title + ', body: ' + body)
      if (topics[i].id === id) {
        title = topics[i].title
        body = topics[i].body
      }
    }
    // content = <Article title="Welcome" body="Hello, READ" />
    // 선택한 id에 해당되는 title과 body 값으로 props를 설정한다.
    content = <Article title={title} body={body} />

    // 리액트에서 태그를 다룰 때는 하나의 태그안에 모든 내용이 들어가야 한다.
    // 특정 태그를 묶는 용도로 사용하지 않으려면 <>와 같이 제목이 없는 태그를 사용해서 묶어준다.
    // <> 태그는 여러 개의 태그를 묶는 용도로 사용하는 빈 태그이고 <> 태그를 사용하면 실제 HTML 코드는
    // 아무 태그도 존재하지 않는다.
    contextControl = 
      <>
        <li><a href={'/update/' + id} onClick={
          function (event) {
            event.preventDefault()
            setMode('UPDATE')
          }
        }>Update</a></li>
        <li>
          <input type='button' value='DELETE' onClick={
            function () {
              // 원본 데이터에서 삭제한 데이터를 제외한 나머지 데이터를 저장할 빈 배열을 만든다.
              const newTopics = []
              // 원본 데이터가 저장된 배열의 크기 만큼 반복하며 삭제한 데이터를 제외한 나머지
              // 데이터를 빈 배열에 저장한다.
              for (let i=0; i<topics.length; i++) {
                if (topics[i].id !== id) {
                  newTopics.push(topics[i])
                }
              }
              // 삭제할 데이터를 제외한 나머지 데이터가 저장된 배열로 topics를 수정한다.
              setTopics(newTopics)
              setMode('WELCOME')
            }
          }/>
        </li>
      </>

  } else if (mode === 'CREATE') {
    // <Create> 컴포넌트로 title과 body를 넘겨받아 topics 배열에 추가하는 함수를 prop으로 넘겨준다.
    content = <Create onCreate={function (title, body) {
      // console.log('title: ' + title + ', body: ' + body)
      // nextId, title, body를 이용해서 topics state에 추가될 새로운 요소를 객체로 만든다.
      const newTopic = {id: nextId, title: title, body: body}
      // useState는 오리지널 데이터와 새 데이터가 같은 데이터인가 확인하고, 같은 데이터일 경우 
      // 컴포넌트를 다시 렌더링하지 않는다.
      // 배열이나 객체는 반드시 복사본을 만들어서 변경해야 useState에 의해서 컴포넌트가 다시 렌더링된다.
      // ... => spread 연산자 => 객체의 내용을 퍼뜨린다.
      // console.log(...topics)
      const newTopics = [...topics] // spread 연산자를 이용해서 topics의 복사본 newTopics를 만든다.
      // setTopics() 함수로 state에 추가할 데이터(newTopic)를 topics의 복사본 newTopics에 추가한다.
      newTopics.push(newTopic)
      setTopics(newTopics)
      // 글이 추가된 후 상세 페이지로 이동한다.
      setMode('READ')
      setId(nextId) // 추가된 글이 상세 페이지에 출력되도록 id를 수정한다.
      setNextId(nextId + 1) // 다음에 추가될 글의 id 값을 1증가 시킨다.
    }}/>
  } else if (mode === 'UPDATE') {
    // mode가 READ일 때 title과 body를 얻어오는 코드를 복사해서 사용한다.
    let title = null
    let body = null
    for (let i=0; i<topics.length; i++) {
      if (topics[i].id === id) {
        title = topics[i].title
        body = topics[i].body
      }
    }
    content = <Update title={title} body={body} onUpdate={
      function (title, body) {
        // console.log('props로 넘겨받은 내용으로 수정하는 함수')
        // 배열이나 객체는 spread 연산자를 사용해서 복사본을 만들어서 변경해야 useState에 의해
        // 컴포넌트가 다시 렌더링 된다.
        const newTopics = [...topics]
        // console.log(newTopics)
        // 수정할 데이터로 수정할 객체를 만든다.
        const updatedTopic = {id: id, title: title, body: body}
        // console.log(updatedTopic)
        // 전체 데이터를 반복하며 수정할 데이터를 찾아서 수정한다.
        for (let i=0; i<newTopics.length; i++) {
          if (newTopics[i].id === id) {
            newTopics[i] = updatedTopic
            break
          }
        }
        // 수정된 내용으로 topics state를 갱신한다.
        setTopics(newTopics)
        setMode('READ')
      }
    }/>
  }
  
  return (
    <div className="App">
      {/*
      html 태그는 속성을 가지고 있다.
      컴포넌트도 html 태그처럼 속성을 지정할 수 있다. 이를 prop이라 한다.
      컴포넌트로 prop을 전달할 때 문자열은 따옴표로 묶어서 전달하고 문자열이 아닌 데이터는 {}로 묶어서 전달한다.
      onChangeMode라는 prop의 값으로 함수를 전달한다.
      */}
      <Header title="React" onChangeMode={() => {
        // alert('Header')
        // mode = 'WELCOME'
        // console.log(mode)
        setMode('WELCOME')
      }}></Header>
      <Nav topics={topics} onChangeMode={id => {
        // alert(id)
        // mode = 'READ'
        // console.log(mode)
        setMode('READ')
        // 선택한 글의 id를 state에 저장하는 함수를 실행한다.
        setId(id)
      }}/>
      {content}

      <ul>
        <li>
          <a href='/create' onClick={
            function (event) {
              event.preventDefault()
              setMode('CREATE')
            }
          }>Create</a>
        </li>
        {/*
        <li>
          <a href='/update'>Update</a>
        </li>
        */}
        {contextControl}
      </ul>

    </div>
  );
}

export default App;

