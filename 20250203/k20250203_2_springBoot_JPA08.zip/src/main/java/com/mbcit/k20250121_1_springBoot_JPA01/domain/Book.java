package com.mbcit.k20250121_1_springBoot_JPA01.domain;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@NoArgsConstructor
@Data
@Entity
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class Book extends BaseEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private String name;
	private String category;
//	private Long authorId; // 제거
//	private Long publisherId; // 제거
	
	@OneToOne
	private BookReviewInfo bookReviewInfo;
	
//	Book 엔티티와 Review 엔티티는 1:N 관계 이므로 @OneToMany 어노테이션으로 설정한다.
	@OneToMany
//	book_reviews라는 중간 테이블이 생성되지 않게 하기 위해서 @JoinColumn 어노테이션을 지정한다.
	@JoinColumn(name = "book_id")
	private List<Review> reviews = new ArrayList<>();
	
//	Book 엔티티와 Publisher 엔티티는 N:1 관계 이므로 @ManyToOne 어노테이션으로 설정한다.
	@ManyToOne
	private Publisher publisher;
	
}












