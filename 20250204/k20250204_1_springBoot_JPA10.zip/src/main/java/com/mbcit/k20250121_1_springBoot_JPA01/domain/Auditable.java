package com.mbcit.k20250121_1_springBoot_JPA01.domain;

import java.time.LocalDateTime;

public interface Auditable {

	void setCreateDate(LocalDateTime createDate);
	void setUpdateDate(LocalDateTime updateDate);
	
}
