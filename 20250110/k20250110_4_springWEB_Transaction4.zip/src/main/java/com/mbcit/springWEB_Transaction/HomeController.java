package com.mbcit.springWEB_Transaction;

import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.mbcit.springWEB_Transaction.dao.TransactionDAO;
import com.mbcit.springWEB_Transaction.service.TransactionService;
import com.mbcit.springWEB_Transaction.vo.CardVO;

@Controller
public class HomeController {
	
	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);

//	컨트롤러에서 외부 트랜잭션을 실행하기 위해서 TicketInsert 클래스 객체를 통해 TransactionDAO 클래스
//	객체에 접근해야 하므로 주석으로 처리한다.
//	private TransactionDAO dao;
//	@Autowired
//	public void setDao(TransactionDAO dao) {
//		this.dao = dao;
//	}
	
//	외부 트랜잭션을 실행하기 위해서 TransactionService 인터페이스 객체를 선언하고 초기화 한다.
	private TransactionService service;
	
//	@Autowired 어노테이션이 설정된 setter 메소드로 servlet-context.xml 설정된 bean으로 초기화 한다.
	@Autowired
	public void setService(TransactionService service) {
		// logger.info("service: {}", service);
		this.service = service;
	}
	
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Locale locale, Model model) {
		logger.info("Welcome home! The client locale is {}.", locale);
		
		Date date = new Date();
		DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG, locale);
		
		String formattedDate = dateFormat.format(date);
		
		model.addAttribute("serverTime", formattedDate );
		
		return "home";
	}

	@RequestMapping("/ticket")
	public String ticket(HttpServletRequest request, Model model) {
		logger.info("HomeController 클래스의 ticket() 메소드 실행");
		return "ticket";
	}
	
	@RequestMapping("/ticketCard")
	public String ticketCard(HttpServletRequest request, Model model, CardVO cardVO) {
		logger.info("HomeController 클래스의 ticketCard() 메소드 실행");
		
		// dao의 buyTicket() 메소드를 바로 실행(내부 트랜잭션)하지 않고 TicketInsert 클래스에서
		// execute() 메소드에서 외부 트랜잭션을 실행한다.
		// dao.buyTicket(cardVO);
		service.execute(cardVO);
		
		return "ticketEnd";
	}
	
	
}







