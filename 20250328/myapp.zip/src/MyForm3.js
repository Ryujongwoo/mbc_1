import React, { useState } from "react";

function MyForm3() {

// 폼에는 입력 필드가 2개 이상인 경우가 많다. 이럴 경우 객체 상태를 이용해서 처리한다.
// useState hook으로 user라는 객체 상태를 만든다.
// user라는 상태는 각각 성, 이름, 이메일을 저장하는 firstName, lastname, email 속성을
// 포함하는 객체이다.
   const [user, setUser] = useState({firstName: '', lastName: '', email: ''}); // 객체 상태
// console.log(user);

// 입력 상자의 내용이 변경되면 값을 저장한다. 객체 상태를 수정한다.
// 수정할 필드의 개수만큼 변경 처리기를 추가하면 여러 필드를 처리할 수 있지만 반복 코드를 작성해야 한다.
// 입력 상자에 name 속성을 추가하고 name 속성 값을 확인하면 값이 변경된 입력 상자를 확인할 수 있다.
  const inputChanged = event => {
    // console.log(event);
    // console.log(event.target);
    // console.log(event.target.name);
    // event.target.name은 값이 변경된 입력 상자의 name 속성 값이고 event.target.value는 값이 변경된
    // 입력 상자에 입력한 값이다.
    // ...user와 같이 스프레드 표기법을 이용하면 반복 코드를 작성하지 않고 처리할 수 있다.
    // 객체 상태의 수정할 속성은 []로 묶어서 표기한다.
    setUser({...user, [event.target.name]: event.target.value});
  }

  const submitHandler = event => {
    event.preventDefault();
    alert(`Hello ${user.firstName}${user.lastName}`);
  }

  return (
    <div align='center'>
      <h1>MyForm3</h1>
      <form onSubmit={submitHandler}>
        <label>
          firstname: <input type="text" name="firstName" value={user.firstName} onChange={inputChanged}/>
        </label><br/>
        <label>
          lastname: <input type="text" name="lastName" value={user.lastName} onChange={inputChanged}/>
        </label><br/>
        <label>
          email: <input type="text" name="email" value={user.email} onChange={inputChanged}/>
        </label><br/>
        <input type="submit" value="눌러봐" />
      </form>
    </div>
  );
}

export default MyForm3;
