package com.mbcit.k20250116_5_springBoot_Lombok;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@SpringBootApplication
public class K202501165SpringBootLombokApplication {

	public static void main(String[] args) {
		SpringApplication.run(K202501165SpringBootLombokApplication.class, args);
		
		Member member = new Member();
		System.out.println(member);
		
		log.info("롬복이 지원하는 로그 출력");
	}

}
