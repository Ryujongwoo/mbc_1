package com.mbcit.inheritance;

//	자식(하위, 서브, 파생) 클래스
//	상속이란 부모 클래스에서 정의한 모든 멤버 변수와 메소드를 자식 클래스에서 물려받는 것을 말한다.
//	자식 클래스는 별도의 선언없이 부모 클래스에서 정의된 모든 기능을 사용할 수 있다.
//	public class 자식클래스이름 extends 부모클래스이름
//	Child 클래스는 Parent 클래스를 상속받아 만든다.
public class Child extends Parent {

	
	
}
