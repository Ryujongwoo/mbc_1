//	자바스크립트는 문자와 문자열을 별도로 구분하지 않고 따옴표로 묶어준다.
console.log('제2외국어를 배운 호랑이가 "야옹" 했습니다.')
console.log("제2외국어를 배운 고양이가 '어흥' 했습니다.")
console.log('제2외국어를 배운 호랑이가 \'야옹\' 했습니다.')
console.log("제2외국어를 배운 고양이가 \"어흥\" 했습니다.")
console.log('============================')

//	'+' 연산자
//	연산자의 한쪽이라도 문자열이 나오면 문자열을 연결하는 문자열 연결 연산자로 사용된다.
console.log('my' + 'love')
console.log('8' + 5)
console.log(8 + '5')
//	연산자 양쪽이 모수 숫자일 경에만 덧셈 연산자로 사용된다.
console.log(8 + 5)
console.log('============================')

//	산술 연산자
//	'+'를 제외한 나머지(*, /, %, -)는 문자열과 숫자를 연산하면 문자열을 숫자로 바꿔서 연산한다.
console.log('8' * 5)
console.log('8' / 5)
console.log('8' % 5)
console.log('8' - 5)

console.log(parseInt('8') + 5) // parseInt(): 정수화 함수
console.log(Number('8') + 5) // Number(): 숫자화 함수

//	자바는 정수와 정수를 나눗셈 연산을 실행하면 결과는 정수가 나온다.
//	파이썬은 '//' 연산자를 사용하면 나눗셈 연산 결과가 정수가 나온다.
//	자바스크립트는 그런거 없다. => 연산 결과를 정수로 얻으려면 함수를 사용해야 한다.
console.log(Math.floor(10 / 3)) // floor(): 버림 함수
console.log(Math.ceil(10 / 3)) // ceil(): 올림 함수
console.log(Math.round(10 / 3)) // round(): 반올림 함수

console.log(8 ** 5) // 거듭제곱 연산자
console.log(Math.pow(8, 5)) // pow(): 거듭제곱 함수
console.log(2 ** 0.5)
console.log(Math.sqrt(2)) // sqrt(): 제곱근 함수
console.log('============================')

//	증감 연산자(++, --)
let count = 1
console.log('count: ' + count)
console.log('count++: ' + count++)
console.log('++count: ' + ++count)
console.log('============================')

//	대입 연산자
let a = 8
let b = 5
console.log(a += b)
console.log(a -= b)
console.log(a *= b)
console.log(a /= b)
console.log(a %= b)
console.log('============================')

//	관계 연산자
console.log(8 > 5)
console.log(8 >= 5)
console.log(8 < 5)
console.log(8 <= 5)
console.log(8 == 5)
console.log(8 != 5)
console.log('============================')

//	관계 연산도 숫자와 문자를 비교하면 숫자로 비교한다.
console.log('8' > 5)
console.log('8' >= 5)
console.log('8' < 5)
console.log('8' <= 5)
console.log('8' == 5)
console.log('8' != 5)
console.log('============================')

//	자바스크립트는 '==='과 '!==' 연산자가 있다.
//	'=='나 '!='는 데이터 타입을 비교하지 않고 값만 비교한다. => 문자도 숫자로 비교한다.
//	'==='와 '!=='는 데이터 타입을 먼저 비교하고 값을 비교한다.
console.log('8' === 8)
console.log('8' !== 8)
console.log('============================')

//	논리 연산자
console.log(true && true)
console.log(true && false)
console.log(false && true)
console.log(false && false)
console.log('============================')

console.log(true || true)
console.log(true || false)
console.log(false || true)
console.log(false || false)
console.log('============================')

console.log(!true)
console.log(!false)
console.log('============================')

//	자바스크립트는 0을 제외한 모든 숫자는 true로 취급하고 0만 false로 취급한다.
console.log(!1)
console.log(!0)
console.log(!5)

