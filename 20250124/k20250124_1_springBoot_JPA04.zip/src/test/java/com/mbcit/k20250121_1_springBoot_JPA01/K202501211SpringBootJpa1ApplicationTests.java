package com.mbcit.k20250121_1_springBoot_JPA01;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class K202501211SpringBootJpa1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
