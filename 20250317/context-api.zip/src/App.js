import './style.css';

// context api는 리액트에서 전역적으로 디자인을 공유할 수 있도록 도와주는 도구이다. => 테마
// 테마 기능을 구현하기 위해서 디자인 코드를 먼저 작성하고 이 디자인 코드를 컴포넌트 전체에
// 적용하기 위해서 context api를 사용한다.

// createContext를 이용해서 context api를 만들고 useContext를 이용해서 context api를 사용하기
// 위해서 import를 해야 한다.
import { createContext, useContext } from 'react';

// 디자인 코드를 만든다.
const themeDefault = { 
  border: '5px solid blue'
};
// 디자인 코드를 이용해서 컨텍스트를 만든다.
const themeContext = createContext(themeDefault);

function Sub1() {
  const theme = useContext(themeContext);
  return (
    // themeContext.Provider 컴포넌트를 이용해 감싸주면 theme가 적용되지 않고 style.css
    // 파일에서 설정한 스타일이 적용된다.
    <themeContext.Provider value={{border: '5px solid green'}}>
      <div style={theme}>
        <h1>Sub1</h1>
        <Sub2></Sub2>
      </div>
    </themeContext.Provider>
  )
}

function Sub2() {
  const theme = useContext(themeContext);
  return (
    <div style={theme}>
      <h1>Sub2</h1>
      <Sub3></Sub3>
    </div>
  )
}

function Sub3() {
  const theme = useContext(themeContext);
  return (
    <div style={theme}>
      <h1>Sub3</h1>
    </div>
  )
}

function App() {
  // 컨텍스트를 사용하기 위해 읽어온다.
  const theme = useContext(themeContext);
  console.log('theme:', theme);
  return (
    <themeContext.Provider value={{border: '5px solid tomato'}}>
      <div className="root" style={theme}>
        <h1>Hello World!</h1>
        <Sub1></Sub1>
      </div>
    </themeContext.Provider>
  );
}

export default App;
