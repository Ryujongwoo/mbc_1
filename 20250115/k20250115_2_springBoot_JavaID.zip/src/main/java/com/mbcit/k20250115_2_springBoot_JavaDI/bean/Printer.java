package com.mbcit.k20250115_2_springBoot_JavaDI.bean;

public interface Printer {

	public abstract void print(String message);
	
}
