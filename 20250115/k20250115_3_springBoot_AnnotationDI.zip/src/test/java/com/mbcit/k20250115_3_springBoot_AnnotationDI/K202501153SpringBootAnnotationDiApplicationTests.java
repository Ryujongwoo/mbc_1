package com.mbcit.k20250115_3_springBoot_AnnotationDI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class K202501153SpringBootAnnotationDiApplicationTests {

	@Test
	void contextLoads() {
	}

}
