CREATE TABLE "SIMPLEBBS" (
    "IDX" NUMBER(*,0) NOT NULL, 
	"NAME" CHAR(20 BYTE) NOT NULL, 
	"TITLE" VARCHAR2(200 BYTE) NOT NULL, 
	"CONTENT" VARCHAR2(2000 BYTE) NOT NULL, 
	CONSTRAINT "SIMPLEBBS_PK" PRIMARY KEY ("IDX")
);

delete from simplebbs;
drop sequence simplebbs_idx_seq;
create sequence simplebbs_idx_seq;

insert into simplebbs (idx, name, title, content) values (simplebbs_idx_seq.nextval, '홍길동', '1등', '1등 입니다.');
insert into simplebbs (idx, name, title, content) values (simplebbs_idx_seq.nextval, '임꺽정', '2등', '2등 입니다.');
insert into simplebbs (idx, name, title, content) values (simplebbs_idx_seq.nextval, '장길산', '3등', '3등 입니다.');
insert into simplebbs (idx, name, title, content) values (simplebbs_idx_seq.nextval, '일지매', '4등', '4등 입니다.');

select * from simplebbs;
select count(*) from simplebbs;
