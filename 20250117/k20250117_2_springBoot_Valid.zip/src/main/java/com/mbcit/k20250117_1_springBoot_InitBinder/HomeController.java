package com.mbcit.k20250117_1_springBoot_InitBinder;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
public class HomeController {

	@RequestMapping("/")
	public @ResponseBody String home() {
		log.info("HomeController 클래스의 home() 메소드 실행");
		return "@NotNull, @NotEmpty, @Size 테스트";
	}
	
	@RequestMapping("/insertForm")
	public String insertForm() {
		log.info("HomeController 클래스의 insertForm() 메소드 실행");
		return "insertForm";
	}
	
	@RequestMapping("/create")
	public String create(@ModelAttribute("vo") @Valid ContentVO contentVO, BindingResult bindingResult) {
		log.info("HomeController 클래스의 create() 메소드 실행");
		log.info("{}", contentVO);
	
		String viewpage = "createDone";
		if (bindingResult.hasErrors()) {
			
			if (bindingResult.getFieldError("writer") != null) {
//				유효성 검사를 수행하는 클래스를 만들어서 사용할 때는 getCode() 메소드로 에러 메시지를 가져오지만
//				유효성을 검사할 커맨드 객체에 @NotNull, @NotEmpty, @Size 어노테이션을 지정해서 유효성을 검사한 
//				에러 메시지는 getDefaultMessage() 메소드로 가져온다.
//				log.info("writer: {}", bindingResult.getFieldError("writer").getCode());
				log.info("writer: {}", bindingResult.getFieldError("writer").getDefaultMessage());
			}
			
			if (bindingResult.getFieldError("content") != null) {
//				log.info("content: {}", bindingResult.getFieldError("content").getCode());
				log.info("content: {}", bindingResult.getFieldError("content").getDefaultMessage());
			}
			
			viewpage = "insertForm";
		}
		
		return viewpage;
	}
	
//	@InitBinder
//	public void initBinder(WebDataBinder binder) {
//		log.info("HomeController 클래스의 initBinder() 메소드 실행");
//		binder.setValidator(new ContentValidator());
//	}
	
}









