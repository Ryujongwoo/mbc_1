package com.mbcit.springBootBoard.dto;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@NoArgsConstructor // 기본 생성자 자동완성
@AllArgsConstructor // 모든 멤버를 사용하는 생성자 자동완성
//	@RequiredArgsConstructor // 특정 멤버(@NonNull 어노테이션을 설정한)를 사용하는 생성자 자동완성
//	@Getter // 모든 멤버의 getter 메소드 자동완성
//	@Setter // 모든 멤버의 setter 메소드 자동완성
//	@ToString // toString() 메소드 자동완성
//	@EqualsAndHashCode // equals(), hashCode() 메소드 자동완성
@Data // 모든 멤버의 getter, setter, toString(), equals(), hashCode() 메소드 자동완성
//	@Data 어노테이션은 실무에서는 너무 무겁고 객체의 안전성을 떨어뜨리므로 사용을 지양한다.
//	글 1건을 기억하는 클래스
public class ArticleForm {

//	@RequiredArgsConstructor 어노테이션을 사용하려면 생성자를 자동완성 하려는 필드에 @NonNull
//	어노테이션을 붙여준다.
//	@NonNull 어노테이션을 붙여준 필드는 null 값을 허용하지 않는다.
//	@NonNull
	private String title;
	private String content;
	
}











