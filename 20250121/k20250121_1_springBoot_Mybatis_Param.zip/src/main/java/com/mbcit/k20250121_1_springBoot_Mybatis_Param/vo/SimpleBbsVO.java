package com.mbcit.k20250121_1_springBoot_Mybatis_Param.vo;

import lombok.Data;

@Data
public class SimpleBbsVO {

	private int idx;
	private String name;
	private String title;
	private String content;
	
}
