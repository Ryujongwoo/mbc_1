package com.mbcit.k20250121_2_springBoot_Mybatis_ResultNum.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.mbcit.k20250121_2_springBoot_Mybatis_ResultNum.vo.SimpleBbsVO;

@Mapper
public interface SimpleBbsDAO {

//	Mybatis에서 sql 명령이 실행 성공하면 다음과 같은 리턴 값을 얻을 수 있다.
//	select: select 명령 실행 결과
//	insert: 1
//	delete: delete된 행(row, record)의 개수
//	update: update된 행의 개수
	
//	void insert(String name, String title, String content);
	int insert(String name, String title, String content);
	List<SimpleBbsVO> selectList();
	SimpleBbsVO selectByIdx(int idx);
//	void update(SimpleBbsVO simpleBbsVO);
	int update(SimpleBbsVO simpleBbsVO);
//	void delete(@Param("id") int idx);
	int delete(@Param("id") int idx);
	int selectCount();
	
}
