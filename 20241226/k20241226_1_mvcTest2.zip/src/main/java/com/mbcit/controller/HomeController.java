package com.mbcit.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//	@WebServlet 어노테이션의 인수로 특정 요청을 써주면 그 요청이 들어왔을 때만 컨트롤러의 메소드가 자동으로
//	실행되므로 요청이 들어왔을 때 마다 처리할 컨트롤러를 일일히 만들어야 하는 문제점(?)이 발생된다.
//	@WebServlet 어노테이션의 인수로 와일드카드 문자(*)를 사용하는 확장명 패턴의 요청을 받을 수 있다.
//	확장명 패턴 방식으로 요청받을 때 "/"를 붙이지 않는다.
//	확장명 패턴 방식으로 요청을 받으면 파일명은 상관없이 동일한 확장명으로 요청되면 컨트롤러의 메소드가
//	자동으로 실행된다.
//	확장명을 ".jsp"가 아닌 다른 이름을 사용하면 어떤 페이지가 호출되나 숨길 수 있다. => 보안성 향상
@WebServlet("*.nhn")
public class HomeController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public HomeController() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		System.out.println("HomeController에 get 방식으로 요청됨");
		actionDo(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		System.out.println("HomeController에 post 방식으로 요청됨");
		actionDo(request, response);
	}
	
	protected void actionDo(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		System.out.println("HomeController의 actionDo() 메소드 실행");
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html; charset=UTF-8");
		
		// 컨트롤러로 넘어오는 데이터를 받는다.
		String name = request.getParameter("name");
		System.out.println(name);
		
		// 컨트롤러에서 viewpage로 전송할 데이터는 request 영역에 저장한다.
		request.setAttribute("name", name);
		
		// 요청에 따른 viewpage를 결정한다.
		// getRequestURI() 메소드로 주소 창에 요청된 contextPath와 요청을 받아온다.
		String url = request.getRequestURI();
		// System.out.println(url); // /k20241226_1_mvcTest2/index.nhn
		// getContextPath() 메소드로 주소 창에 요청된 contextPath를 받아온다.
		String contextPath = request.getContextPath();
		// System.out.println(contextPath); // /k20241226_1_mvcTest2
		// System.out.println(contextPath.length()); // 21
		// String context = url.substring(contextPath.length());
		String context = url.substring(contextPath.length() + 1, url.length() - 4);
		// System.out.println(context);
		
		String viewpage = "/WEB-INF/"; // /WEB-INF/
		switch (context) {
			case "index":
				viewpage += "index"; // /WEB-INF/index
				break;
			case "hello":
				viewpage += "hello";
				break;
		}
		viewpage += ".jsp"; // /WEB-INF/index.jsp
		// System.out.println(viewpage);
		
		// 요청에 따른 viewpage를 호출한다.
		RequestDispatcher dispatcher = request.getRequestDispatcher(viewpage);
		dispatcher.forward(request, response);
	}

}
















