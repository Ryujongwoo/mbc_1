package com.mbcit.k20250121_1_springBoot_JPA01.domain;

import java.time.LocalDateTime;

import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@NoArgsConstructor
@Data
@Entity
//	@EntityListeners 어노테이션으로 사용할 엔티티 리스너를 지정한다.
//	@EntityListeners(value = MyEntityListener.class)
//	@EntityListeners(value = AuditingEntityListener.class)
//	Auditable 인터페이스의 추상 메소드는 override를 하지 않아도 롬복이 자동으로 처리한다.
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class Book extends BaseEntity /* implements Auditable */ {

	@Id
	@GeneratedValue
	private Long id;
	
	private String name;
	private String author;
//	@CreatedDate
//	private LocalDateTime createDate;
//	@LastModifiedDate
//	private LocalDateTime updateDate;
	
//	엔티티 리스너를 이용해서 @PrePersist, @PreUpdate 엔티티 이벤트를 구현할것이므로 기존에 사용하던
//	엔티티 이벤트 메소드는 제거한다.
//	@PrePersist // 엔티티 이벤트
//	public void prePersist() {
//		System.out.println("Book 엔티티의 prePersist() 메소드 실행됨");
//		createDate = LocalDateTime.now();
//		updateDate = LocalDateTime.now();
//	}
	
//	@PreUpdate // 엔티티 이벤트
//	public void preUpdate() {
//		System.out.println("Book 엔티티의 preUpdate() 메소드 실행됨");
//		updateDate = LocalDateTime.now();
//	}
	
}












