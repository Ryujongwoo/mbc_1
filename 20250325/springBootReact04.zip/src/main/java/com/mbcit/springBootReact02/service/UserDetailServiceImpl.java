package com.mbcit.springBootReact02.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.User.UserBuilder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.mbcit.springBootReact02.domain.User;
import com.mbcit.springBootReact02.domain.UserRepository;

//	UserDetailsService 인터페이스를 구현받아 스프링 시큐리티 사용자 인증과 권한 부여에 사용할 
//	서비스 클래스를 만든다.
@Service
public class UserDetailServiceImpl implements UserDetailsService {

//	스프링 시큐리티가 인증을 처리할 때 데이터베이스에서 사용자를 검색하는데 필요한 UserRepository
//	인터페이스 객체를 UserDetailServiceImpl 클래스에 주입한다.
	@Autowired
	private UserRepository userRepository;
	
//	UserDetailsService 인터페이스를 구현하면 Override 시켜서 사용해야 하는 loadUserByUsername()
//	메소드는 인증에 필요한 UserDetails 인터페이스 객체를 리턴한다.
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		System.out.println("UserDetailServiceImpl 클래스의 loadUserByUsername() 메소드 실행");
//		로그인 창에 입력된 사용자를 User 테이블에서 검색한다.
		User user = userRepository.findByUsername(username);
		
//		UserBuilder 클래스로 인증할 사용자 객체를 만든다.
		UserBuilder builder = null;
		if (user != null) {
			builder = org.springframework.security.core.userdetails.User.withUsername(username);
			builder.password(user.getPassword());
			builder.roles(user.getRole());
			System.out.println("사용자를 찾았습니다.");
		} else {
			System.out.println("사용자를 찾지못했습니다.");
			throw new UsernameNotFoundException("User not found");
		}
		return builder.build();
	}

}












