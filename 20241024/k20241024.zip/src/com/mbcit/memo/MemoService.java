package com.mbcit.memo;

import java.util.ArrayList;
import java.util.Scanner;

//	데이터를 테이블에 저장, 수정, 삭제 및 조회 작업을 실행하기 전에 필요한 전처리 작업을
//	실행하는 클래스 => 비즈니스 로직을 작성하는 클래스
public class MemoService {

//	데이터를 입력받아 DAO 클래스로 넘겨주는 메소드
	public static void insertMemo() {
		System.out.println("MemoService 클래스의 insertMemo() 메소드 실행");
		
//		전처리
		Scanner scanner = new Scanner(System.in);
		System.out.println("테이블에 저장된 데이터 입력");
		System.out.print("이름: ");
		String name = scanner.nextLine().trim();
		System.out.print("비밀번호: ");
		String password = scanner.nextLine().trim();
		System.out.print("메모: ");
		String memo = scanner.nextLine().trim();
		
//		입력받은 데이터를 MemoVO 클래스 객체를 만들어 저장한다.
		MemoVO vo = new MemoVO();
		vo.setName(name);
		vo.setPassword(password);
		vo.setMemo(memo);
//		System.out.println(vo);
		
//		입력받은 데이터가 저장된 MemoVO 클래스 객체를 넘겨서 MemoDAO 클래스에서 테이블에 저장하는
//		메소드를 호출한다.
		boolean result = MemoDAO.insertMemo(vo);
		
//		후처리
		if (result) {
			System.out.println(name + "님의 글이 정상적으로 저장되었습니다.");
		} else {
			System.out.println("sql 명령이 올바르게 실행되지 않았습니다.");
		}
	}

//	테이블에 글 목록을 최신글 부터 얻어와서 콘솔에 출력하는 메소드
	public static void selectMemo() {
		System.out.println("MemoService 클래스의 selectMemo() 메소드 실행");
		
//		테이블에 저장된 글 목록을 글번호(idx)의 내림차순(최신글수)으로 얻어오는 메소드
		ArrayList<MemoVO> list = MemoDAO.selectMemo();
		
//		후처리
//		얻어온 글 목록을 콘솔에 출력한다.
		if (list == null || list.size() == 0) {
			System.out.println("테이블에 저장된 글이 없습니다.");
		} else {
			for (MemoVO vo : list) {
				System.out.println(vo);
			}
		}
	}

//	삭제할 글번호를 넘겨받아 테이블의 글을 삭제하는 메소드를 호출하는 메소드
	public static void deleteMemo() {
		System.out.println("MemoService 클래스의 deleteMemo() 메소드 실행");
		
//		전처리
//		삭제할 글번호를 입력받는다.
		Scanner scanner = new Scanner(System.in);
		System.out.print("삭제할 글번호 입력: ");
		int idx = scanner.nextInt();
		
//		테이블에서 삭제할 글 1건을 얻어오는 MemoDAO 클래스의 메소드를 호출한다.
		MemoVO original = MemoDAO.selectByIdx(idx);
		
//		삭제할 글이 존재하면 얻어온 삭제할 글을 콘솔에 출력하고 존재하지 않으면 존재하지 않는다는
//		메시지를 출력한다,
		if (original != null) { // 삭제할 글이 존재하는가?
			System.out.println("삭제할 글을 확인하세요.");
			System.out.println(original);
			
//			글을 삭제하기 위해 비밀번호를 입력받는다.
			System.out.print("비밀번호: ");
			scanner.nextLine(); // 키보드 버퍼를 비운다.
			String password = scanner.nextLine().trim();
			
//			삭제하기 위해 입력한 비밀번호(password)와 삭제할 글의 비밀번호(original.getPassword())를
//			비교한다.
			if (password.equals(original.getPassword())) {
//				비밀번호가 일치하면 MemoDAO 클래스의 글 1건을 삭제하는 메소드를 호출한다.
				MemoDAO.deleteMemo(idx);
				System.out.println(idx + "번 글 삭제완료!!!");
			} else {
				System.out.println("비밀번호가 일치하지 않습니다.");
			}
		} else {
			System.out.println(idx + "번 글은 존재하지 않습니다.");
		}
		
		
		
	}
	
}
























