function passwordCheckFunction() {
	let password = $('#password').val()
	let password2 = $('#password2').val()
	
	if (password == password2) {
		$('#passwordCheckMessage').html('비밀번호가 일치합니다.')
	} else {
		$('#passwordCheckMessage').html('비밀번호가 일치하지 않습니다.')
	}
}

//	===============================================================================================
//	jQuery AJAX
//	===============================================================================================

//	회원 가입을 실행하는 함수
function register() {
//	console.log('register()')
//	index.jsp에서 테이블에 저장할 데이터를 얻어온다.
	let id = $('#id').val()
	let password = $('#password').val()
	let password2 = $('#password2').val()
	let name = $('#name').val()
	let age = $('#age').val()
	let gender = $('input[name=gender]:checked').val()
	let email = $('#email').val()
//	console.log(id, password, password2, name, age, gender, email)

//	jQuery AJAX => $.ajax({ ... })
	$.ajax({
		/*
		// GET 방식 요청
		type: 'GET', 
		// 쿼리 스트링을 사용한 서블릿 호출과 데이터 전송
		url: './Register?id=' + id + '&password=' + password + '&password2=' + password2 + '&name=' + name +
				'&age=' + age + '&gender=' + gender + '&email=' + email
		*/
		
		// POST 방식 요청
		type: 'POST',
		// 서블릿을 호출하고 data를 사용해서 데이터 전송 
		url: './Register',
		data: {
			// key: value
			id: id,
			password: password,
			password2: password2,
			name: name,
			age: age,
			gender: gender,
			email: email
		},
		
		// AJAX 요청이 성공하면 실행할 콜백 함수 지정
		// AJAX 요성이 성공하면 response.getWriter().write(문자열)의 문자열이 콜백 함수의 인수로 넘어온다.
		success: function (response) {
			// alert('요청 성공')
			// console.log(response)
			// 다음 데이터를 입력받기 위해 텍스트 상자의 내용을 지운다.
			$('#id').val('')
			$('#password').val('')
			$('#password2').val('')
			$('#name').val('')
			$('#age').val('')
			$('#email').val('')
			$('#id').focus()
			
			// 서블릿 응답에 따른 메시지를 출력한다.
			switch (response) {
				case '1':
					// alert('에러: 모든 내용을 입력하세요.')
					$('#errorMessage').html('에러: 모든 내용을 입력하세요.')
					$('#messageType').html('에러 메시지')
					$('#messageContent').html('모든 내용을 입력하세요.')
					$('#messageCheck').addClass('bg-danger text-white')
					break;
				case '2':
					// alert('에러: 비밀번호가 일치하지 않습니다.')
					$('#errorMessage').html('에러: 비밀번호가 일치하지 않습니다.')
					$('#messageType').html('에러 메시지')
					$('#messageContent').html('비밀번호가 일치하지 않습니다.')
					$('#messageCheck').addClass('bg-dark text-white')
					break;
				case '3':
					// alert('회원 가입에 성공했습니다.')
					$('#errorMessage').html('성공: 회원 가입에 성공했습니다.')
					$('#messageType').html('성공 메시지')
					$('#messageContent').html('회원 가입에 성공했습니다.')
					$('#messageCheck').addClass('bg-success text-white')
					break;
				case '4':
					// alert('에러: 이미 존재하는 id 입니다.')
					$('#errorMessage').html('에러: 이미 존재하는 id 입니다.')
					$('#messageType').html('에러 메시지')
					$('#messageContent').html('이미 존재하는 id 입니다.')
					$('#messageCheck').addClass('bg-warning text-white')
					break;
			}
			// 모달 창을 띄운다.
			$('#messageModal').modal('show')
		},
		// AJAX 요청이 실패하면 실행할 콜백 함수 지정
		// AJAX 요청이 실패하면 에러 정보가 콜백 함수의 인수로 넘어온다.
		error: error => alert('요청 실패: ' + error.status)
	})
}

//	아이디 중복 검사를 실행하는 함수
function registerCheck() {
//	console.log('registerCheck()')
//	중복 검사할 id를 얻어온다.
	let id = $('#id').val()
//	console.log(id)

	$.ajax({
		/*
		type: 'GET',
		url: './RegisterCheck?id=' + id
		*/
		type: 'POST',
		url: './RegisterCheck',
		data: {
			id: id
		},
		success: response => {
			switch (response) {
				case '1':
					// alert('에러: id를 입력하고 중복 검사 버튼을 클릭하세요.')
					$('#errorMessage').html('에러: id를 입력하고 중복 검사 버튼을 클릭하세요.')
					$('#messageType').html('에러 메시지')
					$('#messageContent').html('id를 입력하고 중복 검사 버튼을 클릭하세요.')
					$('#messageCheck').addClass('bg-danger text-white')
					break;
				case '2':
					// alert('에러: 사용중인 id 입니다.')
					$('#errorMessage').html('에러: 사용중인 id 입니다.')
					$('#messageType').html('에러 메시지')
					$('#messageContent').html('사용중인 id 입니다.')
					$('#messageCheck').addClass('bg-dark text-white')
					break;
				case '3':
					// alert('사용 가능한 id 입니다.')
					$('#errorMessage').html('성공: 사용 가능한 id 입니다.')
					$('#messageType').html('성공 메시지')
					$('#messageContent').html(id + '는(은) 사용 가능한 id 입니다.')
					$('#messageCheck').addClass('bg-success text-white')
					break;
			}
			$('#messageModal').modal('show')
		},
		error: error => alert('요청 실패: ' + error.status)
	})
}


















