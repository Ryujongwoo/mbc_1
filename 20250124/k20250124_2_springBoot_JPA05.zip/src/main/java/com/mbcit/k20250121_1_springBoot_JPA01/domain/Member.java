package com.mbcit.k20250121_1_springBoot_JPA01.domain;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Index;
import javax.persistence.PostLoad;
import javax.persistence.PostPersist;
import javax.persistence.PostRemove;
import javax.persistence.PostUpdate;
import javax.persistence.PrePersist;
import javax.persistence.PreRemove;
import javax.persistence.PreUpdate;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.persistence.UniqueConstraint;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@NoArgsConstructor
@AllArgsConstructor
@RequiredArgsConstructor
@Data
@Builder
@Entity
@SequenceGenerator(name = "seq_generator", sequenceName = "member_id_seq", initialValue = 1, allocationSize = 1)
//	@EntityListeners(value = {MyEntityListener.class, MemberHistoryListener.class})
//	기본 리스너가 동작되게 하려면 @EntityListeners 어노테이션에 AuditingEntityListener를 지정한다.
@EntityListeners(value = { /* AuditingEntityListener.class, */MemberHistoryListener.class})
//	부모 클래스에서 상속받은 멤버를 포함해서 toString(), equals(), hashCode() 메소드를 lombok으로
//	자동 생성하려면 callSuper 속성 값을 true로 지정한다.
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class Member extends BaseEntity /* implements Auditable */ {

	@Id
//	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_generator")
	private Long id;
	
	@NonNull
	private String name;
	@NonNull
	private String email;
	/*
//	@CreatedDate 어노테이션은 최초로 저장될 때만 동작한다.
	@CreatedDate // 기본 리스너를 지정한다.
	private LocalDateTime createDate;
//	@LastModifiedDate 어노테이션은 저장될 때마다 동작한다.
	@LastModifiedDate // 기본 리스너를 지정한다.
	private LocalDateTime updateDate;
	*/
	
	/*
	@PrePersist
	public void prePersist() {
		System.out.println("prePersist() 메소드가 실행됨");
		createDate = LocalDateTime.now();
		updateDate = LocalDateTime.now();
	}
	
	@PostPersist
	public void postPersist() {
		System.out.println("postPersist() 메소드가 실행됨");
	}
	
	@PostLoad
	public void postLoad() {
		System.out.println("postLoad() 메소드가 실행됨");
	}
	
	@PreUpdate
	public void preUpdate() {
		System.out.println("preUpdate() 메소드가 실행됨");
		updateDate = LocalDateTime.now();
	}
	
	@PostUpdate
	public void postUpdate() {
		System.out.println("postUpdate() 메소드가 실행됨");
	}
	
	@PreRemove
	public void preRemove() {
		System.out.println("preRemove() 메소드가 실행됨");
	}
	
	@PostRemove
	public void postRemove() {
		System.out.println("postRemove() 메소드가 실행됨");
	}
	*/
	
}




















