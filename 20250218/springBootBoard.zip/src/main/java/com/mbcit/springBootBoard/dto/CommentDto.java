package com.mbcit.springBootBoard.dto;

import com.mbcit.springBootBoard.entity.Comment;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.extern.slf4j.Slf4j;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
@Slf4j
public class CommentDto { // 답변글 1건을 기억하는 클래스

	private Long id;
	private String nickname;
	private String body;
	private Long articleId;
	
//	Comment 엔티티 객체를 CommentDto 클래스 객체로 변환해서 리턴하는 메소드
	public static CommentDto createCommentDto(Comment comment) {
		log.info("CommentDto의 createCommentDto() 메소드 실행");
//		log.info("comment: " + comment);
		return new CommentDto(
			comment.getId(), comment.getNickname(), comment.getBody(), comment.getArticle().getId()
		);
	}
	
}


















