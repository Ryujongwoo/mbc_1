package com.mbcit.k20250121_1_springBoot_JPA01.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mbcit.k20250121_1_springBoot_JPA01.domain.Relation;

public interface RelationRepository extends JpaRepository<Relation, Long> {

	
	
}
