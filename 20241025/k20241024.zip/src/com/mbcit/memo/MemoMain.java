package com.mbcit.memo;

import java.util.Scanner;

public class MemoMain {

	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		int menu = 0;
		
		while (menu != 5) {
			do {
				System.out.println("============================================");
				System.out.println(" 1.입력  2.목록보기  3.수정  4.삭제  5.종료 ");
				System.out.println("============================================");
				System.out.print("원하는 메뉴를 입력하고 엔터키를 누르세요: ");
				menu = scanner.nextInt();
			} while (menu < 1 || menu > 5);
			
			switch (menu) {
				case 1:
//					테이블에 저장할 데이터를 입력받아 DAO 클래스로 넘겨주는 메소드를 호출한다.	
					MemoService.insertMemo();
					break;
				case 2:
//					테이블에 저장된 글 목록을 최신글 부터 DAO 클래스에서 얻어오는 메소드를 호출한다.
					MemoService.selectMemo();
					break;
				case 3:
//					수정할 글번호와 내용을 입력받아 DAO 클래스로 넘겨주는 메소드를 호출한다.
					MemoService.updateMemo();
					break;
				case 4:
//					삭제할 글번호를 입력받아 DAO 클래스로 넘겨주는 메소드를 호출한다.
					MemoService.deleteMemo();
					break;
			}
		}
		System.out.println("프로그램을 종료합니다. 바이바이~~~~~");
		
	}

}











