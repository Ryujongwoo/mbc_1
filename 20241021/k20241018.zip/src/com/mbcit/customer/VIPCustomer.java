package com.mbcit.customer;

//	자식 클래스
//	VIP 고객 정보를 기억하는 클래스
public class VIPCustomer extends Customer {

//	일반 고객 정보에는 없고 VIP 고객 정보에만 있을 멤버 변수를 선언한다.
	private int agentID; // 1:1 상담원 ID
	private double salesRatio; // 추가 할인 비율
	
//	기본 생성자에서 멤버 변수 초기화
//	고객 등급은 VIP로 보너스 포인트 적립 비율은 5%로 추가 할인 비율 10%로 초기화 시킨다.
	public VIPCustomer() {
//		customerGrade = "VIP"; // 에러
//		bonusRatio = 0.05; // 에러
//		상속받은 private 권한으로 설정된 멤버 변수에 상속받은 setter 메소드로 VIP 고객 정보를 넣는다.
		setCustomerGrade("VIP");
		setBonusRatio(0.05);
		salesRatio = 0.1;
	}
	
//	getters & setters
	public int getAgentID() {
		return agentID;
	}
	public void setAgentID(int agentID) {
		this.agentID = agentID;
	}
	public double getSalesRatio() {
		return salesRatio;
	}
	public void setSalesRatio(double salesRatio) {
		this.salesRatio = salesRatio;
	}
	
	
//	toString() 메소드 override
	@Override
	public String toString() {
		return super.toString() + ", VIPCustomer [agentID=" + agentID + ", salesRatio=" + salesRatio + "]";
	}

//	구매 금액을 인수로 넘겨받아 실제 구매 금액을 계산해서 리턴하는 메소드
	public int calcSales(int price) {
//		return (int) (price * salesRatio); // 추가 할인 금액
		return (int) (price * (1 - salesRatio)); // 실제 구매 금액
	}

//	구매 금액을 인수로 넘겨받아 실제 구매 금액에 따른 보너스 포인트를 계산해서 리턴하는 메소드
	@Override
	public int calcBonus(int price) {
		return (int) (calcSales(price) * getBonusRatio());
	}
	
}
