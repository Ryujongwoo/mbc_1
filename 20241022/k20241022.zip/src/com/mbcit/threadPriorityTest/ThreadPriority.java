package com.mbcit.threadPriorityTest;

public class ThreadPriority extends Thread {

	public ThreadPriority() { }
//	Thread 클래스 객체가 생성될 때 스레드의 이름을 지정하는 생성자
	public ThreadPriority(String name) {
//		부모(Thread) 클래스의 생성자를 호출해서 스레드에 이름을 지정할 수 있다.
		super(name);
	}
	
	
	@Override
	public void run() {
		
//		현재 스레드의 객체를 얻어온다.
		Thread thread = Thread.currentThread();
		
//		setName() 메소드로 스레드의 이름을 지정할 수 있다.
//		Thread 클래스 객체에 현재 스레드의 객체를 얻어온 후 이름을 지정하면 이름이 모두 같아진다.
//		thread.setName("스레드 이름이 같아진다.");
		
		int sum = 0;
		for (int i = 1; i <= 1000000; i++) {
			sum += i;
		}
		
//		getName() 메소드로 스레드의 이름을 얻어올 수 있다.
//		getPriority() 메소드로 스레드의 우선순위를 얻어올 수 있다.
		System.out.println(thread.getName() + " 우선순위: " + thread.getPriority());
		
	}


	
}
