package com.mbcit.k20250121_1_springBoot_JPA01.repository;

import java.util.List;
import java.util.Map;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.mbcit.k20250121_1_springBoot_JPA01.domain.Member;

public interface MemberRepository extends JpaRepository<Member, Long> {

	@Query(value = "select * from member2 limit 1;", nativeQuery = true)
	Map<String, Object> findRecord();

//	JpaRepository 인터페이스 지원하지 않는 쿼리 메소드를 정의한다.
//	findById() 메소드와 유사하게 다른 필드를 검색하는 메소드를 만들려면 Id 대신 다른 필드의 이름이
//	맨 뒤에 사용되는 추상 메소드를 만들어서 사용하면 된다.
//	중복되는 이름이 없을 경우 리턴되는 객체가 1개 이므로 Member를 리턴 타입으로 사용한다.
//	Member findByName(String name);
//	중복되는 이름이 있을 경우 리턴되는 객체가 여러개 이므로 List<Member>를 리턴 타입으로 사용한다.
	List<Member> findByName(String name);
	
	List<Member> findByEmail(String email);
	
}
