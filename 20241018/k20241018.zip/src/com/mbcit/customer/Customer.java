package com.mbcit.customer;

//	부모 클래스
//	일반 고객 정보를 기억하는 클래스
public class Customer {

//	모든 고객 정보를 기억하는 멤버 변수
	private int customerID; // 고객 ID
	private String customerName; // 고객 이름
	private String customerGrade; // 고객 등급
	private int bonusPoint; // 보너스 포인트
	private double bonusRatio; // 보너스 포인트 적립 비율
	
//	기본 생성자에서 멤버 변수 초기화
//	고객 등급은 SILVER로 보너스 포인트 적립 비율은 1%로 초기화 시킨다.
	public Customer() {
		
	}
	
//	getters & setters
	
//	toString() 메소드 override
	
//	회원 정보를 리턴하는 메소드
//	이몽룡님의 등급은 SILVER이며, 보너스 포인트는 1,000점 입니다.
	public String showCustomerInfo() {
		return null;
	}
	
//	구매 금액을 인수로 넘겨받아 보너스 포인트를 계산해서 리턴하는 메소드
	public int calcBonus(int price) {
		return 0;
	}
	
//	구매 금액을 인수로 넘겨받아 누적 보너스 포인트를 계산해서 리턴하는 메소드
	public int calcPrice(int price) {
		return 0;
	}
	
}









