/*
일반 함수의 형식
function 함수이름([인수, ...]) {
	함수가 실행항 문장
	...
	[retuen 값]
}
*/

function printHello() {
	console.log('Hello')
}

printHello() // 함수 호출
console.log('============================')

//	자바스크립트는 함수의 오버로딩을 지원하지 않고 인수의 개수가 달라도 상관없다.
function log(message) {
	console.log(message)
}

//	자바스크립트는 파이썬과 같이 같은 이름의 함수를 다시 선언하면 앞의 함수가 무시된다.
function log() {
	console.log('Hi~~~~~~~~~~~~~~~~~2')
}

log('Hi~~~~~~~~~~~~~~~~~')
log()
console.log('============================')

//	함수의 인수로 객체를 받을 수 있다.
const hong = {
	name: '홍길동',
	age: 20
}

console.log(hong)
console.log(hong.name)
console.log(hong.age)

function setName(obj, name) {
	obj.name = name
}

setName(hong, '임꺽정')
console.log(hong)
console.log('============================')

//	디폴트 인수 => ES6 추가
//	디폴트 인수는 기본값을 가지는 인수를 말한다.
//	from에 데이터가 넘어오면 넘어온 데이터로 함수를 실행하고 데이터가 넘어오지 않으면 디폴트 인수로 지정된
//	'수신인 없음'을 from에 넣고 함수를 실행한다.

function showMessage(message, from = '수신인 없음') {
	console.log(message + ' by ' + from)
}

showMessage('hello', '홍길동')
showMessage('hello')
showMessage('hello', '임꺽정', 20)

//	ES5
function showMessage2(message, from) {
	if (from == undefined) {
		from = '수신인 없음'
	}
	console.log(message + ' by ' + from)
}
showMessage2('hello', '홍길동')
showMessage2('hello')
showMessage2('hello', '임꺽정', 20)
console.log('============================')

//	가변 인수 => ES6 추가 => rest
//	자바스크립트는 자바와 같이 '...'를 붙여서 가변 인수를 만들어 사용한다. => 파이썬은 인수 앞에 '*'을 붙인다.
//	가변 인수는 인수 목록의 맨 마지막에 딱 한 번만 사용할 수 있다.

function printAll(...args) {
	console.log(typeof args)
	console.log(args, args.length)
	
//	일반 for
	for (let i = 0; i < args.length; i++) {
		console.log(args[i])
	}
	
//	향상된 for - 1
//	of 뒤의 배열에 저장된 데이터가 변수에 저장되서 반복한다.
	for (let arg of args) { // for arg in args:
		console.log(arg)
	}
	
//	향상된 for - 2
//	in 뒤의 배열의 크기에 따른 인덱스 값이 변수에 저장되서 반복한다.
	for (let i in args) { // for i in range(len(args)):
		console.log(args[i])
	}
}

printAll('홍길동')
console.log('============================')
printAll('홍길동', '임꺽정')
console.log('============================')
printAll('홍길동', '임꺽정', '장길산')
console.log('============================')
printAll('홍길동', '임꺽정', '장길산', '일지매')
console.log('============================')

//	익명 함수 => 이름이 없는 함수
//	자바스크립트는 변수에 함수를 할당할 수 있으므로 익명으로 만든 함수를 변수에 할당해서 사용할 수 있다.
//	변수 이름이 함수 이름처럼 사용된다. => 1급 함수

const print = function () {
	console.log('print')
}

//	익명 함수를 할당한 변수를 함수 이름처럼 사용해서 변수에 할당된 익명 함수를 실행한다.
print()

//	함수가 할당된 변수를 다른 변수에 대입하면 다른 변수를 함수처럼 사용할 수 있다.
const printAgain = print
printAgain()

//	변수에는 익명 함수와 일반 함수를 모두 할당할 수 있다.
function sum(a, b) {
	return a + b
}
console.log(sum(8, 5))

//	함수의 인수로 함수를 받을 수 있다.
//	데이터(a, b)와 데이터를 처리할 함수(func)를 인수로 넘겨받는 함수
function total(a, b, func) {
	console.log(func(a, b))
}
total(5, 7, sum)
console.log('============================')

total(18, 15, function (a, b) {
	return a + b
})

total(18, 15, function (a, b) {
	return a - b
})
console.log('============================')

//	callback 함수
//	callback 함수는 코드를 통해서 명시적으로 호출되는 함수가 아니라, 개발자는 함수를 등록하기만 하고
//	어떤 상황(이벤트)이 발생되거나 특정 시점에 도달했을 때 시스템에서 호출(자동으로 실행)하는 함수를
//	말한다. => 익명 함수가 callback을 구현할 때 주로 사용된다.

const printYes = function () {
	console.log('yes')
}

const printNo = function () {
	console.log('no')
}

function loveQuiz(answer, yes, no) {
	if (answer == '사랑해') {
		yes()
	} else {
		no()
	}
}

//	함수를 호출할 때 처리할 데이터와 그 데이터를 처리할 함수까지 전달한다.
loveQuiz('사랑해', printYes, printNo)
loveQuiz('싫어해',
	function () {
		console.log('yes')
	},
	function () {
		console.log('no')
	}
)
loveQuiz('싫어해', () => console.log('yes'), () => console.log('no')) // 화살표 함수
	
console.log('============================')

//	화살표 함수(arrow function)

//	일반 함수
function func1() {
	console.log('func1() 실행')
}
func1()

//	일반 익명 함수
const func2 = function () {
	console.log('func2() 실행')
}
func2()

//	익명 함수를 화살표 함수로 만들려면 function을 생략하고 ')'와 '{' 사이에 화살표(=>)를 입력한다.
const func3 = () => {
	console.log('func3() 실행')
}
func3()

//	화살표 함수가 실행할 문장이 {} 블록에 딱 1문장일 경우 {}를 생략할 수 있다.
const func4 = () => console.log('func4() 실행')
func4()
console.log('============================')

function func5(name) {
	console.log(`${name}님 안녕하세요`)
}
func5('홍길동')

const func6 = function (name) {
	console.log(`${name}님 안녕하세요`)
}
func6('임꺽정')

const func7 = (name) => {
	console.log(`${name}님 안녕하세요`)
}
func7('장길산')

const func8 = (name) => console.log(`${name}님 안녕하세요`)
func8('일지매')

//	화살표 함수의 인수의 개수가 1개일 경우 인수를 감싸는 ()도 생략 가능하다.
const func9 = name => console.log(`${name}님 안녕하세요`)
func9('손오공')
console.log('============================')

function func10(name) {
	return name
}
console.log(`${func10('홍길동')}님 안녕하세요`)

const func11 = function (name) {
	return name
}
console.log(`${func11('임꺽정')}님 안녕하세요`)

const func12 = (name) => {
	return name
}
console.log(`${func12('장길산')}님 안녕하세요`)

const func13 = name => {
	return name
}
console.log(`${func13('일지매')}님 안녕하세요`)

//	화살표 함수가 실행할 문장이 {} 블록에 딱 1문장일 경우 {}를 생략할 수 있는데 하필 그 1문장이 return문 일 경우
//	무조건 return을 삭제한다.
const func14 = name => name
console.log(`${func14('손오공')}님 안녕하세요`)

console.log('============================');

//	자동 실행 함수
//	자동 실행 함수는 함수 전체를 ()로 묶은 후 ')' 뒤에 ()를 붙여서 만든다.

(
	function hello() {
		console.log('자동 실행 함수가 실행됩니다.')
	}
)()

//	자동 실행 함수는 일반 함수처럼 실행하면 에러가 발생된다.
//	hello() // hello is not defined 에러 발생 

