package k20241011;

import java.util.Arrays;

public class ZigzagTest {

	public static void main(String[] args) {
		
//		2차원 배열
//		자료형[][] 배열이름 = new 자료형[행][열];
		int[][] a = new int[7][4];
		
		/*
		System.out.println("행의 개수: " + a.length); // 배열이름.length => 행의 개수
		System.out.println("열의 개수: " + a[0].length); // 배열이름[인덱스].length => 인덱스 요소를 구성하는 열의 개수
//		System.out.println(Arrays.toString(a));
//		System.out.println(Arrays.toString(a[0]));
		for (int i = 0; i < a.length; i++) {
			System.out.println(Arrays.toString(a[i]));
		}
		
		int[][] b = {{1, 2, 3}, {4, 5, 6}, {7, 8, 9}};
		for (int i = 0; i < b.length; i++) {
			System.out.println(Arrays.toString(b[i]));
		}
		*/
		
		int num = 0; // 배열에 채워질 숫자를 1씩 증가하는 변수
		for (int i = 0; i < a.length; i++) {
//			짝수 행과 홀수 행이 숫자가 채워지는 방향이 다르므로 반복문을 별도로 만든다.
			if (i % 2 == 0) { // 짝수행인가?
//				짝수행, j => 0, 1, 2, 3, 4, 5
				for (int j = 0; j < a[i].length; j++) {
					a[i][j] = ++num;
				}
			} else {
//				홀수행, j => 5, 4, 3, 2, 1, 0
				for (int j = a[i].length - 1; j >= 0; j--) {
					a[i][j] = ++num;
				}
			}
		}
		
		for (int i = 0; i < a.length; i++) {
			for (int j = 0; j < a[i].length; j++) {
				System.out.printf("%2d ", a[i][j]);
			}
			System.out.println();
		}
		
	}
	
}













