//	Promise 만들기 1 => Promise 객체를 만들어서 변수에 할당한다.
const promise1 = new Promise(function (resolve, reject) {
	setTimeout(function () {
		resolve('promise1 OK!');
	}, 1000);
});

promise1
	.then(function (value) {
		console.log('1. promise1:', value);
	});
	
const promise2 = new Promise(function (resolve, reject) {
	setTimeout(function () {
		reject('promise2 Fail!');
	}, 1000);
});

promise2
	.catch(function (error) {
		console.log('1. promise2:', error);
	});

//	1. ==================================================================================
	
//	Promise 만들기 2 => 함수에서 Promise를 객체를 만들어서 리턴한다.
function promise3() {
	return new Promise(function (resolve, reject) {
		setTimeout(function () {
			resolve('promise3 OK!');
		}, 2000);
	});
}

promise3()
	.then(function (value) {
		console.log('2. promise3:', value);
	});

function promise4() {
	return new Promise(function (resolve, reject) {
		setTimeout(function () {
			reject('promise4 Fail!');
		}, 2000);
	});
}

promise4()
	.catch(function (error) {
		console.log('2. promise4:', error);
	});

//	2. ==================================================================================

promise3()
	.then(function (value) {
		console.log('3. promise3:', value);
		promise4()
		.catch(function (error) {
			console.log('3. promise4:', error);
		});
	})
	
//	3. ==================================================================================

promise4()
	.then(function (data) {
		console.log('4. promise4:', data);
	})
//	catch() 함수가 중간에 있으면 실패했더라도 다음 작업이 이어서 실행된다.
	.catch(function (error) {
		console.log('4. promise4:', error);
		// catch() 함수가 중간에 있더라도 Promise 객체의 reject() 하수를 실행하면 이어지는 다음 작업을
		// 중지시킬 수 있다.
		return Promise.reject('현재 작업이 실패해서 다음 작업을 실행하지 않는다.');
	})
	.then(function () {
		console.log('앞의 작업이 실패하면 이곳의 작업은 실행하면 안된다.');
	})
//	catch() 함수가 마지막에 있으면 실패한 작업 뒤의 작업은 실행되지 않는다.
//	.catch(function (error) {
//		console.log('4. promise4:', error);
//	})

