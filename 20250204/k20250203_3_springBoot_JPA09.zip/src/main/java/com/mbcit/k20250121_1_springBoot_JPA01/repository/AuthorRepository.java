package com.mbcit.k20250121_1_springBoot_JPA01.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mbcit.k20250121_1_springBoot_JPA01.domain.Author;

public interface AuthorRepository extends JpaRepository<Author, Long> {

	
}
