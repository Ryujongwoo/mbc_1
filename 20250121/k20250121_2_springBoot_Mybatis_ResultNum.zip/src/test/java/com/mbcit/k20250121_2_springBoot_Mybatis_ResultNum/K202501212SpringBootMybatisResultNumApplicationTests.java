package com.mbcit.k20250121_2_springBoot_Mybatis_ResultNum;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class K202501212SpringBootMybatisResultNumApplicationTests {

	@Test
	void contextLoads() {
	}

}
