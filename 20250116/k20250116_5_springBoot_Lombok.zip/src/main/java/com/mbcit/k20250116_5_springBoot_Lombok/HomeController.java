package com.mbcit.k20250116_5_springBoot_Lombok;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
public class HomeController {

	@RequestMapping("/")
	public @ResponseBody String home() {
		System.out.println("HomeController 클래스의 home() 메소드 실행");
		return "Lombok 사용하기";
	}
	
	@RequestMapping("/lombokTest")
	public String lombokTest(Member member) {
		System.out.println("HomeController 클래스의 home() 메소드 실행");
		log.info("{}", member);
		return "lombokTest";
	}
	
}
