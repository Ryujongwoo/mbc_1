import React from 'react';

// 컴포넌트 트리가 깊고 복잡하면 모든 컴포넌트를 거쳐서 데이터를 전달해야 하기 때문에
// prop을 통해 데이터를 전달하기가 까다로워진다.
// 컨텍스트 API로 이 문제를 해결할 수 있으며 컴포넌트 트리의 여러 컴포넌트를 거쳐 전달해야
// 하는 전역 데이터에 이용하는 것이 좋다.
const AuthContext = React.createContext('');

export default AuthContext;
