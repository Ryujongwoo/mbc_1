CREATE TABLE "MYUSER" (
    "ID" VARCHAR2(20 BYTE), 
	"NAME" VARCHAR2(20 BYTE)
);

insert into myuser (id, name) values ('1', '홍길동');
insert into myuser (id, name) values ('2', '임꺽정');
insert into myuser (id, name) values ('3', '장길산');
insert into myuser (id, name) values ('4', '일지매');

select * from myuser;
