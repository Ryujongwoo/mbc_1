//	promise는 javascript의 비동기 처리에 사용되는 객체이다.
//	비동기 처리란 특정 코드의 실행이 완료될 때 까지 기다리지 않고 다음 코드를 먼저 실행하는 javascript의
//	특성을 말한다.

//	promise 상태: 실행 대기 => 실행(이행) 또는 거부
//	실행 대기(pending): promise가 실행되기 전 상태, 실행하지도 않고 거부하지도 않은 상태
//	실행(이행, fulfilled): 연산이 성공적으로 실행됨
//	거부(rejected): 연산이 실패함

//	promise 만들기
//	const promise이름 = new Promise(executor 함수)
//	새로운 promise가 생성되면 Promise 객체를 만들 때 인수로 넘겨준 executor 함수가 자동으로 실행된다.

/*
const promise = new Promise(function (resolve, reject) {
	console.log('1. promise의 executor 함수가 실행됨');
	setTimeout(function () {
		// promise가 정상적으로 실행된 결과는 resolve() 함수의 인수로 리턴시킨다.
		resolve('홍길동'); // promise 성공
		// promise가 실패한 결과는 reject() 함수의 인수로 리턴시킨다.
		// reject('에러 발생'); // promise 실패
	}, 2000);
});
*/

const promise = new Promise((resolve, reject) => {
	console.log('1. promise의 executor 함수가 실행됨');
	setTimeout(() => {
		resolve('홍길동');
		// reject('에러 발생');
	}, 2000);
});


//	promise 사용하기
//	resolve() 함수가 리턴하는 값은 then() 함수로 받아서 처리하고 reject() 함수가 리턴하는 값은 catch()
//	함수로 받아서 처리한다.
//	promise의 성공, 실패 여부와 상관없이 무조건 실행해야 할 코드가 있다면 finally() 함수로 처리한다.

//	chaining: '.'으로 연결해서 함수를 실행하는 방법
/*
promise
	.then(function (value) { // promise가 resolve(성공)되면 실행 코드를 입력한다.
		console.log(`1. promise then => ${value}`);
	})
	.catch(function (error) { // promise가 reject(실패)되면 실행할 코드를 입력한다.
		console.log(`1. promise catch => ${error}`);
	})
	.finally(function () { // promise의 성공, 실패 여부와 상관없이 실행할 코드를 입력한다.
		console.log('1. promise finally => promise의 성공, 실패 여부와 상관없이 실행된다.');
	});
*/

promise
	.then(value => {
		console.log(`1. promise then => ${value}`);
	})
	.catch(error => {
		console.log(`1. promise catch => ${error}`);
	})
	.finally(() => {
		console.log('1. promise finally => promise의 성공, 실패 여부와 상관없이 실행된다.');
	});

//	1. ==========================================================================================

const fetchNumber = new Promise(function (resolve, reject) {
	console.log('2. promise의 executor 함수가 실행됨');
	setTimeout(function () {
		resolve(1);
	}, 1000);
});

fetchNumber
	.then(function (number) {
		console.log(`2. promise then 1 => ${number}`);
		return number * 2;
	})
//	이전 then() 함수에서 리턴하는 값을 다음 then 함수에서 받아서 처리할 수 있다.
	.then(function (number) {
		console.log(`2. promise then 2 => ${number}`);
		return number * 3;
	})
	.then(function (number) {
		console.log(`2. promise then 3 => ${number}`);
		// 새 Promise 객체를 만들어 리턴시킬 수 있다.
		return new Promise(function (resolve, reject) {
			setTimeout(function () {
				resolve(number - 1);
			}, 2000);
		});
	})
	.then(function (number) {
		console.log(`2. promise then 4 => ${number}`);
	});

//	2. ==========================================================================================

//	error handling

/*
const getHen = function () {
	return new Promise(function (resolve, reject) {
		setTimeout(function () {
			resolve('암탉');
		}, 1000);
	});
}

const getEgg = function (hen) {
	return new Promise(function (resolve, reject) {
		setTimeout(function () {
			resolve(`${hen} => 달걀`);
		}, 1000);
	});
}

const getMeal = function (egg) {
	return new Promise(function (resolve, reject) {
		setTimeout(function () {
			resolve(`${egg} => 후라이`);	
		}, 1000);
	});
}
*/

const getHen = () => new Promise((resolve, reject) => setTimeout(() => resolve('암탉'), 1000));
const getEgg = hen => new Promise((resolve, reject) => 
//	setTimeout(() => resolve(`${hen} => 달걀`), 1000));
	setTimeout(() => reject(`error!!! ${hen} => 달걀`), 1000));
const getMeal = egg => new Promise((resolve, reject) => setTimeout(() => resolve(`${egg} => 후라이`), 1000));

/*
getHen()
	.then(function (hen) {
		console.log(`3. hen: ${hen}`); // han: 암탉
		return getEgg(hen);
	})
	.then(function (egg) {
		console.log(`3. egg: ${egg}`); // egg: 암탉 => 달걀
		return getMeal(egg);
	})
	.then(function (meal) {
		console.log(`3. meal: ${meal}`); // meal: 암탉 => 달걀 => 후라이
	});
*/

/*
getHen()
	.then(hen => getEgg(hen))
	.then(egg => getMeal(egg))
//	함수의 인수로 넘겨받은 데이터를 console.log()를 사용해서 출력만 할 경우 console.log로 대체할 수 있다.
//	.then(meal => console.log(meal));
	.then(console.log);
*/

getHen()
	.then(hen => getEgg(hen))
//	에러가 발생된 시점에서 에러를 처리하려면 에러가 발생된 시점에서 catch()를 붙여서 처리하면 된다.
//	.catch(() => '빵')
	.then(egg => getMeal(egg))
	.then(console.log)
//	catch()를 마지막에 사용하면 임의의 시점에서 발생된 에러를 처리하고 나머지 코드는 실행하지 않는다.
	.catch(console.log)

