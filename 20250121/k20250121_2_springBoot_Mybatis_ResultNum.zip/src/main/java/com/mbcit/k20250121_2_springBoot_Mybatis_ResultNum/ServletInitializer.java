package com.mbcit.k20250121_2_springBoot_Mybatis_ResultNum;

import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;

public class ServletInitializer extends SpringBootServletInitializer {

	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		return application.sources(K202501212SpringBootMybatisResultNumApplication.class);
	}

}
