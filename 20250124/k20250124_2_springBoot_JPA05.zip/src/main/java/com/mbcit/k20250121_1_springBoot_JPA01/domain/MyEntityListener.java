package com.mbcit.k20250121_1_springBoot_JPA01.domain;

import javax.persistence.PrePersist;

public class MyEntityListener {

	@PrePersist
	public void prePersist(Object object) {
		System.out.println("MyEntityListener 리스너의 prePersist() 메소드 실행됨");
//		createDate = LocalDateTime.now();
//		updateDate = LocalDateTime.now();
	}
	
}
