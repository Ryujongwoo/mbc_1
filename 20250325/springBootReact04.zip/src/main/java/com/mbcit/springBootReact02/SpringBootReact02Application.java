package com.mbcit.springBootReact02;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.mbcit.springBootReact02.domain.Car;
import com.mbcit.springBootReact02.domain.CarRepository;
import com.mbcit.springBootReact02.domain.Owner;
import com.mbcit.springBootReact02.domain.OwnerRepository;
import com.mbcit.springBootReact02.domain.User;
import com.mbcit.springBootReact02.domain.UserRepository;

@SpringBootApplication
//	H2 데이터베이스에 데이터를 추가하기 위해 CommandLineRunner 인터페이스를 구현받는다.
public class SpringBootReact02Application implements CommandLineRunner {

	private static final Logger logger = LoggerFactory.getLogger(SpringBootReact02Application.class);
	
	@Autowired
	private CarRepository carRepository;
	@Autowired
	private OwnerRepository ownerRepository;
	
//	메인 클래스에 UserRepository를 주입한다.
	@Autowired
	private UserRepository userRepository;
	
	public static void main(String[] args) {
		SpringApplication.run(SpringBootReact02Application.class, args);
	}

//	CommandLineRunner 인터페이스를 구현받으면 가변 인자를 인수로 가지는 run() 메소드를 Override 시켜서
//	사용해야 하며 이 메소드는 springBoot가 실행된 후 애플리케이션이 완전히 실행되기 전에 자동 실행된다.
	@Override
	public void run(String... args) throws Exception {
		System.out.println("SpringBootReact02Application 클래스의 run() 메소드 실행");
		System.out.println("carRepository: " + carRepository);
		
//		소유자 객체를 추가하고 데이터베이스에 저장한다.
		Owner owner1 = new Owner("장", "용훈");
		Owner owner2 = new Owner("강", "재성");
		ownerRepository.save(owner1);
		ownerRepository.save(owner2);
		
		carRepository.save(new Car("기아", "모닝", "빨강", "123가 1234", 2024, 1400, owner1));
		carRepository.save(new Car("현대", "액센트", "검정", "123나 1234", 2022, 2100, owner2));
		carRepository.save(new Car("쉐보레", "스파크", "파랑", "123다 1234", 2024, 1500, owner2));
		
//		모든 자동차를 가져와서 콘솔에 로그로 출력한다.
		for (Car car : carRepository.findAll()) {
//			logger.info(car.toString());
//			logger.info(String.valueOf(car));
//			logger.info(car + "");
			logger.info(car.getBrand() + ": " + car.getModel());
		}
		
//		암호는 bcrypt 생성기를 검색해서 계산하고 계산된 해시 코드를 붙여넣는다.
//		$2y는 알고리즘 버전을 나타내고 $05는 알고리즘의 강도를 나타낸다.
//		스프링 시큐리티 BCryptPasswordEncoder 클래스의 기본 강도는 10이다.
//		사용자 이름: user, 암호: user, $2y$05$ZIdEBh7MgERBlc7SrTjCuuYpB9ELeMp29qNSvwZ18ZufTgS4C9UPK
		 userRepository.save(new User("user", 
				 "$2y$05$ZIdEBh7MgERBlc7SrTjCuuYpB9ELeMp29qNSvwZ18ZufTgS4C9UPK", "USER"));
//		사용자 이름: admin, 암호: admin, $2y$05$AnK0HIA27ZNVKQ35hwV4zuCPVU/C7EgEAUxRZYrXRk6h4rP2TGgMS
		 userRepository.save(new User("admin", 
				 "$2y$05$AnK0HIA27ZNVKQ35hwV4zuCPVU/C7EgEAUxRZYrXRk6h4rP2TGgMS", "ADMIN"));		
	}

}














