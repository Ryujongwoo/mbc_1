import { Route, Routes } from 'react-router-dom';
import './App.css';

function Home() {
  return (
    <div>
      <h2>Home</h2>
      Home...
    </div>
  )
}

function Topics() {
  return (
    <div>
      <h2>Topics</h2>
      Topics...
    </div>    
  )
}

function Contact() {
  return (
    <div>
      <h2>Contact</h2>
      Contact...
    </div>    
  )
}

function App() {
  return (
    <div className="App">
      <h1>Hello React Router DOM</h1>
      {/* <Home /> */}
      {/* <Topics /> */}
      {/* <Contact /> */}
      <ul>
        <li><a href='/'>Home</a></li>
        <li><a href='/topics'>Topics</a></li>
        <li><a href='/contact'>Contact</a></li>
      </ul>
      <Routes>
        <Route path='/' element={<Home />} />
        <Route path='/topics' element={<Topics />} />
        <Route path='/contact' element={<Contact />} />
        {/* 존재하지 않는 페이지로 접근했을 경우 아래와 같이 구현한다. */}
        <Route path='/*' element={"Not Found"} />
      </Routes>
    </div>
  );
}

export default App;
