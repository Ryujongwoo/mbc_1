# 주석
# INSERT INTO 테이블이름(데이터를 입력할 필드이름, ...) VALUES (필드에 저장할 데이터, ...);
# 필드에 저장할 데이터가 문자열일 경우 반드시 작은따옴표로 묶어야 한다.
INSERT INTO memo(NAME, PASSWORD, memo) VALUES ('홍길동', '1111', '1등 입니다.');
INSERT INTO memo(NAME, PASSWORD, memo) VALUES ('임꺽정', '2222', '2등 입니다.');
INSERT INTO memo(NAME, PASSWORD, memo) VALUES ('장길산', '3333', '3등 입니다.');
INSERT INTO memo(NAME, PASSWORD, memo) VALUES ('일지매', '4444', '4등 입니다.');
INSERT INTO memo(NAME, PASSWORD, memo) VALUES ('길홍동', '5555', '5등 입니다.');
INSERT INTO memo(NAME, PASSWORD, memo) VALUES ('홍동길', '6666', '6등 입니다.');

# SELECT [DISTINCT] 검색할 필드이름 또는 *(모든 필드) FROM 테이블이름;
SELECT * FROM memo; # memo 테이블의 모든 필드 검색한다.
SELECT NAME, memo FROM memo; # memo 테이블의 name, memo 필드만 검색한다.
# DISTINCT 옵션은 중복되는 데이터는 1번만 출력한다.
SELECT DISTINCT NAME FROM memo; # memo 테이블의 name 필드를 검색하는데 중복되는 이름은 1번만 출력한다.

# SELECT 검색할 필드이름 또는 *(모든 필드) FROM 테이블이름 ORDER BY 필드이름 [ASC/DESC]; 
# ORDER BY: 지정된 필드를 기준으로 정렬한다.
# 정렬 방식을 생략하면 ASC가 기본값으로 사용되며 오름차순으로 정렬되고 DESC를 입력하면 내림차순으로 정렬된다.
SELECT * FROM memo ORDER BY NAME ASC; # memo 테이블의 모든 필드를 검색해서 name의 오름차순으로 정렬한다.
SELECT * FROM memo ORDER BY NAME;
SELECT * FROM memo ORDER BY NAME DESC; # memo 테이블의 모든 필드를 검색해서 name의 내림차순으로 정렬한다.
# name의 오름차순으로 검색을 하려는데 name이 같으면 idx의 내림차순으로 정렬한다.
SELECT * FROM memo ORDER BY NAME ASC, idx DESC;
SELECT * FROM memo ORDER BY idx DESC; # 최신글 순으로 정렬해서 얻어온다.

# SELECT 검색할 필드이름 또는 *(모든 필드) FROM 테이블이름 WHERE 조건식; 
# WHERE 뒤에 입력한 조건에 만족하는 데이터만 검색한다.
# 조건의 종류는 관계 연산자를 사용하는 단순 조건, 논리 연산자를 사용하는 복합 조건, LIKE 연산자를 사용하는 부분일치 조건이 있다.

# 단순 조건 => 조건이 1개
# 같은가 물어볼 때 "="을 1개만 사용한다.
SELECT * FROM memo WHERE idx = 100; # 특정글 1건을 얻어온다.
SELECT * FROM memo WHERE NAME = '홍길동';
SELECT * FROM memo WHERE NAME != '홍길동';

# 복합 조건 => 2개 이상의 조건을 and, or를 사용하는 조건
SELECT * FROM memo WHERE idx >= 100 && idx <= 110;
SELECT * FROM memo WHERE idx >= 120 AND idx <= 130;
# BETWEEN 연산자는 ~이상이고 ~이하인 조건을 지정할 수 있다. 이상, 이하 조건만 가능하다.
SELECT * FROM memo WHERE idx BETWEEN 140 AND 150;

SELECT * FROM memo WHERE NAME = '홍길동' || NAME = '임꺽정';
SELECT * FROM memo WHERE NAME = '장길산' OR NAME = '일지매';
# IN 연산자는 () 안에 있는 데이터만 얻어온다.
SELECT * FROM memo WHERE NAME IN ('홍길동', '임꺽정', '장길산', '일지매');
# NOT IN 연산자는 () 안에 없는 데이터만 얻어온다.
SELECT * FROM memo WHERE NAME NOT IN ('홍길동', '임꺽정', '장길산', '일지매');

# LIKE(부분일치) 조건, 와일드카드(대체) 문자와 같이 사용된다.
# 와일드카드 문자는 '_'와 '%'가 있고 '_'는 1문자를 '%'는 여러 문자를 대체할 수 있다.
# '종로_가'는 종로1가, 종로2가, 종로3가, ... 처럼 '_' 자리에 어떤 문자가 나와도 상관없다.
# '홍%'는 홍으로 시작하는 모든 문자열을 검색한다.
# '%홍'는 홍으로 끝나는 모든 문자열을 검색한다.
# '%홍%'는 홍을 포함하는 모든 문자열을 검색한다.
SELECT * FROM memo WHERE NAME LIKE '홍%';
SELECT * FROM memo WHERE NAME LIKE '%매';
SELECT * FROM memo WHERE NAME LIKE '%길%';

# LIMIT를 사용해서 특정 index 부터 원하는 개수를 지정해서 검색할 수 있다.
# index는 MYSQL은 0부터 시작하고 ORACLE은 1부터 시작한다.
# SELECT 검색할 필드이름 또는 *(모든 필드) FROM 테이블이름 LIMIT 인덱스, 개수;
SELECT * FROM memo;
SELECT * FROM memo LIMIT 1, 10;
SELECT * FROM memo ORDER BY idx DESC LIMIT 0, 10; # 게시판에서 1페이지 분량의 글 목록을 얻어온다.

# 그룹 함수: SUM(합계), AVG(평균), MAX(최대값), MIN(최소값), COUNT(개수)
SELECT SUM(idx) FROM memo;
SELECT AVG(idx) FROM memo;
SELECT MAX(idx) FROM memo;
SELECT MIN(idx) FROM memo;
SELECT COUNT(idx) FROM memo;
# 개수는 어떤 필드의 개수를 세더라도 같은 결과가 나오기 때문에 인수로 필드명을 지정해도 되지만
# '*'를 지정해서 실행한다.
SELECT COUNT(*) FROM memo; # 테이블에 저장된 전체 데이터의 개수를 얻어온다.
# 'AS' 예약어를 사용하면 필드 이름에 별명을 지정할 수 있다.
SELECT NAME AS '이름' FROM memo;
SELECT COUNT(*) AS '인원수' FROM memo;

# GROUP BY를 사용해서 그룹화를 할 수 있다. => 그룹별 소계
# SELECT 검색할 필드이름 또는 *(모든 필드) FROM 테이블이름 WHERE 전체조건 GROUP BY 필드이름 HAVING 그룹조건;
SELECT COUNT(*) AS '응시횟수' FROM memo; # 전체 응시 횟수
SELECT NAME, COUNT(*) AS '응시횟수' FROM memo GROUP BY NAME; # name별 응시 횟수
# name별로 그룹화 해서 그 그룹의 데이터 개수가 3개 이상인 것만 검색한다.
SELECT NAME, COUNT(*) AS '응시횟수' FROM memo GROUP BY NAME HAVING COUNT(*) >= 3;

# DELETE FROM 테이블이름 WHERE 조건식;
DELETE FROM memo; # memo 테이블의 모든 데이터가 삭제된다.
DELETE FROM memo WHERE NAME = '홍길동';
SELECT * FROM memo;

# 자동 증가를 1부터 다시 시작하기 => 데이블에 저장된 데이터가 없어야 한다.
DELETE FROM memo;
ALTER TABLE memo AUTO_INCREMENT = 1;

# UPDATE 테이블이름 SET 수정할내용, ... WHERE 조건식;
UPDATE memo SET PASSWORD = '7777';
UPDATE memo SET PASSWORD = '1111' WHERE NAME = '홍길동';
UPDATE memo SET PASSWORD = '2222', memo = '수정할 내용' WHERE NAME = '임꺽정';
UPDATE memo SET memo = '적당한 내용', PASSWORD = '3333' WHERE NAME = '장길산';


