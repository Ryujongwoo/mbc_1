//	async와 await를 사용하면 Promise를 보다 더 깔끔하게 사용할 수 있다.

//	Promise
//	Promise 객체를 리턴하는 함수를 익명 함수로 만들어 변수에 저장하면 Promise로 인식하지 못한다.
let user = function () {
	return new Promise(function (resolve, reject) {
		
	});
}
console.log('1. user:', user); // 1. user: 할당한 익명 함수

//	1. ==================================================================================

//	Promise 객체를 리턴하는 함수를 실행한 결과는 Promise로 인식한다.
function fetchUser() {
	return new Promise(function (resolve, reject) {
		// return '홍길동'; // pending 상태로 리턴한다.
		// Promise 내부에서는 resolve() 또는 reject() 함수를 실행해서 결과를 리턴시켜야 한다.
		// resolve('홍길동'); // fulfilled 상태로 리턴한다.
		reject('홍길동'); // rejected 상태로 리턴한다.
	});
}
user = fetchUser();
console.log('2. user:', user); // 2. user: Promise

user
	.then(function (response) {
		console.log('2. response:', response);
	})
	.catch(function (error) {
		console.log('2. error:', error);
	})
	
//	2. ==================================================================================

//	async
//	함수 앞에 async를 붙이면 Promise 객체를 리턴 시키지 않아도 함수 내부의 코드가 자동으로 Promise로 변환된다.

function fetchUser2() {
	return '홍길동';
}
const user2 = fetchUser2();
console.log('3. user2:', user2); // 3. user2: 홍길동

async function fetchUser3() {
	return '홍길동';
}
const user3 = fetchUser3();
console.log('3. user3:', user3); // 3. user3: Promise {<fulfilled>: '홍길동'}

user3
	.then(function (response) {
		console.log('3. response:', response); // 3. response: 홍길동
	})
	
//	3. ==================================================================================

//	await
//	await는 async를 붙여준 함수에서만 사용할 수 있고 await를 붙여준 함수가 완전히 끝나기를 기다렸다가
//	다음 작업을 실행한다.

function delay(ms) {
	return new Promise(function (resolve, reject) {
		setTimeout(function () {
			resolve();
		}, ms);
	});
}

async function getApple() {
	await delay(2000);
	return '사과';
}

const apple = getApple();
console.log('4. apple:', apple);

apple
	.then(function (response) {
		console.log('4. response:', response);
	})

async function getBanana() {
	await delay(1000);
	return '바나나';
}
	
const banana = getBanana();
console.log('4. banana:', banana);

banana
	.then(function (response) {
		console.log('4. response:', response);
	})
	
//	4. ==================================================================================

//	Promise도 지나치게 실행하면 콜백 지옥 현상이 나타난다.

/*
function pickFruits() {
	return getApple()
		.then(function (apple) {
			console.log('5. apple:', apple);
			return getBanana()
				.then(function (banana) {
					console.log('5. banana:', banana);
					return apple + banana;
				});
		});
}
*/

//	순차 처리
//	async와 await를 사용하면 동기적 프로그램을 작성하는 것 처럼 비동기 프로그램을 작성할 수 있다.
async function pickFruits() {
	const apple = await getApple(); // getApple() 함수가 끝나기를 기다린다. 2초 대기
	const banana = await getBanana(); // getBanana() 함수가 끝나기를 기다린다. 1초 대기
	return apple + banana;
}

pickFruits()
	.then(function (result) {
		console.log('5. result:', result);
	});
	
//	5. ==================================================================================

//	병렬(동시) 처리 => 실행하는 Promise가 서로 연관이 있을 때
async function pickFruits2() {
//	 병렬 처리할 함수를 동시에 실행시킨다.
	const applePromise = getApple();
	const bananaPromise = getBanana();
//	await를 이용해서 동시에 실행한 함수가 모두 종료될 때 까지 대기한다.
	const apple = await applePromise; // 2초 대기
//	getBanana() 함수는 getApple()와 동시에 실행했기 때문에 getApple() 함수가 2초간 실행되는 도중에 종료된다.
	const banana = await bananaPromise; // 1초 대기
	return apple + banana;
}

pickFruits2()
	.then(function (result) {
		console.log('6. result:', result);
	});

//	6. ==================================================================================

//	병렬(동시) 처리 => 실행하는 Promise가 서로 연관이 없을 때
//	Promise가 서로 연관이 없을 경우 병렬 처리할 때 위와 같이 작성하지 않고 Promise 객체의 all() 함수 또는
//	race() 함수를 사용해서 작성할 수 있다.

//	all() => 전체 => 모든 Promise가 정상적으로 실행된다.
function pickFruits3() {
//	all() 함수의 인수로 병렬 처리할 Promise가 저장된 배열을 전달하면 배열로 전달된 모든 Promise가 종료된 후
//	리턴 값(배열)이 then()으로 전달된다.
	return Promise.all([getApple(), getBanana()])
		.then(function (fruits) {
			//	모든 Promise가 실행된 결과가 저장된 배열이 리턴된다.
			return fruits;
		})
}

pickFruits3()
	.then(function (result) {
		console.log('7. result:', result);
	});
	
//	7. ==================================================================================

//	race() => 경쟁 => 가장 먼저 종료되는 Promise만 실행된다.
function pickFruits4() {
//	race() 함수의 인수로 병렬 처리할 Promise가 저장된 배열을 전달하면 배열로 전달된 모든 Promise 중에서
//	가장 먼저 종료된 Promise의 리턴 값이 then()으로 전달된다. => 나머지는 Promise는 무시된다.
//	실행 시간이 가장 짧은 Promise의 결과만 리턴된다.
	return Promise.race([getApple(), getBanana()]);
}	

pickFruits4()
	.then(function (result) {
		console.log('8. result:', result);
	});
	
