function allCheck() {
//	name 속성 값이 all인 체크 박스를 체크하면 true, 해제하면 false인 상태를 변수에 저장한다.
//	라디오나 체크 박스의 checked 속성은 선택되면 true, 해제되면 false를 얻어온다.
	let check = document.getElementsByName('all')[0].checked;
	console.log(check);
	
//	name 속성 값이 check인 모든 체크 박스를 얻어온다.
	let checks = document.getElementsByName('check');
	console.log(checks);
	
//	name 속성 값이 check인 체크 박스의 개수만큼 반복하며 일괄적으로 선택 또는 해제한다.
	for (let i = 0; i < checks.length; i++) {
		checks[i].checked = check;
	}
}

function selectCheck() {
//	name 속성 값이 check인 모든 체크 박스를 얻어온다.
	let checks = document.getElementsByName('check');
	
//	빨강, 파랑, 노랑, 검정 체크 박스가 체크된 체크 박스의 개수를 계산한다.
	let count = 0; // 체크된 체크 박스의 개수를 기억할 변수
	for (let i = 0; i < checks.length; i++) {
		// console.log(checks[i].checked);
		if (checks[i].checked) {
			count++;
		}
	}
	console.log(count);
	
//	빨강, 파랑, 노랑, 검정 체크 박스가 모두 체크되었으면 전체 선택 체크 박스에 체크하고 한 개 라도
//	체크가 안되어있으면 전체 선택 체크 박스의 체크를 해제한다.
	if (count == checks.length) { // 모든 색상 체크 박스가 체크되었나?
		// 무조건 전체 선택 체크 박스에 체크한다.
		document.getElementsByName('all')[0].checked = true;
	} else {
		// 무조건 전체 선택 체크 박스에 체크를 해제한다.
		document.getElementsByName('all')[0].checked = false;
	}
}





















