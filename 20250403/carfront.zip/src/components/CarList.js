import React, { useEffect, useState } from "react";
import { SERVER_URL } from "../constants";
// MUI의 DataGrid를 사용하기 위해 import 한다.
import { DataGrid } from "@mui/x-data-grid";
import { Button, Snackbar, IconButton } from "@mui/material";
import DeleteIcon from '@mui/icons-material/Delete';
import AddCar from "./AddCar";
import EditCar from "./EditCar";
import CustomToolbar from "./CustomToolbar";

function CarList() {

  // springBoot에 REST API로 요청해서 응답받은 정보를 저장할 cars라는 상태를 선언하고
  // 빈 배열로 초기화 한다.
  const [cars, setCars] = useState([]);

  // Snackbar 컴포넌트가 사용할 open이라는 상태를 선언하고 메시지는 자동차 삭제 후에
  // 표시되어야 하므로 false로 초기치를 지정한다.
  const [open, setOpen] = useState(false);

  // CarList 컴포넌트가 최초 렌더링된 후 useEffect()에서 fetch()를 이용해서 springBoot에
  // 자동차 정보를 요청한다.
  // 최초 렌더링 후에만 useEffect()를 실행해야 하므로 두 번째 인수로 빈 배열을 전달한다.
  useEffect(function () {
    // fetch('http://localhost:9090/api/cars')
    // fetch(SERVER_URL + 'api/cars')
    //   .then(response => response.json())
    //   .then(data => setCars(data._embedded.cars))
    //   .catch(error => console.log('에러 발생', error))
    fetchCars();
  }, []);
    
  // useEffect() 함수에서 fetch를 실행해서 자동차 목록을 가져오는 부분을 함수로 분리한다.
  // 컴포넌트가 최초로 렌더링될 때와 삭제, 수정 작업이 실행된 후에도 자동차 목록을 가져와야
  // 하기 때문이다.
  const fetchCars = () => {
    fetch(SERVER_URL + 'api/cars')
      .then(response => response.json())
      .then(data => setCars(data._embedded.cars))
      .catch(error => console.log('에러 발생', error))
  }

  // Delete 버튼이 클릭되면 자동차를 삭제하는 함수를 구현한다.
  // fetch를 이용해서 DELETE 요청이 성공하면 fetchCars() 함수를 실행해서 cars 상태를
  // 수정해서 화면을 다시 렌더링(새로고침) 한다.
  const onDelClick = url => {
    if (window.confirm('정말로 삭제하겠습니까?')) {
      fetch(url, {method: 'DELETE'})
        .then(response => {
          if (response.ok) {
            fetchCars();
            // 삭제한 후 Snackbar 컴포넌트를 표시하도록 open 상태 값을 true로 수정한다.
            setOpen(true);
          } else {
            alert('뭔가 잘못되었습니다.');
          }
        })
        .catch(error => console.log('에러 발생', error))
    }
  }

  // 새로운 자동차를 추가하는 함수를 구현한다.
  const addCar = function (car) {
    fetch(SERVER_URL + 'api/cars',{
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify(car)
    })
    .then(response => {
      if (response.ok) {
        fetchCars();
      } else {
        alert('뭔가 잘못되었습니다.');
      }
    })
    .catch(error => console.log(error))
  }

  // 기존 자동차를 수정하는 함수를 구현한다.
  const updateCar = function (car, url) {
    fetch(url, {
      method: 'PUT', 
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify(car)
    })
    .then(response => {
      if (response.ok) {
        fetchCars();
      } else {
        alert('뭔가 잘못되었습니다.');
      }
    })
    .catch(error => console.log(error))
  }

  // DataGrid 컴포넌트의 columns prop에 들어갈 열을 정의한다.
  const columns = [
    {field: 'brand', headerName: '차종', width: 200},
    {field: 'model', headerName: '모델명', width: 200},
    {field: 'color', headerName: '색상', width: 200},
    {field: 'year', headerName: '연식', width: 150},
    {field: 'price', headerName: '가격', width: 150},
    {
      field: '_links.self.href',
      headerName: '',
      sortable: false, // 정렬은 필요없으므로 false로 설정한다.
      filterable: false, // 필터링은 필요없으므로 false로 설정한다.
      // renderCell로 Button 컴포넌트를 렌더링해서 새 열을 추가한다.
      // 함수에 전달된 값은 _links.self.href에 저장된 자동차에 대한 링크이다.
      // 자동차를 삭제하는 함수를 삭제할 자동차의 링크(row.id)를 넘겨서 호출한다.
      renderCell: row => 
        // <Button variant="outlined" onClick={() => onDelClick(row.id)}>Delete</Button>
        <IconButton onClick={() => onDelClick(row.id)}>
          <DeleteIcon color="error"/>
        </IconButton>
      , width: 10
    }, // Delete 버튼
    {
      field: '_links.car.href',
      headerName: '',
      sortable: false,
      filterable: false,
      renderCell: row => <EditCar data={row} updateCar={updateCar}/>,
      width: 10
    } // Edit Car 버튼이 화면에 표시되고 클릭하면 EditCar 컴포넌트의 모달 창이 열린다.
  ];

  return (
    <React.Fragment>
      <AddCar addCar={addCar}/>
      <div>
        {/* table 요소를 추가하고 map 함수로 자동차 객체를 출력한다. */}
        {/*
        <table>
          <tbody>
            {
              cars.map((car, index) => 
                <tr key={index}>
                  <td>{car.brand}</td>
                  <td>{car.model}</td>
                  <td>{car.color}</td>
                  <td>{car.year}</td>
                  <td>{car.price}</td>
                </tr>
              )
            }
          </tbody>
        </table>
        */}

        {/* table 요소와 모든 하위 요소를 제거하고 DataGrid 컴포넌트를 사용한다. */}
        <DataGrid 
          rows={cars} // DataGrid 컴포넌트에 출력할 데이터(cars 상태값) 원본을 지정한다.
          columns={columns} // DataGrid 컴포넌트에 출력할 열을 지정한다.
          getRowId={row => row._links.self.href} // 중복되지 않는 고유한 값을 리턴하는 함수를 지정한다.
          disableRowSelectionOnClick={true} // 행이 선택되는 동작을 비활성화 한다.
          // MUI DataGrid 컴포넌트에서 툴바를 활성화하려면 slots prop으로 toolbar 속성에
          // 활성화하려는 툴바를 제작한 컴포넌트를 연결한다.
          slots={{ toolbar: CustomToolbar }}
        />

        {/* DataGrid 컴포넌트 아래에 Snackbar 컴포넌트를 추가한다. */}
        <Snackbar
          open={open} // Snackbar 컴포넌트의 표시 상태를 지정한다.
          message='자동차 삭제 완료' // Snackbar 컴포넌트에 표시될 메시지를 지정한다.
          autoHideDuration={2000} // Snackbar 컴포넌트가 사라지는 시간을 밀리초로 지정한다.
          onClose={() => setOpen(false)} // Snackbar 컴포넌트를 사라지게 한다.
        />
      </div>
    </React.Fragment>
  )
}

export default CarList;