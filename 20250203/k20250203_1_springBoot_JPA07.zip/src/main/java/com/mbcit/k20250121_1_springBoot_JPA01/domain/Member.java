package com.mbcit.k20250121_1_springBoot_JPA01.domain;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.PostLoad;
import javax.persistence.PostPersist;
import javax.persistence.PostRemove;
import javax.persistence.PostUpdate;
import javax.persistence.PrePersist;
import javax.persistence.PreRemove;
import javax.persistence.PreUpdate;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.persistence.UniqueConstraint;
import javax.transaction.Transactional;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@NoArgsConstructor
@AllArgsConstructor
@RequiredArgsConstructor
@Data
@Builder
@Entity
@SequenceGenerator(name = "seq_generator", sequenceName = "member_id_seq", initialValue = 1, allocationSize = 1)
@EntityListeners(value = {MemberHistoryListener.class})
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class Member extends BaseEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
//	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_generator")
	private Long id;
	
	@NonNull
	private String name;
	@NonNull
	private String email;
	
//	@OneToMany 어노테이션으로 Member 엔티티와 MemberHistory 엔티티의 1:N 연관 관계를 설정한다.
//	지연 로딩
//	데이터 조회시 필요한 시점에 연관된 데이터를 불러오는 것을 의미한다.
//	LazyInitializationException(지연 초기화)가 발생될 수 있고 LazyInitializationException이 발생되면 
//	테스트를 실행하는 메소드에 @Transactional 어노테이션을 붙여주거나 @OneToMany 어노테이션의
//	fetch 속성 값을 FetchType.EAGER(즉시 로딩)를 지정하면 해결할 수 있다.
//	@OneToMany
//	@OneToMany(fetch = FetchType.LAZY) // 기본값(FetchType.LAZY)
	
//	즉시 로딩
//	데이터 조회시 연관된 데이터까지 한꺼번에 불러오는 것을 의미한다.
	@OneToMany(fetch = FetchType.EAGER)
	
//	@JoinColum 어노테이션은 엔티티가 어떤 필드와 join 하게될지 지정한다.
//	name 속성값을 member_idx로 지정해서 member_history 테이블의 member_idx 필드와 join됨을 지정한다.
//	MemberHistory 엔티티에 member_idx라는 필드가 없으므로 MemberHistory 엔티티의 memberId 필드에
//	@Column 어노테이션의 name 속성으로 member_idx를 지정한다.
//	1:N 연관 관계 설정은 중간 테이블(N:M 관계에 사용한다.)을 만들지 못하도록 @JoinColumn 어노테이션의
//	name 속성에 Member 엔티티의 기본키 필드와 연결될 MemberHistory 엔티티의 외래키 필드를 지정한다.
	@JoinColumn(name = "member_idx")
	
	@ToString.Exclude
//	Member 엔티티에 관련된 MemberHistory 엔티티가 여러개이기 때문에 collection 타입으로 선언한다.
	private List<MemberHistory> memberHistories = new ArrayList<>();
	
}




















