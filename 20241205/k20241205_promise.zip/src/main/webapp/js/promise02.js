//	동기 방식 처리 => 실행한 순서대로 실행한다.
console.log('1');
console.log('2');
console.log('3');
//	위와 같이 실행하면 실행하는 순서대로 실행되서 1, 2, 3이 출력된다.

//	비동기 방식 처리
console.log('a');
//	setTimeout(실행할 함수, 대기 시간): 대기 시간이 경과되면 실행할 함수를 실행한다.
setTimeout(function () {
	console.log('b');
}, 1000);
console.log('c');
//	위와 같이 실행하면 setTimeout() 함수에 의해서 비동기 방식으로 처리되서 a, c가 출력되고 1초 경과 후
//	b가 출력된다.

//	동기적 콜백
//	변수를 var를 붙여서 선언하거나 함수가 선언되면 호이스팅 기능에 의해서 맨 위로 올라간다.

//	a라는 함수를 실행한다.
a(function () {
	console.log('hello');
});

//	a 라는 함수를 선언한다.
function a(print) {
	print();
}

//	비동기적 콜백
b(function () {
	console.log('비동기 콜백');
}, 500);

function b(print, timeout) {
	setTimeout(print, timeout);
}

