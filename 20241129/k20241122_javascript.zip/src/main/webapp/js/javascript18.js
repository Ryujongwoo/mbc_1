//	명시적 함수
function func1() {
	alert('명시적 함수');
}

//	익명 함수 - 변수에 함수를 할당하고 변수 이름을 함수 이름처럼 사용한다.
/*
const func2 = function () {
	alert('익명 함수');
}
*/
const func2 = () => alert('익명 함수');

/*
function func3() {
	funcLiteral(function (msg) {
		alert(msg);
	});
}
*/
function func3() {
	funcLiteral(msg => alert(msg));
}

function funcLiteral(literal) {
	literal('함수 리터럴 입니다.');
}

//	자바스크립트는 파이썬과 같이 함수 오버로딩이 지원되지 않는다.
//	같은 이름으로 함수를 다시 선언하면 이전에 선언했던 함수가 무시된다.
//	자바스크립트 함수는 실인수와 가인수의 개수가 달라도 정상적으로 실행된다.
//	함수가 호출될 때 넘어오는 인수를 저장할 변수가 모자라면 모자라는 대로 남으면 남는 대로 실행한다.
//	자바스크립트 함수가 호출될 때 실인수는 arguments라는 자바스크립트 내장 객체로 먼저 전달되고
//	arguments 객체에 저장된 실인수를 가인수의 개수만큼 반복하여 arguments 객체에 저장된 데이터를 
//	가인수에 넣어준다.

function varTest(a, b, c, d, e) {
//	console.log('varTest() 함수 실행');
	console.log(arguments);
	console.log('함수가 호출될 때 넘어오는 데이터의 개수: ' + arguments.length);
	for (let i = 0; i < arguments.length; i++) {
		console.log(`arguments[${i}] = ${arguments[i]}`);
	}
	
	console.log(a);
	console.log(b);
	console.log(c);
	console.log(d);
	console.log(e);
}

/*
function goodEdu(good) {
	console.log(good);
}
*/

//	클로저: 함수가 생성될 당시 외부 함수의 값을 기억해 두었다가 내부 함수가 호출될 때 사용한다.
//	참조할 수 없는 위치에 있는 값도 참조할 수 있게 해준다.

// 외부 함수 => 클로저
function closureTest(value) {
	console.log('value: ' + value);
	var a = 100;
	
//	내부 함수
	function addValue(msg) {
		console.log('msg: ' + msg);
		console.log('a: ' + a);
	}
	
//	클로저는 반드시 내부에서 정의한 함수를 리턴시켜야 한다.
	return addValue;	
}

//	변수에 이름이 있는 함수를 할당하려면 할당할 함수의 이름만 적는다.
//	const goodEdu = closureTest; // closureTest 함수가 goodEdu 변수에 저장된다.

//	goodEdu에는 자바스크립트 파일이 읽혀질 때 closureTest 함수를 실행한 후 return 값이 저장된다.
const goodEdu = closureTest('자바스크립트');
console.log(goodEdu);

//	closureTest 함수가 실행된 후 내부 함수(addValue)를 리턴시키므로 closureTest 함수가 호출된 곳으로
//	closureTest 함수의 내부 함수인 addValue가 리턴된다.
//	const goodEdu = function addValue(msg) {
//		console.log('msg: ' + msg);
//		console.log('a: ' + a);
//	}
//	와 같이 된다.
//	즉, goodEdu 변수에 closureTest 함수의 내부 함수인 addValue 할당된다.

goodEdu('클로저는 어렵다.');

