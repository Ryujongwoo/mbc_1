package com.mbcit.register;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/Register")
public class Register extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public Register() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// System.out.println("Register 컨트롤러의 doGet() 메소드 실행");
		actionDo(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// System.out.println("Register 컨트롤러의 doPost() 메소드 실행");
		actionDo(request, response);
	}
	
	protected void actionDo(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		System.out.println("Register 컨트롤러의 actionDo() 메소드 실행");
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html; charset=UTF-8");
		
		String id = request.getParameter("id");
		String password = request.getParameter("password");
		String password2 = request.getParameter("password2");
		String name = request.getParameter("name");
		String age = request.getParameter("age");
		String gender = request.getParameter("gender");
		String email = request.getParameter("email");
		
		if (id == null || id.trim().equals("") || password == null || password.trim().equals("") ||
			password2 == null || password2.trim().equals("") || name == null || name.trim().equals("") ||
			age == null || age.trim().equals("") || gender == null || gender.trim().equals("") ||
			email == null || email.trim().equals("")) {
			// request.getSession().setAttribute("messageType", "오류 메시지: "); // ①
			// request.getSession().setAttribute("messageContent", "모든 내용을 입력하세요."); // ①
			// response.sendRedirect("index.jsp"); // ①
			
			// 입력 체크 실패 메시지를 서블릿을 호출한 AJAX로 넘겨준다.
			response.getWriter().write("1"); // ②
			return;
		}
		
		if (!password.trim().equals(password2.trim())) {
			// request.getSession().setAttribute("messageType", "오류 메시지: "); // ①
			// request.getSession().setAttribute("messageContent", "비밀번호가 일치하지 않습니다."); // ①
			// response.sendRedirect("index.jsp"); // ①
			
			// 비밀번호 체크 실패 메시지를 서블릿을 호출한 AJAX로 넘겨준다.
			response.getWriter().write("2"); // ②
			return;
		}
		
		RegisterVO vo = new RegisterVO();
		vo.setId(id);
		vo.setPassword(password);
		vo.setName(name);
		vo.setAge(Integer.parseInt(age));
		vo.setGender(gender);
		vo.setEmail(email);
		int result = new RegisterDAO().register(vo);
		
		if (result == 1) {
			// request.getSession().setAttribute("messageType", "성공 메시지: "); // ①
			// request.getSession().setAttribute("messageContent", "회원 가입에 성공했습니다."); // ①
			
			// insert sql 명령이 정상적으로 실행됐을 때 메시지를 서블릿을 호출한 AJAX로 넘겨준다.
			response.getWriter().write("3"); // ②
		} else {
			// request.getSession().setAttribute("messageType", "오류 메시지: "); // ①
			// request.getSession().setAttribute("messageContent", "이미 존재하는 아이디입니다."); // ①
			
			// insert sql 명령이 정상적으로 실행되지 않았을 때 메시지를 서블릿을 호출한 AJAX로 넘겨준다.
			response.getWriter().write("4"); // ②
		}
		// response.sendRedirect("index.jsp"); // ①
	}

}

















