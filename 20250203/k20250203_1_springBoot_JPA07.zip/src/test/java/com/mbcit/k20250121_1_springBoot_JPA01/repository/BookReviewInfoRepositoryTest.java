package com.mbcit.k20250121_1_springBoot_JPA01.repository;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.mbcit.k20250121_1_springBoot_JPA01.domain.Book;
import com.mbcit.k20250121_1_springBoot_JPA01.domain.BookReviewInfo;

@SpringBootTest
class BookReviewInfoRepositoryTest {

	@Autowired
	private BookRepository bookRepository;
	@Autowired
	private BookReviewInfoRepository bookReviewInfoRepository;
	
//	RDBMS에서 수행하는 방식
	@Test
	void test() {
		System.out.println("BookReviewInfoRepositoryTest 클래스의 test() 메소드 실행");
		
//		책 정보를 저장한다.
		Book book = new Book();
//		book.setId(1L);
		book.setName("대충 만든 책");
		book.setCategory("java");
		book.setAuthorId(1L);
		book.setPublisherId(1L);
		bookRepository.save(book);
		
		List<Book> books = bookRepository.findAll();
		books.forEach(System.out::println);
		
//		리뷰 정보를 저장한다.
		BookReviewInfo bookReviewInfo = new BookReviewInfo();
//		bookReviewInfo.setId(1L);
		bookReviewInfo.setAverageReviewScore(4.5f);
		bookReviewInfo.setReviewCount(2);
//		bookReviewInfo.setBookId(1L);
		bookReviewInfoRepository.save(bookReviewInfo);
		
		List<BookReviewInfo> bookReviewInfos = bookReviewInfoRepository.findAll();
		bookReviewInfos.forEach(System.out::println);
		
//		id가 1인 책 정보를 Book 엔티티에서 얻어온다.
		Book result = bookRepository.findById(1L).orElse(null);
		System.out.println("result: " + result);
		
//		id가 1인 리뷰 정보를 이용해서 책 정보를 Book 엔티티에서 얻어온다.
//		Book result2 = bookRepository.findById(
//			bookReviewInfoRepository.findById(1L).orElse(null).getBookId()
//		).orElse(null);
//		System.out.println("result2: " + result2);
	}
	
//	JPA에서 수행하는 방식 => BookReviewInfo 정보에서 Book 정보를 가져온다.
	@Test
	void oneToOneTest() {
		System.out.println("BookReviewInfoRepositoryTest 클래스의 oneToOneTest() 메소드 실행");
		System.out.println("BookReviewInfo 정보에서 Book 정보를 가져온다.");

//		책 정보를 저장한다.
		Book book = new Book();
		book.setName("대충 만든 책");
		book.setCategory("java");
		book.setAuthorId(1L);
		book.setPublisherId(1L);
		bookRepository.save(book);
		List<Book> books = bookRepository.findAll();
		books.forEach(System.out::println);
		
//		리뷰 정보를 저장한다.
		BookReviewInfo bookReviewInfo = new BookReviewInfo();
		bookReviewInfo.setAverageReviewScore(4.5f);
		bookReviewInfo.setReviewCount(2);
//		1:1 관계 설정을 위해서 참조할 객체를 넣어준다.
		bookReviewInfo.setBook(book);
		bookReviewInfoRepository.save(bookReviewInfo);
		List<BookReviewInfo> bookReviewInfos = bookReviewInfoRepository.findAll();
		bookReviewInfos.forEach(System.out::println);

//		BookReviewInfo 정보에서 Book 정보를 가져온다.
		Book result = bookReviewInfoRepository.findById(1L).orElse(null).getBook();
		System.out.println("result: " + result);
	}
	
//	JPA에서 수행하는 방식 => Book 정보에서 BookReviewInfo 정보를 가져온다.
	@Test
	void oneToOneTest2() {
		System.out.println("BookReviewInfoRepositoryTest 클래스의 oneToOneTest2() 메소드 실행");
		System.out.println("Book 정보에서 BookReviewInfo 정보를 가져온다.");

//		리뷰 정보를 저장한다.
		BookReviewInfo bookReviewInfo = new BookReviewInfo();
		bookReviewInfo.setAverageReviewScore(4.5f);
		bookReviewInfo.setReviewCount(2);
		bookReviewInfoRepository.save(bookReviewInfo);
		List<BookReviewInfo> bookReviewInfos = bookReviewInfoRepository.findAll();
		bookReviewInfos.forEach(System.out::println);
		
//		책 정보를 저장한다.
		Book book = new Book();
		book.setName("대충 만든 책");
		book.setCategory("java");
		book.setAuthorId(1L);
		book.setPublisherId(1L);
//		1:1 관계 설정을 위해서 참조할 객체를 넣어준다.
		book.setBookReviewInfo(bookReviewInfo);
		bookRepository.save(book);
		List<Book> books = bookRepository.findAll();
		books.forEach(System.out::println);

//		Book 정보에서 BookReviewInfo 정보를 가져온다.
		BookReviewInfo result = bookRepository.findById(1L).orElse(null).getBookReviewInfo();
		System.out.println("result: " + result);
	}
	
}





