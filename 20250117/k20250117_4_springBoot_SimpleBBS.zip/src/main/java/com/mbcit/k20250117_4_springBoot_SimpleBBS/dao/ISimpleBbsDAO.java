package com.mbcit.k20250117_4_springBoot_SimpleBBS.dao;

import java.util.List;

import com.mbcit.k20250117_4_springBoot_SimpleBBS.vo.SimpleBbsVO;

public interface ISimpleBbsDAO {

	public abstract void insert(SimpleBbsVO simpleBbsVO);
	public abstract List<SimpleBbsVO> selectList();
	public abstract SimpleBbsVO select(int idx);
	public abstract void delete(int idx);
	public abstract void update(SimpleBbsVO simpleBbsVO);
	
}
