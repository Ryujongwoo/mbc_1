package com.mbcit.k20250115_2_springBoot_JavaDI.bean;

public class PrinterA implements Printer {

	@Override
	public void print(String message) {
		System.out.println("PrinterA: " + message);
	}

}
