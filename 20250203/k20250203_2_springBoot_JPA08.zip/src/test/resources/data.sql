-- GenerationType 값이 IDENTITY일 경우 insert sql 명령 실행
insert into member (name, email, create_date, update_date) values ('홍길동', 'hong@mbcit.com', now(), now());
insert into member (name, email, create_date, update_date) values ('임꺽정', 'lim@mbcit.com', now(), now());
insert into member (name, email, create_date, update_date) values ('장길산', 'jang@mbcit.com', now(), now());
insert into member (name, email, create_date, update_date) values ('일지매', 'il@mbcit.com', now(), now());
insert into member (name, email, create_date, update_date) values ('홍길동', 'gildong@mbcit.com', now(), now());
insert into member (name, email, create_date, update_date) values ('홍길동', 'hong@mbcit.com', now(), now());

-- GenerationType 값이 SEQUENCE 경우 insert sql 명령 실행
/*
insert into member (id, name, email, create_date, update_date) values (nextval('member_id_seq'), '홍길동', 'hong@mbcit.com', now(), now());
insert into member (id, name, email, create_date, update_date) values (nextval('member_id_seq'), '임꺽정', 'lim@mbcit.com', now(), now());
insert into member (id, name, email, create_date, update_date) values (nextval('member_id_seq'), '장길산', 'jang@mbcit.com', now(), now());
insert into member (id, name, email, create_date, update_date) values (nextval('member_id_seq'), '일지매', 'il@mbcit.com', now(), now());
insert into member (id, name, email, create_date, update_date) values (nextval('member_id_seq'), '홍길동', 'gildong@mbcit.com', now(), now());
insert into member (id, name, email, create_date, update_date) values (nextval('member_id_seq'), '홍길동', 'hong@mbcit.com', now(), now());
*/















