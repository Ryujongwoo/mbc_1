package com.mbcit.k20250116_2_springBoot_JspUse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class HomeController {

	@RequestMapping("/")
	public @ResponseBody String home() {
		return "JSP in Maven";
	}
	
	@RequestMapping("/jspTest")
	public String jspTest() {
		System.out.println("HomeController 클래스의 jspTest() 메소드 실행");
//		application.properties 파일의 spring.mvc.view.prefix에 지정한 내용과 spring.mvc.view.suffix에
//		지정한 내용이 return 되는 내용의 앞, 뒤에 붙어서 viewpage를 요청한다.
//		spring.mvc.view.suffix + return 값 + spring.mvc.view.suffix
//		/WEB-INF/views/ + jspTest + .jsp => /WEB-INF/views/jspTest.jsp
		return "jspTest";
	}
	
	@RequestMapping("/jspTest2")
	public String jspTest2() {
		System.out.println("HomeController 클래스의 jspTest2() 메소드 실행");
		return "sub/jspTest2";
	}
	
}
















