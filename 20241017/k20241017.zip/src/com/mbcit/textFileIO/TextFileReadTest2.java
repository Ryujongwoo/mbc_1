package com.mbcit.textFileIO;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Arrays;
import java.util.Scanner;

public class TextFileReadTest2 {

	public static void main(String[] args) {
		
		Scanner scanner = null;
		String filepath = "./src/com/mbcit/textFileIO/input.txt";
		
		try {
			scanner = new Scanner(new File(filepath)); // 파일에서 읽어들이는 스캐너
			while (scanner.hasNextLine()) {
				String str = scanner.nextLine().trim();
				System.out.println(str);
//				Scanner로 읽어들인 데이터를 split() 메소드로 구분자를 경계로 나누면 리턴되는 배열에서
//				인덱스를 지정해서 변수에 저장해서 처리한다.
//				System.out.println(Arrays.toString(str.split(" ")));
//				System.out.println(str.split(" ")[0]);
//				System.out.println(str.split(" ")[1]);
//				System.out.println(str.split(" ")[2]);
//				System.out.println(str.split(" ")[3]);
				
//				String 변수에 저장된 문자열에서 읽어들이는 Scanner
//				Scanner 클래스 객체를 만들때 생성자의 인수로 String 변수를 넘겨주면 String 변수에
//				저장된 데이터를 읽어들이는 Scanner가 만들어진다.
				Scanner scan = new Scanner(str); // 문자열에서 읽어들이는 스캐너
				
				int i = 0;
				boolean b = false;
				double d = 0;
				String s = "";
				
//				hasNext(): 스캐너로 읽어들일 데이터가 공백을 경계로 읽어들일 데이터가 있으면 true,
//				없으면 false를 리턴한다.
				while (scan.hasNext()) {
//					System.out.println(scan.next());
					if (scan.hasNextInt()) { // 읽어들이려는 데이터가 int면 true, 아니면 false
						i = scan.nextInt();
					} else if (scan.hasNextBoolean()) { // 읽어들이려는 데이터가 boolean면 true, 아니면 false
						b = scan.nextBoolean();
					} else if (scan.hasNextDouble()) { // 읽어들이려는 데이터가 double면 true, 아니면 false
						d = scan.nextDouble();
					} else {
						s = scan.next();
					}
				}
				
				System.out.println("i: " + i);
				System.out.println("b: " + b);
				System.out.println("d: " + d);
				System.out.println("s: " + s);
			}
			System.out.println("텍스트 파일에서 읽기 완료!!!");
		} catch (FileNotFoundException e) {
			System.out.println("파일의 경로가 잘못되었거나 파일이 존재하지 않습니다.");
		}
		
	}
	
}














