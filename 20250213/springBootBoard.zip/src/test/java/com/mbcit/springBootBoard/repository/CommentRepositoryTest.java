package com.mbcit.springBootBoard.repository;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.context.SpringBootTest;

import com.mbcit.springBootBoard.entity.Article;
import com.mbcit.springBootBoard.entity.Comment;

//	@SpringBootTest 어노테이션은 full application config을 로드해서 통합 테스트를 실행한다.
//	@DataJpaTest 어노테이션은 JPA 컴포넌트만 대상으로 테스트를 실행한다.
//	@SpringBootTest 어노테이션을 붙여주면 springBoot와 연동한 통합 테스트를 수행할 수 있고
//	@DataJpaTest 어노테이션을 붙여주면 JPA와 연동한 테스트를 수행할 수 있다.
@DataJpaTest
class CommentRepositoryTest {

	@Autowired
	private CommentRepository commentRepository;
	
//	특정 질문글의 모든 댓글을 조회하는 메소드 테스트
	@Test
	@Transactional
//	@DisplayName 어노테이션은 JUnit 테스트 실행 결과에 메소드 이름을 대신해서 출력할 제목을 지정한다.
	@DisplayName("특정 질문글의 모든 댓글을 조회하는 메소드 테스트")
	void testFindByArticleId() {
//		1번 질문글의 모든 답변글 조회 => 답변글 있음
		{
			Long articleId = 1L;
//			예상
			Article article = new Article(articleId, "질문1", "가장 재미있게 시청한 드라마는 무엇입니까?");
			List<Comment> expected = new ArrayList<>();
			expected.add(new Comment(1L, "홍길동", "태양의 후예", article));
			expected.add(new Comment(2L, "임꺽정", "태왕 사신기", article));
			expected.add(new Comment(3L, "장길산", "응답하라 1998", article));
			expected.add(new Comment(4L, "일지매", "중증외상센터", article));
//			expected.forEach(System.out::println);
//			실제
			List<Comment> actual = commentRepository.findByArticleId(articleId);
//			actual.forEach(System.out::println);
//			비교
			assertEquals(expected.toString(), actual.toString(), "1번 질문글의 모든 답변글 조회");
		}
		
//		4번 질문글의 모든 답변글 조회 => 답변글 없음
		{
			Long articleId = 4L;
			List<Comment> expected = new ArrayList<>();
			List<Comment> actual = commentRepository.findByArticleId(articleId);
			assertEquals(expected.toString(), actual.toString(), "4번 질문글의 모든 답변글 조회");
		}
	}

//	특정 닉네임의 모든 댓글을 조회하는 메소드 테스트
	@Test
	@Transactional
//	@DisplayName 어노테이션은 JUnit 테스트 실행 결과에 메소드 이름을 대신해서 출력할 제목을 지정한다.
	@DisplayName("특정 닉네임의 모든 댓글을 조회하는 메소드 테스트")
	void testFindByNickname() {
//		홍길동 닉네임의 모든 답변글 조회 => 답변글 있음
		{
			String nickname = "홍길동";
//			예상
			List<Comment> expected = new ArrayList<>();
			expected.add(new Comment(1L, nickname, "태양의 후예", 
				new Article(1L, "질문1", "가장 재미있게 시청한 드라마는 무엇입니까?")
			));
			expected.add(new Comment(5L, nickname, "짜장면", 
				new Article(2L, "질문2", "가장 맛있게 먹었던 음식은 무엇입니까?")
			));
			expected.add(new Comment(9L, nickname, "등산", 
				new Article(3L, "질문3", "당신의 취미는 무엇입니까?")
			));
//			expected.forEach(System.out::println);
//			실제
			List<Comment> actual = commentRepository.findByNickname(nickname);
//			expected.forEach(System.out::println);
//			비교
			assertEquals(expected.toString(), actual.toString(), "홍길동 닉네임의 모든 답변글 조회");
		}
		
//		손오공 닉네임의 모든 답변글 조회 => 답변글 없음
		{
			String nickname = "손오공";
			List<Comment> expected = new ArrayList<>();
			List<Comment> actual = commentRepository.findByNickname(nickname);
			assertEquals(expected.toString(), actual.toString(), "손오공 닉네임의 모든 답변글 조회");
		}
	}
	
}


















