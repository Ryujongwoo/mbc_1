function timer(time) {
	return new Promise((resolve, reject) => setTimeout(() => resolve(time), time));
}

//	all() => 전체 => 모든 Promise가 정상적으로 실행된다.
//	all() 함수의 인수로 병렬 처리할 Promise가 저장된 배열을 전달하면 배열로 전달된 모든 Promise가 종료된 후
//	리턴 값(배열)이 then()으로 전달된다.

console.time('Promise.all 실행 시간');
Promise.all([timer(2000), timer(3000), timer(1000)])
	.then(function (result) {
		console.log('result:', result);
		console.timeEnd('Promise.all 실행 시간');
	});

//	race() => 경쟁 => 가장 먼저 종료되는 Promise만 실행된다.
//	race() 함수의 인수로 병렬 처리할 Promise가 저장된 배열을 전달하면 배열로 전달된 모든 Promise 중에서
//	가장 먼저 종료된 Promise의 리턴 값이 then()으로 전달된다. => 나머지는 Promise는 무시된다.

console.time('Promise.race 실행 시간');
Promise.race([timer(2000), timer(3000), timer(1000)])
	.then(function (result) {
		console.log('result:', result);
		console.timeEnd('Promise.race 실행 시간');
	});

