package com.mbcit.k20250120_1_springBoot_Mybatis.jdbc;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

//	@Mapper 어노테이션은 실행할 sql 명령 구현을 xml 파일로 한다는 의미이다.
@Mapper
public interface MyUserDAO {

	public abstract List<MyUserVO> list();

}
