package com.mbcit.k20250120_1_springBoot_Mybatis.jdbc;

import lombok.Data;

@Data
public class MyUserVO {

	private String id;
	private String name;
	
}
