const dog = {
	name: '강아지',
	sound: '멍멍',
	
//	객체의 멤버로 함수를 가질 수 있다. => 멤버 함수
//	객체 내부에 함수를 정의하고 key에 할당하므로 함수 이름은 의미가 없으므로 익명 함수로 만들어 할당한다.
	/*
	say: function () {
		// console.log(sound); // 에러
		// 객체에서 정한한 함수에서 객체의 멤버 변수를 참조하려면 자기 자신을 의미하는 'this'를 붙여야 한다.
		console.log(this.sound);
	}
	*/
	
//	화살표 함수는 'this'를 사용할 수 없다. 
//	say: () => console.log(this.sound) // undefined
	
//	key에 할당하지 않고 바로 함수를 정의할 수 있는데 이 때 function을 사용하면 안된다.
	say() {
		console.log(this.sound);
	}
}

console.log(dog);
console.log(dog.name);
console.log(dog.sound);

dog.say(); // 객체에서 정의한 함수를 실행한다.
console.log('============================');

//	객체 외부에서 작성한 함수를 객체에 주입할 수 있다.
const cat = {
	name: '고양이',
	sound: '야옹'
}

console.log(cat); // 주입전

//	객체 외부에서 객체에 주입할 함수를 만든다.
/*
function say() {
	console.log(this.sound);
}
*/
/*
const say = function () {
	console.log(this.sound);
}
*/

//	객체 외부에서 만든 say() 함수를 cat 객체에 주입한다.
// cat.say = say;

cat.say = function () {
	console.log(this.sound);
}
//	객체 외부에서 정의한 함수를 객체에 주입할 때도 화살표 함수를 사용하면 'this'를 사용할 수 없다.
//	cat.say = () => console.log(this.sound); // undefined

console.log(cat); // 주입후
cat.say();
console.log('============================');

//	다른 객체에서 작성된 함수를 객체에 주입할 수 있다
//	dog 객체의 say() 함수를 cat 객체에 주입한다.
cat.say2 = dog.say;
console.log(cat);
cat.say2();
console.log('============================');

//	getter, setter를 사용하면 객체의 값을 얻어오거나 넣어줄 때 필요한 기능을 실행할 수 있다.
const numbers = {
	a: 1,
	b: 2,
	
//	getter: get으로 선언하는 함수
//	getter 함수는 특정 멤버 변수에 저장된 값을 얻어올 때 사용한다.
	get sum() {
		console.log('sum() 함수가 실행됩니다.');
		// getter 함수는 값을 얻어오는 함수이므로 return을 사용하지 않으면 getter 함수의 실행 결과는
		// undefined가 된다.
		return this.a + this.b;
	}
}

console.log(numbers);
console.log(numbers.a);
console.log(numbers.b);

//	getter 함수를 실행할 때는 함수 뒤에 ()를 붙이지 않는다.
//	numbers.sum(); // numbers.sum is not a function 에러 발생
console.log(numbers.sum); // getter 함수 실행
console.log('============================');

const bull = {
	_name: '황소',
	
	get name() {
		console.log('값을 가져오기 전에 필요한 기능을 실행한다.');
		return this._name;
	},
	
//	setter: set으로 선언하는 함수
//	setter 함수도 getter 함수와 마찬가지로 실행할 때 함수 이름뒤에 ()를 붙이면 안된다.
//	setter 함수는 특정 멤버 변수에 값을 저장할 때 사용한다.
//	setter 함수의 인수 이름은 어떤 이름을 사용해도 상관없지만 일반적으로 value를 사용한다.
	set name(value) {
		console.log('_name의 값을 변경한다.');
		this._name = value;
	}
}

console.log(bull.name); // getter 실행
bull.name = '암소'; // setter 실행
console.log(bull)
console.log('============================');

const numbers2 = {
	_a: 1,
	_b: 2,
	sum: 3,
	
	calculator() {
		this.sum = this._a + this._b;
		console.log(`a: ${this._a}, b: ${this._b}, sum: ${this.sum}`);
	},
	
	get a() {
		return this._a;
	},
	get b() {
		return this._b;
	},
	
	set a(value) {
		this._a = value;
		this.calculator();
	},
	set b(value) {
		this._b = value;
		this.calculator();
	}
}

console.log(numbers2);
//	numbers2 객체 내부에서는 이름이 '_a'지만 numbers2 객체 외부에서는 'a'를 사용한다.
console.log(numbers2.a);
//	numbers2 객체 내부에서는 이름이 '_b'지만 numbers2 객체 외부에서는 'b'를 사용한다.
console.log(numbers2.b);

numbers2.a = 8;
numbers2.b = 5;

