package com.mbcit.k20250121_1_springBoot_JPA01.domain;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@NoArgsConstructor
@Data
@Entity
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class Author extends BaseEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private String name;
	private String country;
	
//	1명의 저자(Author)는 여러권의 책(Book)을 쓸 수 있고 책 1권은 여러명의 저자가 같이 쓸 수 있으므로
//	저자와 책은 N:M 관계가 성립되므로 @ManyToMany 어노테이션을 사용해서 N:M 관계로 설정한다.
	@ManyToMany
//	StackOverflowError가 발생되면 @ToString.Exclude를 붙여준다.
	@ToString.Exclude
	private List<Book> books = new ArrayList<>();

	public void addBook(Book ... books) {
//		if (books != null) {
//			for (Book book : books) {
//				this.books.add(author);
//			}
//		}
		Collections.addAll(this.books, books);
	}
	
//	Author 엔티티와 Relation 엔티티는 1:N 관계이므로 @OneToMany 어노테이션을 사용해서 N:1 관계로 설정한다.
	@OneToMany
//	@JoinColumn 어노테이션으로 연결될 필드를 지정해서 중간 테이블이 생성되지 않도록 한다.
	@JoinColumn(name = "author_id")
//	StackOverflowError가 발생되면 @ToString.Exclude를 붙여준다.
	@ToString.Exclude
	List<Relation> relations = new ArrayList<>();
	
	public void addRelation(Relation ... relations) {
		Collections.addAll(this.relations, relations);
	}
	
}












