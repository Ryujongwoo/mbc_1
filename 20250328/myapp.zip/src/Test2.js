import React, { useRef } from 'react';

// Ref라는 컴포넌트를 만든다.
function Ref() {
  // useRef() hook 함수는 변경할 수 있는 ref 객체를 반환하며 DOM 노드에 접근하는 등의 작업에 사용한다.
  // const current라는 key와 초기치가 value로 저장된 객체 = useRef(current의 초기치);
  // inputRef라는 ref 객체를 만들고 current를 null로 초기화 시킨다.
  const inputRef = useRef(null);
  // console.log('useRef:', inputRef);

  return (
    <div align="center">
      <h1>Ref</h1>
      {/*
        JSX 요소인 ref 속성을 사용해서 useRef() 함수로 생성한 객체를 전달한다.
        inputRef는 ref 속성이 지정된 input 태그를 참조하게 되고 inputRef의 current에는 input 태그가 
        저장된다.
      */}
      <input ref={inputRef} />
      <button type='button' onClick={
        function () {
          console.log('useRef:', inputRef);
          // inputRef.current를 이용해서 특정 DOM 노드에 접근할 수 있다.
          inputRef.current.focus();
          inputRef.current.value = '홍길동';
        }
      }>Focus Input</button>
    </div>
  )
}

// 컴포넌트를 다른 js 파일에서 사용하려면 반드시 export를 시켜야 한다.
export default Ref;
