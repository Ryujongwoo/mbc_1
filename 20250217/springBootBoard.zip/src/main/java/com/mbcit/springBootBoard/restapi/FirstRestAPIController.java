package com.mbcit.springBootBoard.restapi;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import lombok.extern.slf4j.Slf4j;

//	RestAPI용 컨트롤러는 @Controller 어노테이션이 아닌 @RestController 어노테이션을 붙여서 선언한다.
//	@Controller 어노테이션을 붙여서 선언한 컨트롤러는 viewpage를 리턴하지만 @RestController 어노테이션을
//	붙여서 선언한 컨트롤러는 JSON을 리턴한다.
@RestController
@Slf4j
public class FirstRestAPIController {

	@GetMapping("/restapi/hello")
	public String hello() {
		log.info("FirstRestAPIController의 hello() 메소드 실행");
		return "hello restAPI";
	}
	
}
