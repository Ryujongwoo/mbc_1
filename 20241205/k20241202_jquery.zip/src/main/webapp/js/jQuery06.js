$(() => {
//	id 속성 값이 errorMsg로 지정된 span 태그(에러 메시지)를 숨긴다.
	$('#errorMsg').hide();
//	id 속성 값이 userID로 지정된 텍스트 상자에 포커스를 위치시킨다.
	$('#userID').focus();
	
//	id 속성 값이 single로 지정된 form 태그에서 submit 버튼이 클릭되면 실행할 이벤트를 정의한다.
//	submit 이벤트는 input 태그나 button 태그의 type 속성 값이 submit인 버튼이 클릭되면 발생되는 이벤트이다.
//	submit 이벤트에서는 서버로 form의 데이터를 전송하기 전에 form의 유효성을 검사해서 입력된 데이터에 이상이
//	없으면 true를 리턴시키고 이상이 있으면 에러 메시지를 출력하고 false를 리턴시킨다.
//	submit 이벤트의 실행 결과가 true(기본값)면 action 속성에 지정된 페이지로 이동하고 실행 결과가 false면
//	현재 페이지에 그대로 머물러 있는다.

	$('#single').submit(function () {
		// alert('submit 버튼을 클릭했습니다.');
		// let userID = $('input:eq(0)').val().trim();
		// let userID = $('input[type=text]:eq(0)').val().trim();
		// let userID = $('input:text:eq(0)').val().trim();
		// let userID = $('input[name=userID]:eq(0)').val().trim();
		// let userID = $('input[id=userID]:eq(0)').val().trim();
		let userID = $('#userID').val().trim();
		// console.log(userID);
		if (userID == null || userID == undefined || userID == '') { // 유효성 검사
			$('#userID').val('');
			$('#userID').focus();
			$('#errorMsg').show(); // 시작할 때 감춰둔 에러 메시지를 표시한다.
			// 유효성 검사를 통과하지 못했으면 현재 페이지에 머무르도록 false를 리턴시킨다.
			return false;
		}
		// 유효성 검사를 통과했으면 action에 지정한 페이지로 이동하도록 true를 리턴시킨다.
		return true; // submit 이벤트는 true가 기본값이므로 return true를 생략해도 된다.
	});
	
//	전체 선택 체크 박스가 클릭되면 모든 체크 박스를 선택 또는 해제한다.
	$('input:checkbox[name=all]:eq(0)').click(function () {
		// console.log('전체 선택 체크 박스 클릭');
		// name 속성의 속성 값이 all인 체크 박스의 선택 여부를 얻어온다.
		// prop('속성이름'): 인수로 지정된 속성의 프로퍼티를 얻어온다.
		let check = $('input:checkbox[name=all]:eq(0)').prop('checked');
		// console.log(check);
		
		// name 속성의 속성 값이 chk인 모든 체크 박스의 프로퍼티를 name 속성의 속성 값이 all인 체크 박스의
		// 프로퍼티로 변경한다.
		// prop('속성이름', 프로퍼티): 인수로 지정된 속성의 프로퍼티를 변경한다.
		/*
		$('input:checkbox[name=chk]').each(function (index, obj) {
			$('input:checkbox[name=chk]').eq(index).prop('checked', check);
		});
		*/
		/*
		$('input:checkbox[name=chk]')
			.each(index => $('input:checkbox[name=chk]').eq(index).prop('checked', check));
		*/
		$('input:checkbox[name=chk]').each(function () {
			$(this).prop('checked', check);
		});
	});
	
//	name 속성의 속성 값이 chk인 체크 박스가 클릭되면 name 속성의 속성 값이 chk인 모든 체크 박스가 체크되었나
//	검사해서 모두 체크되었으면 전체 선택 체크 박스를 체크하고 그렇치 않으면 전체 선택 체크 박스의 체크를
//	해제한다.
	$('input:checkbox[name=chk]').click(function () {
		// console.log('name 속성의 속성 값이 chk인 체크 박스 클릭');
		// name 속성의 속성 값이 chk인 요소 전체의 개수와 name 속성의 속성 값이 chk인 요소 중에서 체크된 요소의
		// 개수와 비교한다.
		// console.log('name 속성의 속성 값이 chk인 요소 전체의 개수: ' + $('input:checkbox[name=chk]').length);
		// console.log('name 속성의 속성 값이 chk인 요소 중에서 선택된 요소의 개수: ' + 
		//	$('input:checkbox[name=chk]:checked').length);
		if ($('input:checkbox[name=chk]').length === $('input:checkbox[name=chk]:checked').length) {
			// console.log('모두 체크됨');
			$('input:checkbox[name=all]').prop('checked', true);
		} else {
			// console.log('모두 체크되지 않음');
			$('input:checkbox[name=all]').prop('checked', false);
		}
	});
	
//	형제(sibling) 요소 탐색
//	.sibling(): 선택된 요소의 형제 요소 중에서 지정한 선택자에 해당되는 모든 형제 요소를 선택한다.
//	.next(): 선택된 요소 바로 다음에 위치한 형제 요소 1개를 선택한다.
//	.nextAll(): 선택된 요소 바로 다음에 위치한 모든 형제 요소를 선택한다.
//	.nextUntil(): 선택된 요소 바로 다음에 위치한 형제 요소 중에서 지정한 선택자에 해당되는 요소 바로
//		이전까지의 모든 형제 요소를 선택한다.
//	.prev(): 선택된 요소 바로 이전에 위치한 형제 요소 1개를 선택한다.
//	.prevAll(): 선택된 요소 바로 이전에 위치한 모든 형제 요소를 선택한다.
//	.prevUntil(): 선택된 요소 바로 이전에 위치한 형제 요소 중에서 지정한 선택자에 해당되는 요소 바로
//		다음까지의 모든 형제 요소를 선택한다.
	
//	과일 이름이 지정된 체크 상자에 체크하고 확인 버튼을 클릭하면 id 속성의 속성 값이 result인 div
//	태그 내부에 과일 이름과 과일 가격을 출력한다.
	$('#confirm').click(function () {
		// console.log('확인 버튼  click 이벤트 실행');
		// name 속성의 속성 값이 chk인 체크 박스 중에서 체크된 항목의 개수를 얻어온다.
		let chk = $('input:checkbox[name=chk]:checked');
		// console.log(chk.length);
		
		// 선택한 과일 이름과 가격이 표시될 div 태그 내부의 내용을 지운다.
		// $('#result').text('');
		// $('#result').html('');
		// empty(): 선택된 태그 요소의 내부 내용을 지운다.
		$('#result').empty();
		
		if (chk.length === 0) {
			$('#result').html('<b style="color: red;">과일을 1개 이상 선택하세요</b>');
		} else {
			chk.each(function (index) {
				let obj = chk.eq(index);
				// console.log(obj); // <input type="checkbox" name="chk" value="1000"/>
				// console.log(obj.val()); // 1000
				// console.log(obj.next()); // <span>사과</span>
				// console.log(obj.next().html()); // 사과
				
				// $('#result').html(`<b>과일 이름: ${obj.next().html()}, 과일 가격: ${obj.val()}</b><br/>`);
				// text(), html()을 사용하면 기존의 내용에 덮어쓰기가 된다.
				// append(): text(), html()와 같이 태그 내부에 문자열을 넣어준다. 차이점은 기존의 내용을 지우지 않고
				// 뒤에 새로운 내용을 추가한다.
				$('#result').append(`<b>과일 이름: ${obj.next().html()}, 과일 가격: ${obj.val()}</b><br/>`);
			})
		}
	});
});

