insert into article(title, content) values ('홍길동', '1등 입니다.');
insert into article(title, content) values ('임꺽정', '2등 입니다.');
insert into article(title, content) values ('장길산', '3등 입니다.');
insert into article(title, content) values ('일지매', '4등 입니다.');