package com.mbcit.k20250116_6_springBoot_Validator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class K202501166SpringBootValidatorApplicationTests {

	@Test
	void contextLoads() {
	}

}
