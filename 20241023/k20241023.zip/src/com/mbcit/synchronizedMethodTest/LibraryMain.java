package com.mbcit.synchronizedMethodTest;

public class LibraryMain {

	static Library library = new Library();
	
	public static void main(String[] args) {
		
		/*
		System.out.println(library);
		String book = library.bookList.remove(0);
		System.out.println(book); // 다빈치 코드
		System.out.println(library);
		
//		ArrayList의 remove(index) 메소드를 실행하면 지정된 index의 데이터를 러턴하고 제거한다.
//		index가 ArrayList index의 범위를 벗어나면 IndexOutOfBoundsException이 발생된다.
//		ArrayList의 remove(object) 메소드를 실행하면 제거할 객체가 있으면 true를 리턴하고 제거하고
//		제거할 객체가 없으면 false를 리턴한고 아무런 동작도 하지 않는다.
		System.out.println(library.bookList.remove(0)); // 천사와 악마
//		System.out.println(library.bookList.remove(4)); // 예외 발생
		System.out.println(library.bookList.remove("라스트 심볼")); // true
		System.out.println(library.bookList.remove("다빈치 코드")); // false
		*/
		
		Student student1 = new Student("홍길동");
		Student student2 = new Student("임꺽정");
		Student student3 = new Student("장길산");
		Student student4 = new Student("일지매");
		Student student5 = new Student("이몽룡");
		Student student6 = new Student("성춘향");
		
		student1.start();
		student2.start();
		student3.start();
		student4.start();
		student5.start();
		student6.start();
		
	}
	
}




















