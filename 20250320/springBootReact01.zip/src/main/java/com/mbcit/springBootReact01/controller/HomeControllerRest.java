package com.mbcit.springBootReact01.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HomeControllerRest {

	@GetMapping("/hello-rest")
//	REST API용 컨트롤러는 @Controller 어노테이션이 아닌 @RestController 어노테이션을 붙여서 선언한다.
//	@Controller를 뷰 페이지 이름을 리턴하지만 @RestController는 JSON을 리턴한다.
	public String home() {
		return "hello rest controller";
	}
	
}
