function searchID() {
	let doc = document.getElementById('test');
	console.log(doc);
	console.log(doc.length); // 객체 배열이 아니기 때문에 undefined가 출력된다. 
	doc.innerHTML += '<br/>&nbsp;&nbsp;&nbsp;&nbsp;getElementById() 함수는 DOM에서 id 속성 값을 선택한다.';
	doc.style.backgroundColor = 'orange';
}

function searchName() {
	let docs = document.getElementsByName('test'); // NodeList
//	let docs = document.getElementsByTagName('test'); // HTMLCollection
	console.log(docs);
	console.log(docs.length); // 객체 배열이므로 배열의 크기가 출력된다. 
	
//	docs[0].value = '홍길동';
//	docs[1].value = '임꺽정';
//	docs[2].value = '장길산';

	const names = ['홍길동', '임꺽정', '장길산'];
	
//	for (let i = 0; i < docs.length; i++) {
//		docs[i].value = names[i];
//	}

//	let i = 0;
//	for (let doc of docs) {
//		doc.value = names[i++];
//	}

//	for (let i in docs) {
//		docs[i].value = names[i];
//	}

//	배열이름.forEach(함수(변수[, 인덱스]) {})
//	변수에는 배열에 저장된 각 인덱스의 데이터가 차례대로 넘어가고 인덱스에는 변수에 저장된 데이터의 인덱스가 
//	저장된다.
//	DOM 선택 함수 중에서 getElementsByName()은 NodeList 객체로 얻어오고 getElementsByTagName()과
//	getElementsByClassName()은 HTMLCollection 객체로 얻어온다.
//	HTMLCollection 객체에는 forEach()를 사용할 수 없다.

//	docs.forEach(function (doc, i) {
//		// console.log(doc, i);
//		doc.value = names[i];
//	});

	docs.forEach((doc, i) => doc.value = names[i]);
}

function searchTagName() {
	let docs = document.getElementsByTagName('p');
	console.log(docs);
	console.log(docs.length); 
	
	for (let i = 0; i < docs.length; i++) {
		docs[i].style.backgroundColor = 'hotpink';
	}

//	for (let doc of docs) {
//		doc.style.backgroundColor = 'tomato';
//	}

//	for (let i in docs) {
//		docs[i].style.backgroundColor = 'yellowgreen';
//	}

//	docs.forEach((doc, i) => doc.style.backgroundColor = 'yellow'); // 에러 발생
}

function searchClassName() {
	let docs = document.getElementsByClassName('test');
	console.log(docs);
	console.log(docs.length); 
	
	for (let i = 0; i < docs.length; i++) {
		docs[i].style.backgroundColor = 'skyblue';
	}
	
//	docs.forEach((doc, i) => doc.style.backgroundColor = 'yellow'); // 에러 발생
}

function searchCSSSelector() {
//	id 속성 값으로 선택
//	querySelector('#id속성값') => getElementById('id속성값')
	let doc = document.querySelector('#test');
	doc.innerHTML = 'querySelector()로 id 탐색';
	doc.style.color = 'red';
	doc.style.backgroundColor = 'skyblue';
	
//	class 속성 값으로 선택
//	querySelectorAll('.class속성값') => getElementsByClassName('class속성값')
	let docs = document.querySelectorAll('.test');
	docs[3].innerHTML = 'querySelectorAll()로 class 탐색';
	docs[3].style.color = 'yellow';
	docs[3].style.backgroundColor = 'green';
	
//	tag 이름으로 선택
//	querySelectorAll('tag이름') => getElementsByTagName('tag이름')
	docs = document.querySelectorAll('p');
	docs[2].innerHTML = 'querySelectorAll()로 tag 탐색';
	docs[2].style.color = 'dodgerblue';
	docs[2].style.backgroundColor = 'tomato';
	
//	name 속성 값으로 선택
//	querySelectorAll('[name="name속성값"]') => getElementsByName('name속성값')
	docs = document.querySelectorAll('[name="test"]');
	console.log(docs);
	docs[0].value = 'querySelectorAll()로 name 속성 선택';
	docs[1].style.backgroundColor = 'hotpink';
	docs[2].style.backgroundColor = 'magenta';
}

