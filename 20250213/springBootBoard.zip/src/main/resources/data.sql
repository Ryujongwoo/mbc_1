-- article(질문글) 테이블 더미 데이터
insert into article(title, content) values ('질문1', '가장 재미있게 시청한 드라마는 무엇입니까?');
insert into article(title, content) values ('질문2', '가장 맛있게 먹었던 음식은 무엇입니까?');
insert into article(title, content) values ('질문3', '당신의 취미는 무엇입니까?');
insert into article(title, content) values ('질문4', '당신이 가장 좋아하는 스포츠는 무엇입니까?');

-- comment(답변글) 테이블 더미 데이터
-- 1번 질문글에 대한 답변글
insert into comment(nickname, body, article_id) values ('홍길동', '태양의 후예', 1);
insert into comment(nickname, body, article_id) values ('임꺽정', '태왕 사신기', 1);
insert into comment(nickname, body, article_id) values ('장길산', '응답하라 1998', 1);
insert into comment(nickname, body, article_id) values ('일지매', '중증외상센터', 1);

-- 2번 질문글에 대한 답변글
insert into comment(nickname, body, article_id) values ('홍길동', '짜장면', 2);
insert into comment(nickname, body, article_id) values ('임꺽정', '짬뽕', 2);
insert into comment(nickname, body, article_id) values ('장길산', '쌀국수', 2);
insert into comment(nickname, body, article_id) values ('일지매', '분짜', 2);

-- 3번 질문글에 대한 답변글
insert into comment(nickname, body, article_id) values ('홍길동', '등산', 3);
insert into comment(nickname, body, article_id) values ('임꺽정', '바둑', 3);
insert into comment(nickname, body, article_id) values ('장길산', '낚시', 3);
insert into comment(nickname, body, article_id) values ('일지매', '없음', 3);
