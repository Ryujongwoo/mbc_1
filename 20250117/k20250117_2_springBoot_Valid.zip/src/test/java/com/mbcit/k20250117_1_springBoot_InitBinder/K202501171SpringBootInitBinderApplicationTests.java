package com.mbcit.k20250117_1_springBoot_InitBinder;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class K202501171SpringBootInitBinderApplicationTests {

	@Test
	void contextLoads() {
	}

}
