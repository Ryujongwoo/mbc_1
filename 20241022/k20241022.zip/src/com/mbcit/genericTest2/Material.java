package com.mbcit.genericTest2;

public interface Material {
//	public class Material {
	
}
