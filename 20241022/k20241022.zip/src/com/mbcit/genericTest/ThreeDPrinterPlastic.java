package com.mbcit.genericTest;

//	재료로 Plastic을 사용하는 3D 프린터 => Plastic 전용 프린터
public class ThreeDPrinterPlastic {

	private Plastic material;

	public Plastic getMaterial() {
		return material;
	}

	public void setMaterial(Plastic material) {
		this.material = material;
	}

	@Override
	public String toString() {
		return material + "을(를) 재료로 사용하는 3D 프린터 사용중";
	}
	
}
