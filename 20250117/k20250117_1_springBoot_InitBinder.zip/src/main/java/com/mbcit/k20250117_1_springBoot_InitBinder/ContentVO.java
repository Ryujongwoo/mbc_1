package com.mbcit.k20250117_1_springBoot_InitBinder;

import lombok.Data;

@Data
public class ContentVO {

	private int id;
	private String writer;
	private String content;
	
}
