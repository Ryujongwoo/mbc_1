package com.mbcit.k20250116_6_springBoot_Validator;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class ContentValidator implements Validator {

	@Override
	public boolean supports(Class<?> clazz) {
		return ContentVO.class.isAssignableFrom(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {
		ContentVO vo = (ContentVO) target;
		
//		String writer = vo.getWriter();
//		if (writer == null || writer.trim().length() == 0) {
//			log.info("작성자가 null이거나 비어있습니다.");
//			errors.rejectValue("writer", "writer 오류");
//		}
		
//		ValidationUtils 클래스의 rejectIfEmptyOrWhitespace() 메소드는 null이거나 비어있는 경우만 유효성을
//		검사할 수 있도록 spring에서 제공하는 유효성 검사 메소드이다.
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "writer", "작성자가 null이거나 비어있습니다.");
		
//		rejectIfEmptyOrWhitespace() 메소드는 null과 공백만 유효성 검사를 할 수 있으므로 그 이외의 유효성을
//		검사하려면 아래와 같이 코드를 작성해야 한다.
		String writer = vo.getWriter();
		if (writer.length() < 3) {
//			log.info("작성자는 3글자 이상 입력해야 합니다.");
			errors.rejectValue("writer", "작성자는 3글자 이상 입력해야 합니다.");
		}
		
//		String content = vo.getContent();
//		if (content == null || content.trim().isEmpty()) {
//			log.info("내용이 null이거나 비어있습니다.");
//			errors.rejectValue("content", "content 오류");
//		}
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "content", "내용이 null이거나 비어있습니다.");
	}

}













