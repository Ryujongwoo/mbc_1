-- 메인글 테이블
CREATE TABLE "FREEBOARD" (
    "IDX" NUMBER(*,0) NOT NULL, 
	"NAME" CHAR(20 BYTE) NOT NULL, 
	"PASSWORD" CHAR(20 BYTE) NOT NULL, 
	"SUBJECT" VARCHAR2(200 BYTE) NOT NULL, 
	"CONTENT" VARCHAR2(3000 BYTE) NOT NULL, 
	"WRITEDATE" TIMESTAMP (6) DEFAULT sysdate, 
	"HIT" NUMBER(*,0) DEFAULT 0, 
	"NOTICE" VARCHAR2(20 BYTE) DEFAULT '', 
	"IP" CHAR(15 BYTE), 
	CONSTRAINT "FREEBOARD_PK" PRIMARY KEY ("IDX")
);

-- 메인글 시퀀스
delete from freeboard;
drop sequence freeboard_idx_seq;
create sequence freeboard_idx_seq;

-- 메인글 더미 데이터
insert into freeboard (idx, name, password, subject, content, ip) 
values (freeboard_idx_seq.nextval, '홍길동', '1111', '1등', '1등 입니다.', '192.168.200.001');
insert into freeboard (idx, name, password, subject, content, ip) 
values (freeboard_idx_seq.nextval, '임꺽정', '2222', '2등', '2등 입니다.', '192.168.200.002');
insert into freeboard (idx, name, password, subject, content, ip) 
values (freeboard_idx_seq.nextval, '장길산', '3333', '3등', '3등 입니다.', '192.168.200.003');
insert into freeboard (idx, name, password, subject, content, ip) 
values (freeboard_idx_seq.nextval, '일지매', '4444', '4등', '4등 입니다.', '192.168.200.004');

select count(*) from freeboard;
select * from freeboard order by idx desc;
select * from freeboard where notice = 'on' order by idx desc;

-- 댓글 테이블
CREATE TABLE "FREEBOARDCOMMENT" (
    "IDX" NUMBER(*,0) NOT NULL, 
	"GUP" NUMBER(*,0), 
	"NAME" CHAR(20 BYTE) NOT NULL, 
	"PASSWORD" CHAR(20 BYTE) NOT NULL, 
	"CONTENT" VARCHAR2(1000 BYTE) NOT NULL, 
	"WRITEDATE" TIMESTAMP (6) DEFAULT sysdate, 
	"IP" CHAR(15 BYTE), 
	CONSTRAINT "FREEBOARDCOMMENT_PK" PRIMARY KEY ("IDX")
);

-- 댓글 시퀀스
delete from freeboardcomment;
drop sequence freeboardcomment_idx_seq;
create sequence freeboardcomment_idx_seq;

select * from freeboardcomment;
