// 스타일드 컴포넌트를 사용하려면 아래와 같이 styled를 import 해야 한다.
import styled from 'styled-components';
import './App.css';

// 스타일드 컴포넌트를 이용해서 스타일을 지정할 때 백틱(`) 내부에서 지정해야 한다.
const SimpleButton = styled.button`
  color: white;
  background-color: green;
`
// 스타일드 컴포넌트의 또 한 가지 기능은 이미 존재하는 스타일드 컴포넌트를 감싸서(래핑해서) 새로운
// 스타일드 컴포넌트를 만들 수 있다.
const LargeButton = styled(SimpleButton)`
  font-size: 50px;
`
/*
// 스타일드 컴포넌트를 사용하지 않고 리액트가 제공하는 일반적인 방법으로 작성한 컴포넌트를
// 스타일드 컴포넌트가 감싸서 새로운 스타일드 컴포넌트를 만들려면 className 속성값으로
// {props.className}를 지정해서 만들어야 한다.
function ReactButton(props) {
  // children prop으로는 태그의 '>'와 '<' 사이의 문자열이 전달된다.
  // className prop으로는 class 속성의 속성값이 전달된다.
  console.log(props, props.children, props.className)
  return (
    <button className={props.className}>{props.children}</button>
  )
}
*/
const ReactButton = props => {
  return (
    <button className={props.className}>{props.children}</button>
  )
}

const ReactLargeButton = styled(ReactButton)`
  font-size: 50px;
`

// 스타일드 컴포넌트로 지정할 속성의 속성값으로 ${} 안에 함수를 정의하면 함수가 리턴하는 값이 스타일로 지정된다.
// ${} 안에 정의하는 함수는 컴포넌트의 props를 받도록 약속돼 있다.
const PrimaryButton = styled.button`
  // color: white
  /*
  color: ${
    function (props) {
      // console.log('props:', props)
      if (props.primary) {
        return 'blue'
      } else {
        return 'red'
      }
    }
  };
  background-color: ${
    function (props) {
      if (props.primary) {
        return 'yellow'
      } else {
        return 'cyan'
      }
    }
  }
  */
 color: ${ props => props.primary ? 'blue' : 'red' };
 background-color: ${ props => props.primary ? 'yellow' : 'cyan' }
`

function App() {
  return (
    <div className="App">
      <SimpleButton>Simple</SimpleButton>
      <LargeButton>Large</LargeButton>
      <ReactButton>ReactButton1</ReactButton>
      <ReactButton>ReactButton2</ReactButton>
      <ReactLargeButton>ReactLargeButton</ReactLargeButton>
      <PrimaryButton>PrimaryButton</PrimaryButton>
      <PrimaryButton primary>PrimaryButton</PrimaryButton>
    </div>
  );
}

export default App;
