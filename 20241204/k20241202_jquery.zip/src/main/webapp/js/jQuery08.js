$(() => {
//	$('div > p > b').eq(1).css({'fontSize': '30px', 'color': 'purple'});
	$('div').find('p').find('b').eq(1).css({'fontSize': '40px', 'color': 'yellowgreen'});
	
//	$('#select').html('<i>야무치</i>');
	$('div').children('#select').html('<i>베지터</i>');
//	children() 함수의 인수를 생략하면 모든 자식 요소가 선택된다.
//	$('div').children().html('<i>베지터</i>');

	$('span').css({'fontSize': '20px', 'backgroundColor': 'tomato'}); // 기준점
	$('span').parent().css('backgroundColor', 'skyblue');
	$('span').parents('div').css('backgroundColor', 'dodgerblue');
//	parents() 함수의 인수를 생략하면 모든 조상 요소가 선택된다.
//	$('span').parents().css('backgroundColor', 'dodgerblue');

	$('p:eq(2)').next().css('backgroundColor', 'lime');
	$('p:eq(2)').prev().css('backgroundColor', 'yellow');
});

