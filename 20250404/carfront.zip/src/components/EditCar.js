import { Button, Dialog, DialogActions, DialogContent, DialogTitle, IconButton, Stack, TextField } from "@mui/material";
import React, { useState } from "react";
import EditIcon from '@mui/icons-material/Edit';

function EditCar(props) {
  const [open, setOpen] = useState(false);
  const [car, setCar] = useState({brand: '', model: '', color: '', year: '', price: ''});

  // 모달 창이 열릴 때 props로 넘어온 수정할 데이터를 모달 창에 넣어준다.
  const handleOpen = () => {
    setCar({
      brand: props.data.row.brand,
      model: props.data.row.model,
      color: props.data.row.color,
      year: props.data.row.year,
      price: props.data.row.price
    });
    setOpen(true);
  }

  const handleClose = () => setOpen(false);
  const handleChange = function (event) {
    setCar({...car, [event.target.name]: event.target.value});
  }
  // 자동차를 수정하고 모달 창을 닫는 함수
  const handleSave = function () {
    props.updateCar(car, props.data.id);
    handleClose();
  }

  return (
    <div>
      {/* <Button type="button" variant="outlined" onClick={handleOpen}>Edit Car</Button> */}
      <IconButton onClick={handleOpen}>
        <EditIcon color="success"/>
      </IconButton>
      <Dialog open={open} onClose={handleClose}>
        <DialogTitle>Edit Car</DialogTitle>
        <DialogContent>
          <Stack spacing={2} mt={1}>
            <TextField name="brand" label="Brand" value={car.brand} onChange={handleChange}/>
            <TextField name="model" label="Model" value={car.model} onChange={handleChange}/>
            <TextField name="color" label="Color" value={car.color} onChange={handleChange}/>
            <TextField name="year" label="Year" value={car.year} onChange={handleChange}/>
            <TextField name="price" label="Price" value={car.price} onChange={handleChange}/>
          </Stack>
        </DialogContent>
        <DialogActions>
          <Button type="button" variant="outlined" onClick={handleSave}>Save</Button>
          <Button type="button" variant="outlined" onClick={handleClose}>Cancel</Button>
        </DialogActions>
      </Dialog>
    </div>
  )
}

export default EditCar;