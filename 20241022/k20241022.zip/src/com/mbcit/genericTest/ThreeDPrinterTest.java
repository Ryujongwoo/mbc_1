package com.mbcit.genericTest;

public class ThreeDPrinterTest {

	public static void main(String[] args) {
		
//		Plastic 전용 3D 프린터
//		Plastic을 재료로 사용하는 3D 프린터를 만든다.
		ThreeDPrinterPlastic printerPlastic = new ThreeDPrinterPlastic();
//		Plastic 재료로 사용하는 3D 프린터에 사용할 재료를 만든다.
		Plastic plastic = new Plastic();
//		3D 프린터에 재료를 넣는다.
		printerPlastic.setMaterial(plastic);
//		3D 프린터를 사용한다.
		System.out.println(printerPlastic);
//		3D 프린터 사용이 종료되면 재료를 꺼낸다.
		plastic = printerPlastic.getMaterial();
		System.out.println("=====================================================");
		
//		Powder 전용 3D 프린터
		ThreeDPrinterPowder printerPowder = new ThreeDPrinterPowder();
		Powder powder = new Powder();
		printerPowder.setMaterial(powder);
		System.out.println(printerPowder);
		powder = printerPowder.getMaterial();
		System.out.println("=====================================================");
		
//		Plastic과 Powder를 모두 재료로 사용하는 프린터 => Object 클래스
		ThreeDPrinter threeDPrinter = new ThreeDPrinter();
		
//		Plastic을 재료로 사용한다.
		threeDPrinter.setMaterial(plastic); // UpCasting
		System.out.println(threeDPrinter);
//		자식 객체를 부모 객체에 넣을 때(UpCasting)는 별다른 문제가 발생되지 않지만 부모 객체에 저장된
//		자식 객체를 다시 자식 객체로 넣을 때(DownCasting)는 반드시 형변환 시켜서 넣어야 한다.
		plastic = (Plastic) threeDPrinter.getMaterial(); // DownCasting
		
//		Powder를 재료로 사용한다.
		threeDPrinter.setMaterial(powder); // UpCasting
		System.out.println(threeDPrinter);
		powder = (Powder) threeDPrinter.getMaterial(); // DownCasting
		
//		Water를 재료로 사용한다.
		Water water = new Water();
		threeDPrinter.setMaterial(water);
		System.out.println(threeDPrinter);
		water = (Water) threeDPrinter.getMaterial();
		System.out.println("=====================================================");
		
//		Plastic과 Powder를 모두 재료로 사용하는 프린터 => generic
		GenericPrinter<Plastic> genericPrinter = new GenericPrinter<Plastic>();
		genericPrinter.setMaterial(plastic);
		System.out.println(genericPrinter);
		plastic = genericPrinter.getMaterial();
		
		GenericPrinter<Powder> genericPrinter2 = new GenericPrinter<Powder>();
		genericPrinter2.setMaterial(powder);
		System.out.println(genericPrinter2);
		powder = genericPrinter2.getMaterial();
		
		GenericPrinter<Water> genericPrinter3 = new GenericPrinter<Water>();
		genericPrinter3.setMaterial(water);
		System.out.println(genericPrinter3);
		water = genericPrinter3.getMaterial();
		
	}
	
}





















