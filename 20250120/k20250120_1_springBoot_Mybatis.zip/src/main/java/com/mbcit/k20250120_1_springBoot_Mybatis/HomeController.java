package com.mbcit.k20250120_1_springBoot_Mybatis;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.mbcit.k20250120_1_springBoot_Mybatis.jdbc.MyUserDAO;
import com.mbcit.k20250120_1_springBoot_Mybatis.jdbc.MyUserVO;

import lombok.extern.slf4j.Slf4j;

@Controller
@Slf4j
public class HomeController {

//	컨트롤러에서 Mybatis mapper를 사용하기 위해서 @Mapper 어노테이션을 붙여 선언한 인터페이스 객체의
//	bean을 얻어온다.
	@Autowired
	private MyUserDAO dao;
	
	@RequestMapping("/")
	public @ResponseBody String home() {
		log.info("HomeController 클래스의 home() 메소드 실행");
		log.info("dao: {}", dao);
		return "Mybatis 사용하기";
	}
	
	@RequestMapping("/userList")
	public String userList(Model model) {
		log.info("HomeController 클래스의 userList() 메소드 실행");
		List<MyUserVO> userList = dao.list();
		model.addAttribute("userList", userList);
		return "userList";
	}
	
}
