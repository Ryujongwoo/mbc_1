package com.mbcit.k20250121_1_springBoot_JPA01.domain;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@NoArgsConstructor
@Data
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
@Entity
public class Publisher extends BaseEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private String name;
	
//	publisher_id와 매핑하기 위해서 연관 관계를 설정한다.
//	Publisher 엔티티와 Book 엔티티는 1:N 관계 이므로 @OneToMany 어노테이션으로 설정한다.
	@OneToMany
//	publisher_books라는 중간 테이블이 생성되지 않게 하기 위해서 @JoinColumn 어노테이션을 지정한다.
	@JoinColumn(name = "publisher_id")
	private List<Book> books = new ArrayList<>();
	
}








