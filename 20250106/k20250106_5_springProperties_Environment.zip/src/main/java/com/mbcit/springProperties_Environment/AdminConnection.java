package com.mbcit.springProperties_Environment;

import org.springframework.context.EnvironmentAware;
import org.springframework.core.env.Environment;

public class AdminConnection implements EnvironmentAware {

	private String adminId;
	private String adminPw;
	
	public AdminConnection() {
		System.out.println("AdminConnection 클래스의 bean이 생성되었습니다.");
	}

	public String getAdminId() {
		return adminId;
	}
	public void setAdminId(String adminId) {
		this.adminId = adminId;
	}
	public String getAdminPw() {
		return adminPw;
	}
	public void setAdminPw(String adminPw) {
		this.adminPw = adminPw;
	}

	@Override
	public String toString() {
		return "AdminConnection [adminId=" + adminId + ", adminPw=" + adminPw + "]";
	}

//	EnvironmentAware 인터페이스를 구현하면 사용할 수 있는 EnvironmentAware 인터페이스가 구현된
//	클래스의 bean이 생성된 후 자동으로 실행되는 메소드
	@Override
	public void setEnvironment(Environment environment) {
		System.out.println("AdminConnection 클래스의 bean이 생성된 후 자동으로 setEnvironment() 메소드 실행");
		// setEnvironment() 메소드의 인수인 DI 컨테이너 환경 설정 정보를 기억하는 Environment 인터페이스 타입의
		// 객체 environment에 spring이 알아서 EnvironmentAware 인터페이스가 구현된 클래스의 bean이 생성되는 순간
		// DI 컨테이너의 환경 설정 정보를 넘겨준다. => admin.properties 파일의 정보가 넘어온다.
		System.out.println(environment);
		System.out.println("admin.id: " + environment.getProperty("admin.id"));
		System.out.println("admin.pw: " + environment.getProperty("admin.pw"));
		adminId = environment.getProperty("admin.id");
		adminPw = environment.getProperty("admin.pw");
	}
	
}
















