function allCheck() {
//	name 속성 값이 all인 체크 박스를 체크하면 true, 해제하면 false인 상태를 변수에 저장한다.
//	라디오나 체크 박스의 checked 속성은 선택되면 true, 해제되면 false를 얻어온다.
	let check = document.getElementsByName('all')[0].checked;
	console.log(check);
	
//	name 속성 값이 check인 모든 체크 박스를 얻어온다.
	let checks = document.getElementsByName('check');
	console.log(checks);
	
//	name 속성 값이 check인 체크 박스의 개수만큼 반복하며 일괄적으로 선택 또는 해제한다.
	for (let i = 0; i < checks.length; i++) {
		checks[i].checked = check;
	}
}

function selectCheck() {
	/*
//	name 속성 값이 check인 모든 체크 박스를 얻어온다.
	let checks = document.getElementsByName('check');
	
//	빨강, 파랑, 노랑, 검정 체크 박스가 체크된 체크 박스의 개수를 계산한다.
	let count = 0; // 체크된 체크 박스의 개수를 기억할 변수
	for (let i = 0; i < checks.length; i++) {
		// console.log(checks[i].checked);
		if (checks[i].checked) {
			count++;
		}
	}
	console.log(count);
	
//	빨강, 파랑, 노랑, 검정 체크 박스가 모두 체크되었으면 전체 선택 체크 박스에 체크하고 한 개 라도
//	체크가 안되어있으면 전체 선택 체크 박스의 체크를 해제한다.
	if (count == checks.length) { // 모든 색상 체크 박스가 체크되었나?
		// 무조건 전체 선택 체크 박스에 체크한다.
		document.getElementsByName('all')[0].checked = true;
	} else {
		// 무조건 전체 선택 체크 박스에 체크를 해제한다.
		document.getElementsByName('all')[0].checked = false;
	}
	*/
	
	let checks = document.getElementsByName('check');
	let flag = true;
	for (let i = 0; i < checks.length; i++) {
		// 각각의 체크 박스가 체크되어있나 검사해서 한 개 라도 체크가 안되어있으면 flag를 false로 변경한다.
		if (!checks[i].checked) {
			flag = false;
			// 각각의 체크 박스 중에서 한 개 라도 체크가 안되어 있으면 나머지는 비교할 필요없다.
			break;
		}
	}
	document.getElementsByName('all')[0].checked = flag;
}

function selectColor() {
	let checks = document.getElementsByName('check');
	for (let check of checks) {
		if (check.checked) {
			// 선택된 체크 박스의 배경색과 글자색을 변경한다.
			// console.log(check.value + ' 선택');
			document.getElementById(check.value).style.backgroundColor = check.value;
			document.getElementById(check.value).style.color = 'white';
		} else {
			// 선택 해제된 체크 박스의 배경색과 글자색을 원래대로 되돌린다.
			// console.log(check.value + ' 해제');
			document.getElementById(check.value).style.backgroundColor = 'white';
			document.getElementById(check.value).style.color = 'black';
		}
	}
}

function clearColor() {
	/*
	let divs = document.getElementsByTagName('div');
	for (let i = 1; i < divs.length; i++) {
		divs[i].style.backgroundColor = 'white';
		divs[i].style.color = 'black';
	}
	*/
	
	let divs = document.querySelectorAll('#colorBox > div');
	for (let div of divs) {
		div.style.backgroundColor = 'white';
		div.style.color = 'black';
	}
	
//	전체 선택 체크 박스와 모든 색상 체크 박스를 선택 해제한다.
	/*
	document.getElementsByName('all')[0].checked = false;
//	document.getElementsByName('check')[0].checked = false;
//	document.getElementsByName('check')[1].checked = false;
//	document.getElementsByName('check')[2].checked = false;
//	document.getElementsByName('check')[3].checked = false;
	allCheck();
	*/
	
	let checks = document.querySelectorAll('[type="checkbox"]');
	console.log(checks);
	for (let check of checks) {
		check.checked = false;
	}
}

