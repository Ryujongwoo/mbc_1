package com.mbcit.k20250120_2_springBoot_Mybatis_SimpleBBS.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.mbcit.k20250120_2_springBoot_Mybatis_SimpleBBS.vo.SimpleBbsVO;

@Mapper
public interface SimpleBbsDAO {

	void insert(SimpleBbsVO simpleBbsVO);
	List<SimpleBbsVO> selectList();
	SimpleBbsVO selectByIdx(int idx);
	void update(SimpleBbsVO simpleBbsVO);
	void delete(int idx);
	
}
