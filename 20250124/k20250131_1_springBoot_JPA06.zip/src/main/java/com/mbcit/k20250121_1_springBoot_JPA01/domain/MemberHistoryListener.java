package com.mbcit.k20250121_1_springBoot_JPA01.domain;

import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;

import org.springframework.beans.factory.annotation.Autowired;

import com.mbcit.k20250121_1_springBoot_JPA01.repository.MemberHistoryRepository;
import com.mbcit.k20250121_1_springBoot_JPA01.support.BeanUtils;

public class MemberHistoryListener {

	private MemberHistoryRepository memberHistoryRepository;
	
	@PrePersist
	@PreUpdate
	public void prePersistAndPreUpdate(Object object) {
		System.out.println("MemberHistoryListener 리스너의 prePersistAndPreUpdate() 메소드 실행됨");
		memberHistoryRepository = BeanUtils.getBean(MemberHistoryRepository.class);
		System.out.println("memberHistoryRepository: " + memberHistoryRepository);
		
		Member member = (Member) object;
		MemberHistory memberHistory = new MemberHistory();
		memberHistory.setMemberId(member.getId());
		memberHistory.setName(member.getName());
		memberHistory.setEmail(member.getEmail());
		memberHistoryRepository.save(memberHistory);
	}
	
}












