package com.mbcit.k20250121_1_springBoot_JPA01;

import javax.persistence.EntityListeners;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;

@SpringBootApplication
//	데이터 작성일 및 수정일 저장은 매우 빈번하게 사용되는 기능이므로 springBoot는 기본 리스너를 제공한다.
//	기본 리스너를 사용하려면 main() 메소드가 생성된 클래스에 @EnableJpaAuditing 어노테이션을 붙여준다.
//	기본 리스너가 동작되게 하려면 기본 리스너를 적용할 엔티티 클래스의 @EntityListeners 어노테이션에
//	AuditingEntityListener를 지정하고 @PrePersist 어노테이션 대신에 @CreatedDate 어노테이션을 사용하고
//	@PreUpdate 어노테이션 대신에 @LastModifiedDate 어노테이션을 사용하면 기본 리스너가 동작된다.
@EnableJpaAuditing
public class K202501211SpringBootJpa1Application {

	public static void main(String[] args) {
		SpringApplication.run(K202501211SpringBootJpa1Application.class, args);
	}

}
