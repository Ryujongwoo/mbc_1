import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
// import App from './App';
import reportWebVitals from './reportWebVitals';

import Counter from './Test';
import Ref from './Test2';
import Subject from './Test3';
import Context from './Test4';
import MyList from './MyList';
import MyTable from './MyTeble';
import MyComponent from './MyComponent';
import MyForm from './MyForm';
import MyForm2 from './MyForm2';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    {/* <App /> */}
    <Counter />
    <Ref />
    <Subject />
    <Context />
    <MyList />
    <MyTable />
    <MyComponent />
    <MyForm />
    <MyForm2 />
  </React.StrictMode>
);

reportWebVitals();
