package com.mbcit.k20250117_4_springBoot_SimpleBBS;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class K202501174SpringBootSimpleBbsApplication {

	public static void main(String[] args) {
		SpringApplication.run(K202501174SpringBootSimpleBbsApplication.class, args);
	}

}
