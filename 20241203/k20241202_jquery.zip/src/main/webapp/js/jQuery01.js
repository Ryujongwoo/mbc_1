//	javascript 작성법
//	document.getElementById('list').style.color = 'blue';
//	document.querySelector('#list').style.color = 'red';

//	jQuery 작성법
//	$('css 선택자').실행할함수();
//	$('#list').css('color', 'green');
//	==================================================================

//	javascript onload
/*
onload = function () {
	alert('javascript onload 이벤트1');
}
//	==================================================================

onload = () => alert('javascript onload 이벤트2');
//	==================================================================
*/

//	jQuery onload
/*
$(document).ready(function () {
	alert('jQuery onload 이벤트1');
});
//	==================================================================

$().ready(function () { // document 생략 가능
	alert('jQuery onload 이벤트2');
});
//	==================================================================

$(function () { // ready 생략 가능
	alert('jQuery onload 이벤트3');
});
//	==================================================================

$(() => alert('jQuery onload 이벤트4'));
//	==================================================================
*/

function imgSize() {
//	javascript
//	width만 지정하거나 height만 지정하면 지정하지 않은 부분은 비율을 계산해서 알아서 변경된다.
//	width와 height를 각각 지정하면 지정한 크기만큼 각각 커지거나 작아진다.
//	document.getElementsByTagName('img')[0].style.width = '100px';
//	document.getElementsByTagName('img')[0].style.height = '200px';

//	jQuery
//	$('img').css('width', '100px');
//	$('img').css('height', '200px');

//	아래와 같이 1줄에 여러 개의 스타일 속성을 지정할 수 있다.
//	$('img').css('width', '100px').css('height', '200px');
//	$('img').css({'width': '100px', 'height': '200px'});
	$('img').css({'width': '100px', 'height': '200px'}).css('opacity', '0.5');
}

//	필터링 함수
//	.first(): 선택된 요소 중 첫 번째 요소를 선택한다.
//	.last(): 선택된 요소 중 마지막 요소를 선택한다.
//	.eq(index): 선택된 요소 중 index 번째 요소를 선택한다. => index는 0부터 시작한다.
//	.slice(): 선택된 요소 중 전달받은 인덱스 범위에 해당되는 요소만 선택한다.
//	.filter(): 선택된 요소 중 전달받은 선택자에 해당되거나, 함수 호출 결과가 참인 모든 요소를 선택한다.
//	.not(): 함수 호출 결과가 거짓인 모든 요소를 선택한다.
//	.has(): 선택된 요소 중 전달받은 선택자에 해당되는 요소의 모든 자손 요소를 선택한다.
//	.is(): 선택된 요소 중 전달받은 선택자에 해당되는 요소가 하나라도 존재하면 true를 리턴한다.
//	.map(): 선택된 요소 집합의 각 요소마다 콜백 함수를 실행하고 리턴값으로 구성된 객체를 리턴한다.

function highLight() {
//	javascript
//	document.querySelector('#list').style.backgroundColor = 'tomato';
//	jQuery
//	$('#list').css('backgroundColor', 'skyblue'); // javascript 스타일 속성과 동일하게 지정한다.
//	$('#list').css('background-color', 'chocolate'); // css 스타일 속성과 동일하게 지정한다.
	$('#list').css('background', 'hotpink'); // css 단축 스타일 속성과 동일하게 지정한다.
	
//	javascript
//	document.getElementsByTagName('li')[1].style.backgroundColor = 'dodgerblue';
//	document.querySelectorAll('li')[3].style.backgroundColor = 'yellowgreen';
//	document.querySelectorAll('#list > li')[5].style.backgroundColor = 'yellow';
//	jQuery
	$('#list > li').first().css('backgroundColor', 'skyblue');
	$('#list > li').last().css('backgroundColor', 'chocolate');
	$('#list > li').eq(2).css('backgroundColor', 'dodgerblue');
	$('#list > li').slice(3, 5).css('backgroundColor', 'yellowgreen');
}

//	요소(element) 추가 함수
//	선택된 요소 내부에 추가
//		.append(): 선택된 요소의 마지막에 추가한다.
//		.prepend(): 선택된 요소의 첫 번째에 추가한다.
//	선택된 요소 외부에 추가
//		.before(): 선택된 요소의 앞에 추가한다.
//		.after(): 선택된 요소의 뒤에 추가한다.

function addImage() {
	$('div').append('<img alt="샤미드" src="./images/img03.jpg"/>');
	$('div').prepend('<img alt="이브이A" src="./images/img01.jpg"/>');
	$('div').before('<img alt="고라파덕" src="./images/img04.jpg"/>');
	$('div').after('<img alt="이브이B" src="./images/img05.jpg"/>');
}

//	요소의 표시와 숨김
//	.hide(): 선택한 요소의 css를 자동으로 조정해서 사라지게 한다.
//	.show(): 선택한 요소의 css를 자동으로 조정해서 나타지게 한다.
//	.toggle(): 선택한 요소의 css를 자동으로 조정해서 hide(), show()를 번갈아서 실행한다.
//	hide(), show(), toggle()의 인수로 시간(밀리초)을 설정하거나 "slow", "fast"와 같은 예약어를 전달해
//	효과가 지속되는 시간을 설정할 수 있다.

//	페이드 효과
//	.fadeOut(): 선택한 요소의 css 중 opacity 속성 값을 줄여가며 사라지게 한다.
//	.fadeIn(): 선택한 요소의 css 중 opacity 속성 값을 늘여가며 나타나게 한다.
//	.fadeToggle(): fadeOut(), fadeIn()를 번갈아 적용한다.
//	fadeOut(), fadeIn(), fadeToggle()의 인수로 시간(밀리초)을 설정하거나 "slow", "fast"와 같은 예약어를 
//	전달해 효과가 지속되는 시간을 설정할 수 있다.

//	슬라이드 효과
//	.slideUp(): 선택한 요소의 css 중 height 속성 값을 줄여가며 사라지게 한다.
//	.slideDown(): 선택한 요소의 css 중 height 속성 값을 늘여가며 나타나게 한다.
//	.slideToggle(): slideUp(), slideDown()를 번갈아 적용한다.
//	slideUp(), slideDown(), slideToggle()의 인수로 시간(밀리초)을 설정하거나 "slow", "fast"와 같은 
//	예약어를 전달해 효과가 지속되는 시간을 설정할 수 있다.

function hideImage() {
//	개별
//	javascript
//	document.querySelectorAll('img')[0].style.display = 'none';
//	jQuery
//	$('img').first().css('display', 'none');
//	$('img').last().css('display', 'none');
//	$('img').eq(2).css('display', 'none');

//	전체
//	javascript
//	let imgs = document.querySelectorAll('img');
//	for (let img of imgs) {
//		img.style.display = 'none';
//	}
//	jQuery
//	javascript는 전체에 대해서 작업하려면 반복문을 사용해야 하지만 jQuery는 반복문을 사용하지 
//	않아도 된다. => 별도의 설정이 없으면 선택된 요소 전체에 대해서 일괄 처리를 한다.
//	$('img').css('display', 'none');

//	$('img').hide();
//	$('img').hide('slow');
//	$('img').hide('fast');
//	$('img').hide(5000);

//	$('img').fadeOut(3000);
//	$('img').slideUp(3000);
	$('div').slideUp(3000);
}

function showImage() {
//	개별
//	javascript
//	document.querySelectorAll('img')[0].style.display = 'block';
//	jQuery
//	$('img').first().css('display', 'block');
//	$('img').last().css('display', 'block');
//	$('img').eq(2).css('display', 'block');
	
//	전체
//	javascript
//	let imgs = document.querySelectorAll('img');
//	for (let img of imgs) {
//		img.style.display = 'block';
//	}
//	jQuery
//	$('img').css('display', 'block');

//	$('img').show();
//	$('img').show('slow');
//	$('img').show('fast');
//	$('img').show(5000);

//	$('img').fadeIn(3000);
//	$('img').slideDown(3000);
	$('div').slideDown(3000);
}

function toggleImage() {
//	$('img').toggle();
//	$('img').fadeToggle();
//	$('img').slideToggle();
	$('div').slideToggle();
}

