import './App.css';

// redux는 프로그램이 동작하는데 필요한 데이터(state)를 명확하게 관리하기 위한 기술로 등장했다.
// redux를 react에서 사용하려 하면 어려운 점이 많기때문에 이 문제를 해결해준 도구가 react-redux 인데
// 그래도 redux를 이용하는데 많은 문제점이 있다.
// 이런 문제를 해결해준 도구가 redux toolkit 이다.
// import { legacy_createStore as createStore } from 'redux';
import { Provider, useSelector, useDispatch } from 'react-redux';

// redux toolkit을 사용하려면 npm install @reduxjs/toolkit를 실행해서 설치한다.
// redux toolkit을 사용해서 슬라이스를 만들기 위해 createSlice를 import 한다.
// 슬라이스들을 모아서 스토어를 만들기 위해 configureStore를 import 한다.
import { createSlice, configureStore } from '@reduxjs/toolkit';

// function reducer(state, action) {
//   if (action.type === 'up') {
//     return {...state, value: state.value + action.step};
//   }
//   return state;
// }

// state의 초기값을 0으로 설정한다.
// const initialState = {value: 0};
// createStore() 함수의 첫 번째 인수는 reducer 함수를 두 번째 인수는 state의 초기값을 지정한다.
// const store = createStore(reducer, initialState);

// redux toolkit 슬라이스를 만든다.
// 슬라이스를 만들 때 슬라이스 이름, 초기값, 공급할 리듀서를 객체로 만들어서 인수로 지정한다.
const counterSlice = createSlice({
  name: 'counterSlice', // 슬라이스 이름, 아무렇게나 지정해도 상관없다.
  initialState: {count: 0}, // 초기값
  reducers: {
    // redux에서 사용했던 리듀서 함수에서는 action의 type에 따른 조건문이 있었는데
    // redux toolkit에서는 조건문 대신 reducers에다 up이라고 작성하면 action type이 up일때
    // 이 함수가 실행된다는 뜻이다.
    upup: function (state, action) {
      // console.log(action);
      // 기존 코드(reducer 함수)는 리턴할 때 불변성 때문에 기존 상태를 복사해서 사용했었다.
      // redux toolkit을 사용할 때는 기존 상태를 복사하는 지저분한 코딩이 필요없다.
      // state.count = state.count + action.step;
      state.count = state.count + action.payload;
    }
  } // 공급할 리듀서, 복수형으로 사용해야 한다.
});

// configureStore를 이용해서 슬라이스를 스토어로 만든다.
const sliceStore = configureStore({
  reducer: {
    counter: counterSlice.reducer
  }
});

function Counter() {
  // const value = useSelector(state => state.value);
  const count = useSelector(state => {
    // console.log(state);
    // console.log(state.counter);
    // console.log(state.counter.count);
    return state.counter.count;
  });
  console.log(count);
  const dispatch = useDispatch();
  return (
    <div>
      {/* <button type="button" onClick={() => dispatch({type: 'up', step: 2})}>+</button> {value}<br /> */}
      <button type="button" onClick={
        () => {
          // dispatch({type: 'counterSlice/upup', step: 3});
          dispatch(counterSlice.actions.upup(3));
        }
      }>toolkit</button> {count}
    </div>
  )
}

function App() {
  return (
    <Provider store={sliceStore}>
      <div className="App">
        <Counter></Counter>
      </div>
    </Provider>
  );
}

export default App;
