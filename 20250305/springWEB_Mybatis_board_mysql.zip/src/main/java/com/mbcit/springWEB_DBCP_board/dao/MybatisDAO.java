package com.mbcit.springWEB_DBCP_board.dao;

import java.util.ArrayList;
import java.util.HashMap;

import com.mbcit.springWEB_DBCP_board.vo.MvcboardVO;

//	mapper로 사용할 인터페이스
//	이 인터페이스의 풀 패키지와 이름을 sql 명령이 저장된 xml 파일의 namespace에 정확히 적어야 한다.
public interface MybatisDAO {

//	mapper로 사용하는 인터페이스의 추상 메소드 형식은 아래와 같다.
//	public abstract 리턴타입 메소드이름(인수); // 일반적으로 사용하는 추상 메소드 형식
//	<select id="" parameterType="" resultType=""> // sql 명령을 실행하는 xml 파일의 태그
//	public abstract resultType id(parameterType); // mapper 추상 메소드 형식
//	추상 메소드 이름이 xml 파일의 실행할 sql 명령을 식별하는 id로 사용되로 리턴 타입이 resultType으로
//	사용되고 parameterType이 메소드로 전달되는 인수로 사용된다.
	
//	<insert id="insert" parameterType="vo">
	void insert(MvcboardVO mvcboardVO);
//	<select id="selectCount" resultType="int">
	int selectCount();
//	<select id="selectList" parameterType="java.util.HashMap" resultType="vo">
	ArrayList<MvcboardVO> selectList(HashMap<String, Integer> hmap);
//	<update id="increment" parameterType="int">
	void increment(int idx);
//	<select id="selectByIdx" parameterType="int" resultType="vo">
	MvcboardVO selectByIdx(int idx);
//	<update id="update" parameterType="vo">
	void update(MvcboardVO mvcboardVO);
//	<delete id="delete" parameterType="int">
	void delete(int idx);
//	<update id="replyIncrement" parameterType="java.util.HashMap">
	void replyIncrement(HashMap<String, Integer> hmap);
//	<insert id="replyInsert" parameterType="vo">
	void replyInsert(MvcboardVO mvcboardVO);
	
	int maxIdx();
	
}















