package com.mbcit.springBootReact02.domain;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

//	다른 경로 이름을 사용하려면 레포지토리로 사용되는 인터페이스에 @RepositoryRestResource 어노테이션을
//	아래와 같이 path를 지정하면 된다.
//	@RepositoryRestResource(path = "asdfg")
//	서비스에 쿼리를 추가하려면 레포지토리로 사용되는 인터페이스에 @RepositoryRestResource 어노테이션을
//	추가한다.
//	http://localhost:9090/api/cars/ 경로에 GET 요청을 하면 /search라는 새 엔드포인트를 볼 수 있다.
@RepositoryRestResource
public interface CarRepository extends CrudRepository<Car, Long> {
	
//	brand로 자동차 검색
//	서비스에 추가된 쿼리에 데이터를 넘겨주려면 쿼리 매개변수는 @Param 어노테이션으로 지정한다.
	public List<Car> findByBrand(@Param("brand") String brand);
//	color로 자동차 검색
	public List<Car> findByColor(@Param("color")String color);
//	year로 자동차 검색
	public List<Car> findByYear(int year);
//	brand와 model로 자동차 검색
	public List<Car> findByBrandAndModel(String brand, String model);
//	brand나 color로 자동차 검색
	public List<Car> findByBrandOrColor(String brand, String color);
//	brand나 color로 자동차를 검색하고 price로 정렬
	public List<Car> findByBrandOrColorOrderByPrice(String brand, String color);
//	SQL문을 이용해 brand로 자동차 검색
	@Query("select c from Car c where c.brand = ?1")
	public List<Car> brandEqual(String brand);
	@Query("select c from Car c where c.brand like %?1%")
	public List<Car> brandImport(String brand);
	
}












