package com.mbcit.springBootReact02.domain;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonIncludeProperties;


@Entity
//	car 테이블과 owner 테이블이 일대다 관계가 설정되어 있기 때문에 자동차가 직렬화되면 연결된 소유자가
//	직렬화되고 이어서 그 소유자가 소유한 자동차가 다시 직렬화되는 식이다.
//	이런 직렬화 문제를 해결하는 방법은 Owner 클래스의 cars 필드에 @JsonIgnore 어노테이션을 지정해서
//	직렬화 작업 중에 cars 필드를 무시하게 하는 것이다.
//	이 경우 하이버네이트가 생성한 필드를 무시하도록 @JsonIgnoreProperties 어노테이션을 함께 사용한다.
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class Owner {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long ownerid;
	private String firstname;
	private String lastname;
	
//	@JsonIgnore은 직렬화 작업시 @JsonIgnore 어노테이션이 지정된 필드를 무시한다.
	@JsonIgnore
	@OneToMany(mappedBy = "owner", cascade = CascadeType.ALL)
	private List<Car> cars;
	
	public Owner() { }
	public Owner(String firstname, String lastname) {
		this.firstname = firstname;
		this.lastname = lastname;
	}
	
	public Long getOwnerid() {
		return ownerid;
	}
	public void setOwnerid(Long ownerid) {
		this.ownerid = ownerid;
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public List<Car> getCars() {
		return cars;
	}
	public void setCars(List<Car> cars) {
		this.cars = cars;
	}
	
	@Override
	public String toString() {
		return "Owner [ownerid=" + ownerid + ", firstname=" + firstname + ", lastname=" + lastname + ", cars=" + cars
				+ "]";
	}
	
}
