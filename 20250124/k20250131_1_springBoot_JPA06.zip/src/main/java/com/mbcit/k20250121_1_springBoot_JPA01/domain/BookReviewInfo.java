package com.mbcit.k20250121_1_springBoot_JPA01.domain;

import java.time.LocalDateTime;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@NoArgsConstructor
@Data
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
@Entity
public class BookReviewInfo extends BaseEntity {

	@Id
	@GeneratedValue
	private Long id; // PK
//	멤버 선언시 기본 자료형을 사용하면 테이블 생성시 not null을 사용해 null check를 한다.
//	null check를 하지 않으려면 랩퍼 클래스를 사용하면 된다.
	private float averageReviewScore;
	private int reviewCount;
//	createDate, updateDate는 BaseEntity에서 상속받아 사용한다.
//	private LocalDateTime createDate;
//	private LocalDateTime updateDate;
	private Long bookId;
	
}








