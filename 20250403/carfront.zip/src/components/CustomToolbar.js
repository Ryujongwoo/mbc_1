import { gridClasses, GridToolbarContainer, GridToolbarExport } from "@mui/x-data-grid";
import React from "react";

// MUI의 GridToolbarContainer 및 GridToolbarExport 컴포넌트로 Export 버튼을 렌더링하는
// 컴포넌트를 만든다.
function CustomToolbar() {
  return (
    <GridToolbarContainer className={gridClasses.toolbarContainer}>
      <GridToolbarExport />
    </GridToolbarContainer>
  )
}

export default CustomToolbar;