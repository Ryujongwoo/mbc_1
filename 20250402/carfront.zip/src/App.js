import { AppBar, Container, Toolbar, Typography } from '@mui/material';
import './App.css';
import CarList from './components/CarList';

function App() {
  return (
    <div className="App">
      <Container>
        <AppBar position='static'>
          <Toolbar>
            <Typography variant='h6'>
              Carshop
            </Typography>
          </Toolbar>
        </AppBar>

        {/* CarList 컴포넌트를 가져온다. */}
        <CarList/>

      </Container>
    </div>
  );
}

export default App;
