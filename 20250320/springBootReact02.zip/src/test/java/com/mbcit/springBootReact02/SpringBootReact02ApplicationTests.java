package com.mbcit.springBootReact02;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootReact02ApplicationTests {

	@Test
	void contextLoads() {
	}

}
