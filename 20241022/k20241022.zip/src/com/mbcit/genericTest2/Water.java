package com.mbcit.genericTest2;

//	3D 프린터 재료 - Water
public class Water {

	@Override
	public String toString() {
		return "Water";
	}
	
}
