package com.mbcit.k20250121_1_springBoot_JPA1.repository;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDateTime;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.mbcit.k20250121_1_springBoot_JPA1.domain.Member;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@SpringBootTest
class MemberRepositoryTest {

	@Autowired
	private MemberRepository memberRepository;
	
	@Test
	void test() {
//		log.info("memberRepository: {}", memberRepository);
		log.info("MemberRepositoryTest 클래스의 test() 메소드 실행");
		
//		memberRepository.save(new Member(1L, "홍길동", "a@a.com", LocalDateTime.now(), LocalDateTime.now()));
//		memberRepository.save(new Member(2L, "임꺽정", "b@b.com", LocalDateTime.now(), LocalDateTime.now()));
//		memberRepository.save(new Member(3L, "장길산", "c@c.com", LocalDateTime.now(), LocalDateTime.now()));
//		memberRepository.save(new Member(4L, "일지매", "b@b.com", LocalDateTime.now(), LocalDateTime.now()));
		
		log.info("결과: {}", memberRepository.findAll());
	}

}













