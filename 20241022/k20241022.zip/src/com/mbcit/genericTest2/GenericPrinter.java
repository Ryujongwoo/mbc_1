package com.mbcit.genericTest2;

//	<M extends 클래스나 인터페이스>: M 자료형의 범위를 제한할 수 있다.
//	상속을 받지 않은 경우 Object가 기본값으로 사용된다.

//	GenericPrinter 클래스를 선언할 때 generic은 Material 인터페이스를 상속받아 선언해서
//	Material 인터페이스를 구현받아 작성된 Plastic 클래스와 Powder 클래스만 generic으로
//	받아서 사용할 수 있다.
//	Material이 인터페이스인 경우에도 extends를 사용해야 한다.
public class GenericPrinter<M extends Material> {

	private M material;

	public M getMaterial() {
		return material;
	}

	public void setMaterial(M material) {
		this.material = material;
	}

	@Override
	public String toString() {
		return material + "을(를) 재료로 사용하는 3D 프린터 사용중";
	}
	
}
