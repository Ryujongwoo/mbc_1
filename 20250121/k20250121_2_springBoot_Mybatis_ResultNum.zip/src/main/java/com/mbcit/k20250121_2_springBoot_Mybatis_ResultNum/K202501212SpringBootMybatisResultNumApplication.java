package com.mbcit.k20250121_2_springBoot_Mybatis_ResultNum;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class K202501212SpringBootMybatisResultNumApplication {

	public static void main(String[] args) {
		SpringApplication.run(K202501212SpringBootMybatisResultNumApplication.class, args);
	}

}
