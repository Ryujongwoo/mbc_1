package com.mbcit.register;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/Register")
public class Register extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public Register() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		actionDo(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		actionDo(request, response);
	}
	
	protected void actionDo(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		System.out.println("Register 컨트롤러의 actionDo() 메소드 실행");
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html; charset=UTF-8");
		
		String id = request.getParameter("id");
		String password = request.getParameter("password");
		String password2 = request.getParameter("password2");
		String name = request.getParameter("name");
		String age = request.getParameter("age");
		String gender = request.getParameter("gender");
		String email = request.getParameter("email");
		
		// 입력 체크
		if (id == null || id.trim().equals("") || password == null || password.trim().equals("") ||
			password2 == null || password2.trim().equals("") || name == null || name.trim().equals("") ||
			age == null || age.trim().equals("") || gender == null || gender.trim().equals("") ||
			email == null || email.trim().equals("")) {
			// 입력 체크 실패 메시지를 session에 저장한다.
			// request.getSession(): 서블릿에서 session을 얻어온다.
			request.getSession().setAttribute("messageType", "오류 메시지: ");
			request.getSession().setAttribute("messageContent", "모든 내용을 입력하세요.");
			response.sendRedirect("index.jsp");
			return; // 입력 데이터에 오류가 있으므로 서블릿을 종료한다.
		}
		
		// 비밀번호 체크
		if (!password.trim().equals(password2.trim())) {
			request.getSession().setAttribute("messageType", "오류 메시지: ");
			request.getSession().setAttribute("messageContent", "비밀번호가 일치하지 않습니다.");
			response.sendRedirect("index.jsp");
			return;
		}
		
		RegisterVO vo = new RegisterVO();
		vo.setId(id);
		vo.setPassword(password);
		vo.setName(name);
		vo.setAge(Integer.parseInt(age));
		vo.setGender(gender);
		vo.setEmail(email);
		// System.out.println(vo);

		// 테이블에 회원 정보를 저장하는 메소드를 실행한다.
		int result = new RegisterDAO().register(vo);
		
		// 저장 체크
		if (result == 1) {
			// insert sql 명령이 정상적으로 실행되었을 때 성공 메시지를 session에 저장한다.
			request.getSession().setAttribute("messageType", "성공 메시지: ");
			request.getSession().setAttribute("messageContent", "회원 가입에 성공했습니다.");
		} else {
			// insert sql 명령이 정상적으로 실행되지 않았을 때 실패 메시지를 session에 저장한다.
			request.getSession().setAttribute("messageType", "오류 메시지: ");
			request.getSession().setAttribute("messageContent", "이미 존재하는 아이디입니다.");
		}
		response.sendRedirect("index.jsp");
	}

}

















