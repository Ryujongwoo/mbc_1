import './App.css';

// useState는 state의 값이 바뀌면 컴포넌트가 다시 렌더링된다.
// useState의 경쟁자가 있는데 바로 useReducer이다. 이 둘은 똑같은 일을 하지만 서로 다른 취지를 
// 가지고 있다.
import { useState } from 'react';

// useState와 useReducer의 가장 큰 차이점은 useReducer는 리듀서라는 함수를 사용한다는 것이다.
// useReducer를 사용하려면 useReducer를 import 하고 useReducer를 추가하고 첫 번째 파라미터로
// 리듀서 함수를 전달하고 두 번째 파라미터로 state의 기본값을 전달한다.
import { useReducer } from 'react';

function App() {
  // 0을 초기값으로 가지는 count라는 state를 만든다.
  // 이 state는 count를 통해 state 값을 읽을 수 있고 setCount 함수를 통해 state 값을 수정한다.
  // const [count, setCount] = useState(0);
  // 초기값이 1인 number state를 만든다.
  const [number, setNumber] = useState(1);

  // useReducer에 사용할 리듀서 함수를 정의한다.
  // 리듀서 함수는 어떤 동작에 따라서 현재 state 값을 변경하는 함수를 의미한다.
  // 리듀서 함수는 두 개의 파라미터를 인수로 받는데 첫 번째 파라미터는 현재 state 값이고
  // 두 번째 파라미터는 useReducer가 실행할 action(동작) 이다.
  /*
  function countReducer(oldCount, action) {
    if (action === 'UP') {
      // return oldCount + 1;
      return oldCount + number;
    } else if (action === 'DOWN') {
      // return oldCount - 1;
      return oldCount - number;
    } else {
      return 0;
    }
  }
  */
  function countReducer(oldCount, action) {
    if (action.type === 'UP') {
      return oldCount + action.number;
    } else if (action.type === 'DOWN') {
      return oldCount - action.number;
    } else {
      return 0;
    }
  }

  // useReducer를 만든다.
  // const [상태를 기억할 변수, action을 변경하는 함수] = useReducer(리듀서 함수, state 초기치)
  const [count, setAction] = useReducer(countReducer, 0);

  // count state 값을 1감소 시키는 함수
  function down() {
    // setCount(count - 1);
    // setAction('DOWN')
    // 리듀스 함수의 action으로 2개 이상의 값을 전달해야 한다면 객체로 만들어서 전달한다.
    setAction({type: 'DOWN', number: number})
  }
  // count state 값을 0으로 초기화 시키는 함수
  function reset() {
    // setCount(0);
    // setAction('RESET')
    setAction({type: 'RESET', number: number})
  }
  // count state 값을 1증가 시키는 함수
  function up() {
    // setCount(count + 1);
    // setAction('UP')
    setAction({type: 'UP', number: number})
  }

  function changeNumber(event) {
    // console.log(event.target.value);
    setNumber(Number(event.target.value));
  }

  return (
    <div className="App">
      <div>
        <input type="button" value="-" onClick={down}/>
        <input type="button" value="0" onClick={reset}/>
        <input type="button" value="+" onClick={up}/>
        <input type="number" value={number} onChange={changeNumber} />
        <span>{count}</span>
      </div>
    </div>
  );
}

export default App;
