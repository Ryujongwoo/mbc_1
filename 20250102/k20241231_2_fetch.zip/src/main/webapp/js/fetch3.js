function fetchAJAX(pagename) {
	fetch(pagename)
		.then(response => {
			if (response.status == 200) {
				response.text()
					.then(data => document.querySelectorAll('div')[0].innerHTML = data)
			} else {
				alert('요청 실패!!!')
			}
		})
}


