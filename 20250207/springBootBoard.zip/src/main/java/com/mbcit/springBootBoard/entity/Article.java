package com.mbcit.springBootBoard.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Transient;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

//	JPA(Java Persistence API)를 사용해서 테이블을 작성하는 클래스는 @Entity 어노테이션을 붙여서
//	선언해야 하고 엔티티라 부른다.
//	@Entity 어노테이션을 붙여서 선언한 클래스 이름으로 springBoot JPA가 자동으로 테이블을 만들고
//	클래스 내부에 선언한 멤버 이름으로 테이블을 구성하는 필드(컬럼, 속성)를 만들어 준다.
@Entity // 현재 클래스는 엔티티로 사용되는 클래스임을 의미한다.
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
public class Article { // 메인글을 저장하는 테이블

//	기본키로 사용할 멤버를 선언한다.
//	엔티티 객체에서 기본키를 생성하려면 @Id와 @GeneratedValue 어노테이션을 사용해야 한다.
	@Id // @Id 어노테이션을 붙여 선언한 멤버는 테이블에서 기본키 필드로 사용된다. 
//	@GeneratedValue // @GeneratedValue 어노테이션을 붙여서 기본키 필드의 값을 자동으로 증가하게 한다.
	@GeneratedValue(strategy = GenerationType.IDENTITY) // mysql 처럼 auto_increment를 사용한다.
	private Long id;
	
//	데이터를 저장할 필드로 사용할 멤버를 선언한다.
	@Column // 클래스의 멤버를 테이블의 필드와 매핑한다.
	private String title;
	@Column
//	@Transient 어노테이션을 붙여주면 클래스의 멤버로는 사용하지만 테이블의 필드로는 만들지 않는다.
	private String content;
	
	
	
}








