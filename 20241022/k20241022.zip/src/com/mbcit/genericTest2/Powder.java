package com.mbcit.genericTest2;

//	3D 프린터 재료 - Powder
public class Powder implements Material {
//	public class Powder extends Material {

	@Override
	public String toString() {
		return "Powder";
	}

}
