package com.mbcit.k20250120_2_springBoot_Mybatis_SimpleBBS;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class K202501202SpringBootMybatisSimpleBbsApplicationTests {

	@Test
	void contextLoads() {
	}

}
