package com.mbcit.k20250121_1_springBoot_Mybatis_Param;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.mbcit.k20250121_1_springBoot_Mybatis_Param.dao.SimpleBbsDAO;
import com.mbcit.k20250121_1_springBoot_Mybatis_Param.vo.SimpleBbsVO;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
public class HomeController {

	@Autowired
	private SimpleBbsDAO dao;
	
	@RequestMapping("/")
	public String home() {
		log.info("HomeController 클래스의 home() 메소드 실행");
		return "redirect:list";
	}
	
	@RequestMapping("/insert")
	public String insert() {
		log.info("HomeController 클래스의 insert() 메소드 실행");
		return "insert";
	}
	
	@RequestMapping("/insertOK")
	public String insertOK(SimpleBbsVO simpleBbsVO) {
		log.info("HomeController 클래스의 insertOK() 메소드 실행");
//		dao.insert(simpleBbsVO);
//		방법1
		dao.insert(simpleBbsVO.getName(), simpleBbsVO.getTitle(), simpleBbsVO.getContent());
		return "redirect:list";
	}
	
	@RequestMapping("/list")
	public String list(Model model) {
		log.info("HomeController 클래스의 list() 메소드 실행");
		model.addAttribute("list", dao.selectList());
		return "list";
	}
	
	@RequestMapping("/view")
	public String view(HttpServletRequest request, Model model) {
		log.info("HomeController 클래스의 view() 메소드 실행");
		int idx = Integer.parseInt(request.getParameter("idx"));
		model.addAttribute("vo", dao.selectByIdx(idx));
		return "view";
	}
	
	@RequestMapping("/update")
	public String update(HttpServletRequest request, Model model) {
		log.info("HomeController 클래스의 update() 메소드 실행");
		int idx = Integer.parseInt(request.getParameter("idx"));
		model.addAttribute("vo", dao.selectByIdx(idx));
		return "update";
	}
	
	@RequestMapping("/updateOK")
	public String updateOK(SimpleBbsVO simpleBbsVO) {
		log.info("HomeController 클래스의 updateOK() 메소드 실행");
		dao.update(simpleBbsVO);
		return "redirect:list";
	}
	
	@RequestMapping("/delete")
	public String delete(HttpServletRequest request) {
		log.info("HomeController 클래스의 delete() 메소드 실행");
		int idx = Integer.parseInt(request.getParameter("idx"));
		dao.delete(idx);
		return "redirect:list";
	}
}


















