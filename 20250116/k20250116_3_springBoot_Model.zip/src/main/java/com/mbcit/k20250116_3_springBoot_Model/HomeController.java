package com.mbcit.k20250116_3_springBoot_Model;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class HomeController {

	@RequestMapping("/")
	public @ResponseBody String home() {
		System.out.println("HomeController 클래스의 home() 메소드 실행");
		return "Model & View";
	}
	
	@RequestMapping("/modelTest")
	public String modelTest(Model model) {
		System.out.println("HomeController 클래스의 modelTest() 메소드 실행");
//		Model 인터페이스 객체를 이용해서 viewpage로 데이터를 전달한다.
		model.addAttribute("name", "홍길동");
		return "modelTest";
	}
	
	@RequestMapping("/modelTest2")
//	ModelAndView 클래스 객체를 이용하면 viewpage 이름과 데이터를 전달한다.
	public ModelAndView modelTest2() {
		System.out.println("HomeController 클래스의 modelTest2() 메소드 실행");
		ModelAndView modelAndView = new ModelAndView();
		
		List<String> books = new ArrayList<>();
		books.add("java");
		books.add("jsp");
		books.add("spring");
		
//		ModelAndView 클래스 객체에 viewpage로 넘길 데이터를 넣어준다.
		modelAndView.addObject("books", books);
		modelAndView.addObject("test", "ModelAndView 테스트");
		modelAndView.addObject("name", "임꺽정");
		
//		ModelAndView 클래스 객체에 viewpage 이름을 넣어준다.
		modelAndView.setViewName("view/modelTest2");
		
//		viewpage로 넘겨줄 데이터와 viewpage 이름이 저장된 ModelAndView 클래스 객체를 리턴시킨다.
		return modelAndView;
	}
	
}
