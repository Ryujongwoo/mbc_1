package com.mbcit.springBootBoard.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller // 이 클래스는 컨트롤러임을 나타낸다.
public class HomeController {

//	브라우저에 "/"라는 요청이 들어오면 home() 메소드가 실행된다.
	@RequestMapping("/")
	public @ResponseBody String home() {
		return "springBoot를 이용한 간단 게시판";
	}
	
}
