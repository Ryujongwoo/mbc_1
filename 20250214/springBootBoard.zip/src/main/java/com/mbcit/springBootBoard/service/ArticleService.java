package com.mbcit.springBootBoard.service;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import com.mbcit.springBootBoard.dto.ArticleForm;
import com.mbcit.springBootBoard.entity.Article;
import com.mbcit.springBootBoard.repository.ArticleRepository;

import lombok.extern.slf4j.Slf4j;

//	클래스를 정의할 때 스테레오 타입의 어노테이션을 붙여주면 springBoot가 실행될 때 자동으로
//	객체(bean)을 만들어서 등록한다.
//	@Component: 일반 클래스
//	@Repository: 데이터베이스 명령을 처리하는 클래스
@Service // 서비스 클래스
@Slf4j
public class ArticleService {

	@Autowired
	private ArticleRepository articleRepository;

//	article 테이블 전체 글 목록 조회
	public List<Article> index() {
		log.info("ArticleService의 index() 메소드 실행");
		return articleRepository.findAllByOrderByIdDesc();
	}
	
//	article 테이블 전체 특정 글 조회
	public Article show(Long id) {
		log.info("ArticleService의 show() 메소드 실행");
		return articleRepository.findById(id).orElse(null);
	}
	
//	article 테이블에 글 저장
	public Article createArticle(ArticleForm articleForm) {
		log.info("ArticleService의 createArticle() 메소드 실행");
		Article article = articleForm.toEntity();
//		save() 메소드는 id가 null이면 insert sql 명령이 실행되고 null이 아니면 update sql 명령이
//		실행된다.
//		save() 메소드로 insert sql 명령을 실행할 때 id는 데이터베이스가 자동으로 생성하므로
//		만약에 id가 넘어오는 데이터는 article 테이블에 저장하면 안된다.
		if (article.getId() != null) {
			log.info("id가 null이 아니면 insert sql 명령을 실행하면 안됩니다.");
			return null;
		}
		return articleRepository.save(article);
	}
	
//	article 테이블의 글 수정
	public Article update(Long id, ArticleForm articleForm) {
		log.info("ArticleService의 update() 메소드 실행");
		Article article = articleForm.toEntity();
		Article target = articleRepository.findById(id).orElse(null);
		if (target == null || target.getId() != article.getId()) {
			log.info("잘못된 요청");
			return null;
		}
//		id만 존재하면 null을 리턴하는 코드를 추가한다.
		if (article.getTitle() == null && article.getContent() == null) {
			log.info("잘못된 요청");
			return null;
		}
		article.patch(target);
		return articleRepository.save(article);
	}
	
//	article 테이블의 글 삭제
	public Article delete(Long id) {
		log.info("ArticleService의 delete() 메소드 실행");
		Article target = articleRepository.findById(id).orElse(null);
		if (target == null) {
			log.info("잘못된 요청");
			return null;
		}
		articleRepository.delete(target);
		return target;
	}
	
//	트랜잭션
//	@Transactional 어노테이션은 @Transactional 어노테이션을 지정한 메소드를 하나의 트랜잭션으로 묶는다.
//	트랜잭션은 한 번에 모두 실행되야할 sql 명령의 집합을 의미하고 모든 명령이 정상적으로 실행되면
//	commit 되고 한 개라도 정상적으로 실행되지 않으면 모두 rollback 된다.
	@Transactional
	public List<Article> transaction(List<ArticleForm> articleForms) {
		log.info("ArticleService의 transaction() 메소드 실행");
		articleForms.forEach(System.out::println);
		
//		articleForms(dto 묶음 데이터)를 Article 엔티티 묶음 데이터로 변환한다.
		List<Article> articles = new ArrayList<>();
		for (int i = 0; i < articleForms.size(); i++) {
			articles.add(articleForms.get(i).toEntity());
		}
		articles.forEach(System.out::println);
		
//		엔티티 묶음 데이터를 article 테이블에 저장한다.
//		for (Article article : articles) {
//			articleRepository.save(article);
//		}
		articleRepository.saveAll(articles);
		
//		강제 예외 발생
		articleRepository.findById(-1L).orElseThrow(
			() -> new IllegalArgumentException("저장 실패!!!")
		);
		
		return articles;
	}
	
}




















