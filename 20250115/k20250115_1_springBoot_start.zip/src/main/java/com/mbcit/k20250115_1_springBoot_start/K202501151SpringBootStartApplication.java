package com.mbcit.k20250115_1_springBoot_start;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class K202501151SpringBootStartApplication {

	public static void main(String[] args) {
		SpringApplication.run(K202501151SpringBootStartApplication.class, args);
	}

}
