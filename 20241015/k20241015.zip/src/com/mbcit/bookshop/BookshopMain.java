package com.mbcit.bookshop;

import java.util.Date;

public class BookshopMain {

	public static void main(String[] args) {
		
//		클래스 객체 선언방법
//		클래스이름 객체(변수)이름 = new 생성자();
		BookVO vo = new BookVO();
		System.out.println("vo: " + vo);
//		클래스로 만든 객체를 출력하면 자동으로 toString() 메소드가 실행된다.
		System.out.println("vo: " + vo.toString());
		
//		도서 정보를 만든다.
//		Date date = new Date(2022, 7, 30); // 출판일
//		BookVO book1 = new BookVO("java", "홍길동", "MBC 출판사", date, 35000);
//		출판일은 날짜 데이터를 만들어서 BookVO 클래스의 date 필드에 넣어주면 프로그램의 다른 부분에서
//		사용할 일이 없다. => 이럴 경우 익명 객체로 만들어 사용한다.
		BookVO book1 = new BookVO("java", "홍길동", "MBC 출판사", new Date(2022, 7, 30), 35000);
		System.out.println("book1: " + book1);
		
//		private 권한으로 선언된 멤버 변수는 클래스 외부에서 접근할 수 없기때문에 getters & setters
//		메소드를 사용한다.
//		private 권한으로 선언된 멤버 변수에 아래와 같이 "."을 찍어 접근을 시도하면 에러가 발생된다.
//		System.out.println(book1.title); // 에러
		System.out.println(book1.getTitle()); // getter 메소드 사용
//		book1.title = "spring"; // 에러
		book1.setTitle("python"); // setter 메소드 사용
		System.out.println("book1: " + book1);
		
		BookVO book2 = new BookVO("java", "홍길자", "MBC 출판사", new Date(2022, 7, 30), 35000);
		BookVO book3 = new BookVO("java", "홍길숙", "MBC 출판사", new Date(2022, 7, 30), 35000);
		BookVO book4 = new BookVO("java", "홍길희", "MBC 출판사", new Date(2022, 7, 30), 35000);
		BookVO book5 = new BookVO("java", "홍길자", "MBC 출판사", new Date(2022, 7, 30), 35000);
		BookVO book6 = new BookVO("java", "홍길도", "MBC 출판사", new Date(2022, 7, 30), 35000);
		
		System.out.println("book2: " + book2);
		System.out.println("book5: " + book5);
		
//		"=="을 사용해서 같은가 비교할 수있는 데이터는 기본 자료형 7가지와 null만 가능하다.
//		클래스로 만든 객체를 "=="를 사용해서 비교하면 데이터가 아니라 데이터가 생성된 주소를 비교한다.
		System.out.println(book2 == book5 ? "같다" : "다르다");
		
//		기본 자료형 7가지와 null을 제외한 나머지 데이터는 equals() 메소드를 사용해서 비교한다.
//		단순한 String은 equals() 메소드만 사용해서 비교가 가능하지만 String을 제외한 나머지 클래스로
//		만든 객체는 같은 내용이 저장되어있으면 동일한 hashcode를 가져아 equals로 비교가 가능하다.
		System.out.println(book2.equals(book5) ? "같다" : "다르다");
		
//		여러권의 책 정보를 기억하는 클래스의 객체를 만든다.
		BookList bookList = new BookList(5);
		
//		도서 정보를 BookList 클래스의 bookList 배열에 저장하는 메소드를 실행한다.
		bookList.addBook(book1);
		bookList.addBook(book2);
		bookList.addBook(book3);
//		bookList.addBook(book4);
//		bookList.addBook(book5);
//		bookList.addBook(book6);
		
		System.out.println(bookList);
		
	}
	
}













