import { Link, NavLink, Route, Routes, useParams } from 'react-router-dom';
import './App.css';

function Home() {
  return (
    <div>
      <h2>Home</h2>
      Home...
    </div>
  )
}

const contents = [
  {id: 1, title: 'HTML', description: 'HTML is ...'},
  {id: 2, title: 'JS', description: 'JS is ...'},
  {id: 3, title: 'REACT', description: 'REACT is ...'},
  {id: 4, title: 'SPRINGBOOT', description: 'SPRINGBOOT is ...'},
  {id: 5, title: 'AWS', description: 'AWS is ...'}
]

function Topic() {
  // 주소가 /topics/2일 때, 이 주소는 path 속성이 /topics/:topic_id 라고 지정한 Route에 매칭된다.
  // Topic 컴포넌트 안에서 주소에 있는 값, 즉 topic_id가 무엇인지 알아낼 수 있어야 한다.
  // 이때, useParams()이라는 hook이 사용된다.
  let params = useParams()
  // console.log(params)
  let selected_topic = null
  for (let i=0; i<contents.length; i++) {
    if (contents[i].id === Number(params.topic_id)) {
      selected_topic = contents[i]
      break
    }
  }
  return (
    <div>
      {/*
      <h2>Topic</h2>
      Topic...
      */}
      <h2>{selected_topic.title}</h2>
      {selected_topic.description}
    </div>
  )
}

function Topics() {
  let lis = [], routes = []
  for (let i=0; i<contents.length; i++) {
    lis.push(
      <li key={contents[i].id}>
        <NavLink to={"/topics/" + contents[i].id}>{contents[i].title}</NavLink>
      </li>
    )
    routes.push(
      <Route path={'/' + contents[i].id} element={contents[i].description} />
    )
  }
  return (
    <div>
      <h2>Topics</h2>
      {/* Topics 컴포넌트 안에 또 다른 페이지를 만든다. */}
      <ul>
        {/*
        <li><NavLink to="/topics/1">HTML</NavLink></li>
        <li><NavLink to="/topics/2">JS</NavLink></li>
        <li><NavLink to="/topics/3">REACT</NavLink></li>
        */}
        {lis}
      </ul>
      <Routes>
        {/*
        <Route path='/1' element={'HTML is ...'} />
        <Route path='/2' element={'JS is ...'} />
        <Route path='/3' element={'REACT is ...'} />
        */}
        {/* {routes} */}
        <Route path='/:topic_id' element={<Topic />} />
      </Routes>
    </div>    
  )
}

function Contact() {
  return (
    <div>
      <h2>Contact</h2>
      Contact...
    </div>    
  )
}

function App() {
  return (
    <div className="App">
      <h1>Hello React Router DOM</h1>
      {/*
      <Home />
      <Topics />
      <Contact />
      {/* <a>를 사용해서 만든 하이퍼링크 클릭할 때 마다 페이지가 새로 로딩된다. */}
      <h2>a 태그 사용</h2>
      <ul>
        <li><a href='/'>Home</a></li>
        <li><a href='/topics'>Topics</a></li>
        <li><a href='/contact'>Contact</a></li>
      </ul>
      {/* Link 컴포넌트는 클릭할 때 마다 페이지가 새로 로딩되지 않게 구현한다. */}
      <h2>Link 컴포넌트 사용</h2>
      <ul>
        <li><Link to='/'>Home</Link></li>
        <li><Link to='/topics'>Topics</Link></li>
        <li><Link to='/contact'>Contact</Link></li>
      </ul>
      {/* NavLink 컴포넌트는 Link 컴포넌트와 유사한데 기능이 조금 더 부가된 것이다. */}
      {/* Link 컴포넌트를 사용했을 때와 다르게 class="active" 라는 속성이 자동으로 생성된다. */}
      {/* 어떤 페이지에 위치하고 있는지 알 수 있게 내비게이션에 사용자가 위치한 곳을 표시할 수 있다. */}
      <h2>NavLink 컴포넌트 사용</h2>
      <ul>
        <li><NavLink to='/'>Home</NavLink></li>
        <li><NavLink to='/topics'>Topics</NavLink></li>
        <li><NavLink to='/contact'>Contact</NavLink></li>
      </ul>

      <Routes>
        <Route path='/' element={<Home />} />
        {/* <Route path='/topics' element={<Topics />} /> */}
        {/* 하위 페이지가 있으면 topics를 담당하는 Route의 path를 /topics/*로 설정한다. */}
        <Route path='/topics/*' element={<Topics />} />
        <Route path='/contact' element={<Contact />} />
        {/* 존재하지 않는 페이지로 접근했을 경우 아래와 같이 구현한다. */}
        <Route path='/*' element={"Not Found"} />
      </Routes>
    </div>
  );
}

export default App;
