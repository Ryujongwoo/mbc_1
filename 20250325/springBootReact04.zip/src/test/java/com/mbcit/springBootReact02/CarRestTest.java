package com.mbcit.springBootReact02;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpHeaders;
import org.springframework.test.web.servlet.MockMvc;

@SpringBootTest
//	컨트롤러나 다른 노출된 엔드포인트를 테스트 하려면 @AutoConfigureMockMvc 어노테이션을 이용한다.
@AutoConfigureMockMvc
public class CarRestTest {

//	MockMvc 객체를 이용하면 서버가 시작되지는 않지만 스프링이 HTTP 요청을 처리하는 계층에서 실제
//	상황을 모의 테스트할 수 있다.
	@Autowired
	private MockMvc mockMvc;
	
	@Test
	public void testAuthentication() throws Exception {
//		올바른 자격 증명으로 인증 테스트
		mockMvc.perform(
			post("/login")
			.content("{\"username\": \"user\", \"password\": \"user\"}")
			.header(HttpHeaders.CONTENT_TYPE, "application/json")
		).andDo(print()).andExpect(status().isOk());
		
	}
	
}



















