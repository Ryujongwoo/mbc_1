package com.mbcit.springBootBoard.service;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.mbcit.springBootBoard.entity.Article;

import lombok.extern.slf4j.Slf4j;

//	@SpringBootTest 어노테이션을 붙여서 springBoot와 연동한 통합 테스를 수행한다.
@SpringBootTest
@Slf4j
class ArticleServiceTest {

	@Autowired
	private ArticleService articleService;
	
//	article 테이블 전체 글 목록 조회 테스트
	@Test
	void 테스트는_메소드_이름을_한글로_해도_상관없다() {
//		예상
//		index() 메소드가 실행되었을 때 예상되는 결과를 만든다.
		List<Article> expected = new ArrayList();
		expected.add(new Article(4L, "일지매", "4등 입니다."));
		expected.add(new Article(3L, "장길산", "3등 입니다."));
		expected.add(new Article(2L, "임꺽정", "2등 입니다."));
		expected.add(new Article(1L, "홍길동", "1등 입니다."));
		log.info("expected: " + expected);
//		실제
//		index() 메소드가 실제로 실행되었을 때 결과를 얻어온다.
		List<Article> actual = articleService.index();
		log.info("actual: " + actual);
//		비교
//		예상되는 결과와 실제로 실행되었을 때 결과를 비교한다.
		assertEquals(expected.toString(), actual.toString());
	}

//	article 테이블 전체 특정 글 조회 테스트 => 성공시
	@Test
	void 성공시_존재하는_id가_입력된_경우() {
//		예상
		Article expected = new Article(1L, "홍길동", "1등 입니다.");
//		실제
		Article actual = articleService.show(1L);
//		비교
		assertEquals(expected.toString(), actual.toString());
	}
	
//	article 테이블 전체 특정 글 조회 테스트 => 실패시
	@Test
	void 실패시_존재하지_않는_id가_입력된_경우() {
//		예상
		Article expected = null;
//		실제
		Article actual = articleService.show(5L);
//		비교
		assertEquals(expected, actual);
	}

	@Test
	void testCreateArticle() {
		
	}

	@Test
	void testUpdate() {
		
	}

	@Test
	void testDelete() {
		
	}

}
