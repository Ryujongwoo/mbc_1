package com.mbcit.k20250117_3_springBoot_JdbcTemplate;

import lombok.Data;

@Data
public class MyUserVO {

	private String id;
	private String name;
	
}
