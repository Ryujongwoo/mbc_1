import React from "react";

function MyComponent() {
  const ButtonPressed = () => alert('눌러봐 버튼을 눌렀습니다.');
  return (
    <div align='center'>
      <h1>MyComponent</h1>
      <button type="button" onClick={ButtonPressed}>눌러봐</button>
    </div>
  );
}

export default MyComponent;
