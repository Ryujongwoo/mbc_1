package com.mbcit.k20250121_1_springBoot_JPA01.support;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;

//	엔티티 리스너는 @Autowired에 의해서 자동으로 bean을 주입받지 못한다.
//	springBoot가 자동으로 bean을 생성하도록 @Component 어노테이션을 붙이고 ApplicationContextAware
//	인터페이스를 구현받아 bean을 주입받는 객체를 만든다.
@Component
public class BeanUtils implements ApplicationContextAware {

	private static ApplicationContext applicationContext;
	
	@Override
	public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
		System.out.println("BeanUtils 클래스의 setApplicationContext() 메소드 실행됨");
		System.out.println("applicationContext: " + applicationContext);
		BeanUtils.applicationContext = applicationContext;
	}
	
	public static<T> T getBean(Class<T> clazz) {
		return applicationContext.getBean(clazz);
	}

}
