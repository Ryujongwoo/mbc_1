-- 주석
CREATE TABLE "GUESTBOOK" (
    "IDX" NUMBER(*,0) NOT NULL, 
	"NAME" CHAR(20 BYTE) NOT NULL, 
	"PASSWORD" CHAR(20 BYTE) NOT NULL, 
	"MEMO" VARCHAR2(3000 BYTE) NOT NULL, 
	"WRITEDATE" TIMESTAMP (6) DEFAULT sysdate, 
	"IP" CHAR(20 BYTE), 
	CONSTRAINT "GUESTBOOK_PK" PRIMARY KEY ("IDX")
);

-- 오라클은 자동 증가 기능을 사용하려면 sequence를 만들어 사용해야 한다.
-- 시퀀스 초기화 => 시퀀스가 다시 1부터 시작되게 한다.
-- 모든 데이터를 제거하고 시퀀스를 삭제하고 다시 만든다.
delete from guestbook;
-- 시퀀스 지우기: drop sequence 시퀀스이름;
drop sequence guestbook_idx_seq;
-- 시퀀스 만들기: create sequence 시퀀스이름;
create sequence guestbook_idx_seq;

-- 시퀀스이름.nextval: 시퀀스 값을 1증가 시킨다.
-- 시퀀스이름.currval: 현재 시퀀스 값을 의미한다.
insert into guestbook(idx, name, password, memo, ip) 
values (guestbook_idx_seq.nextval, '홍길동', '1111', '1등 입니다.', '162.168.300.101');
insert into guestbook(idx, name, password, memo, ip) 
values (guestbook_idx_seq.nextval, '임꺽정', '2222', '2등 입니다.', '162.168.300.102');
insert into guestbook(idx, name, password, memo, ip) 
values (guestbook_idx_seq.nextval, '장길산', '3333', '3등 입니다.', '162.168.300.103');
insert into guestbook(idx, name, password, memo, ip) 
values (guestbook_idx_seq.nextval, '일지매', '4444', '4등 입니다.', '162.168.300.104');

select * from guestbook;
select count(*) from guestbook;
select * from guestbook where idx = 1;

-- 둘리% => 둘리로 시작하는, %둘리 => 둘리로 끝나는, %둘리% => 둘리를 포함하는
select count(*) from guestbook where memo like '%1등%';
select count(*) from guestbook where name like '%길%';
select count(*) from guestbook where memo like '%1등%' or name like '%꺽%';

-- 트랜잭션: 한 번에 모두 실행되야 할 명령들의 집합
-- commit: 트랜잭션이 정상적으로 처리되서 결과를 데이터베이스에 반영한다.
-- rollback: 트랜잭션이 정상적으로 처리되지 않아서 트랜잭선 실행 이전 상태로 되될린다.
-- 오라클 디벨로퍼는 기본적으로 auto commit을 지원하지 않기 때문에 디벨로퍼에서 실행한 값이 jsp에
-- 적용되게 하려면 반드시 commit 명령을 실행해야 한다.
-- 디벨로퍼 auto commit 설정하기 
-- 도구 => 환경설정 => 커밋으로 검색 => 데이터베이스 아래 고급에서 자동 커밋에 체크한다.
commit;







