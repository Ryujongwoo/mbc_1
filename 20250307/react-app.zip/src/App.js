import './App.css';
import { useState } from 'react';

// 사용자 정의 컴포넌트(사용자 정의 함수, 이하 컴포넌트)를 만든다.
// 컴포넌트 이름은 반드시 대문자로 시작해야 한다.
// 컴포넌트의 인수로 컴포넌트가 호출될 때 전달되는 데이터(prop)를 받는다.
// 인수 이름은 props라고 지정했는데 인수 이름은 반드시 props라고 할 필요는 없다.
// 남들다 props로 하니까 우리도 props라고 했다.
function Header(props) {
  // props로 넘어온 속성에 할당된 속성 값은 '.'을 찍어서 얻어온다.
  // console.log(`props: ${props}, props.title: ${props.title}`)
  // console.log(props, props.title, props.onChangeMode)
  // 컴포넌트는 반드시 html 코드를 return 시켜야 한다.
  return (
    <header>
      {/* props로 넘어온 데이터를 사용하려면 {}로 묶어준다. */}
      <h1><a href='/' onClick={
        event => {
          // <a> 태그가 실행하는 기본 동작을 실행하지 않는다.
          event.preventDefault()
          // Header 컴포넌트가 호출될 때 넘겨받은 onChangeMode prop에 저장된 함수를 실행한다.
          props.onChangeMode()
        }
      }>{props.title}</a></h1>
    </header>
  )
}

function Nav(props) {
  let lis = [] // return할 결과를 저장할 빈 배열을 선언한다.
  for (let i=0; i<props.topics.length; i++) {
    // console.log(props.topics[i])
    let topic = props.topics[i]

    // Each child in a list should have a unique "key" prop. 메시지가 출력되는 경우 아래와 같이 처리한다.
    // 반복문을 사용해서 동적으로 만든 <li> 태그는 key라는 prop을 가지고 있어야 하고,
    // key라는 prop은 반복문 내부에서 고유한 값을 가져야 한다.
    lis.push(
      <li key={topic.id}>
        <a id={topic.id} href={'/read/' + topic.id} onClick={
          event => {
            event.preventDefault()
            // onChangeMode prop에 저장되서 넘어오는 함수를 호출할 때 id 값을 전달해야 한다.
            // 이벤트 함수 안에서 <a> 태그의 id 속성값을 얻어내려면 event 객체를 사용한다.
            // event.target이라고 하면 target은 이벤트를 발생시킨 태그, 즉 <a> 태그를 의미한다.
            // <a> 태그가 가지고 있는 id 속성값은 event.target.id와 같은 형태로 얻어올 수 있다.
            props.onChangeMode(event.target.id)
          }
        }>{topic.title}</a><br/>
        {topic.body}
      </li>
    )
  }

  return (
    <nav>
      <ol>
        {/*
        <li><a href='/read/1'>html</a></li>
        <li><a href='/read/2'>css</a></li>
        <li><a href='/read/3'>js</a></li>
        */}
        {lis}
      </ol>
    </nav>
  )
}

function Article(props) {
  return (
    <article>
      <h2>{props.title}</h2>
      {props.body}
    </article>
  )
}

function App() {
  // Nav 컴포넌트에 전달할 정보가 저장된 배열을 만든다.
  const topics = [
    {id: 1, title: 'html', body: 'html is ...'},
    {id: 2, title: 'css', body: 'css is ...'},
    {id: 3, title: 'js', body: 'js is ...'},
  ]

  // let mode = 'WELCOME'
  // useState는 배열을 리턴하는데 리턴되는 배열의 0번째 인덱스 요소는 상태값을 읽을 때 쓰이는 데이터이고,
  // 1번째 인덱스 요소는 상태값을 변경하는 함수이다.
  // const ['상태의 초기값', 상태값이 변경되면 실행할 함수] = useState('상태의 초기값')
  const [mode, setMode] = useState('WELCOME')

  let content = null
  if (mode === 'WELCOME') {
    content = <Article title="Welcome" body="Hello, WEB" />
  } else if (mode === 'READ') {
    content = <Article title="Welcome" body="Hello, READ" />
  }
  
  return (
    <div className="App">
      {/*
      html 태그는 속성을 가지고 있다.
      컴포넌트도 html 태그처럼 속성을 지정할 수 있다. 이를 prop이라 한다.
      컴포넌트로 prop을 전달할 때 문자열은 따옴표로 묶어서 전달하고 문자열이 아닌 데이터는 {}로 묶어서 전달한다.
      onChangeMode라는 prop의 값으로 함수를 전달한다.
      */}
      <Header title="React" onChangeMode={() => {
        // alert('Header')
        // mode = 'WELCOME'
        // console.log(mode)
        setMode('WELCOME')
      }}></Header>
      <Nav topics={topics} onChangeMode={id => {
        // alert(id)
        // mode = 'READ'
        // console.log(mode)
        setMode('READ')
      }}/>
      {content}
    </div>
  );
}

export default App;

