package com.mbcit.springBootReact02;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import com.mbcit.springBootReact02.service.JwtService;

//	필터 클래스는 들어오는 다른 모든 요청을 인증하는데 이용된다.
//	필터 클래스는 OncePerRequestFilter 추상 클래스를 상속받아서 만든다.
//	OncePerRequestFilter 추상 클래스에는 인증을 구현할 doFilterInternal() 메소드가 있다.
@Component
public class AuthenticationFilter extends OncePerRequestFilter {

//	요청에 있는 토큰을 확인하려면 필요하므로 JwtService 인스턴스를 필터 클래스에 주입한다.
	@Autowired
	private JwtService jwtService;
	
	@Override
//	인증을 구현할 메소드
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, 
			FilterChain filterChain) throws ServletException, IOException {
		
//		Authorization 헤더에서 토큰을 가져온다.
		String jwts = request.getHeader(HttpHeaders.AUTHORIZATION);
		
		if (jwts != null) {
//			토큰을 확인하고 사용자를 얻어온다.
			String user = jwtService.getAuthUser(request);
//			인증한다.
			Authentication authentication = 
					new UsernamePasswordAuthenticationToken(user, null, 
							java.util.Collections.emptyList());
			SecurityContextHolder.getContext().setAuthentication(authentication);
		}
		filterChain.doFilter(request, response);
	}

}













