function singleArray() {
//	배열 선언 방법
//	let 배열이름 = new Array(); // 크기가 0인 빈 배열 객체를 선언한다.
	let array1 = new Array();
	console.log(array1);
	console.log(typeof array1);
	console.log(array1.length);
	console.log('1. =================================');
	
//	let 배열이름 = []; // 크기가 0인 빈 배열 객체를 선언한다.
	let array2 = [];
	console.log(array2);
	console.log(typeof array2);
	console.log(array2.length);
	console.log('2. =================================');
	
//	let 배열이름 = new Array(크기); // 크기가 지정된 빈 배열 객체를 선언한다.
	let array3 = new Array(5);
	console.log(array3);
	console.log(typeof array3);
	console.log(array3.length);
	console.log('3. =================================');
	
//	초기치 개수 만큼의 크기를 가지는 배열 객체를 선언하고 초기치로 초기화 한다.
//	let 배열이름 = new Array(초기치); 
	let array4 = new Array(1, 2, 3, 4, 5);
	console.log(array4);
	console.log(typeof array4);
	console.log(array4.length);
	console.log('4. =================================');
	
//	let 배열이름 = [초기치]; 
	let array5 = [1, 2, 3, 4, 5];
	console.log(array5);
	console.log(typeof array5);
	console.log(array5.length);
	console.log('5. =================================');
}

function multiArray() {
	let row = 4; // 행
	let col = 3; // 열
	
//	2차원 빈 배열은 행을 먼저 만들고 행의 개수만큼 반복하며 열을 만든다.
	let array = new Array(row); // 행을 만든다.
	for (let i = 0; i < row; i++) { // 행의 개수만큼 반복한다.
		array[i] = new Array(col); // 각각의 행에 열을 만든다.
	}
	console.log(array);

//	2차원 배열의 각 인덱스에 접근하려면 배열이름[행][열] 형태로 접근한다.
	array[0][0] = 'apple';
	array[0][1] = 'banana';
	array[0][2] = 'melon';
	
	array[1][0] = 100;
	array[1][1] = 200;
	array[1][2] = 300;
	
	array[2][0] = true;
	array[2][1] = 3.14;
	array[2][2] = '홍길동';
	
//	배열에 배열을 저장시킬 수 있다.
	array[3][0] = ['임꺽정', '바보']; // 3차원, 배열이름[면][행][열]
	array[3][1] = ['장길산', '천재'];
	array[3][2] = ['손오공', '원숭이'];
	
	console.log(array);
	console.log(array[0]);
	console.log(array[3][0]);
	console.log(array[3][0][0]);
	
//	초기치를 지정해서 2차원 배열을 만들 수 있다.
	let array2 = [[1, 2], [3, 4], [5, 6]];
	console.log(array2);
}

function joinArray() {
	let fruits = ['apple', 'banana', 'melon', 'mango'];
	let numbers = ['111', '222', '333', '444'];
	
//	배열을 연결하려고 덧셈 연산자를 사용하면 각각의 배열 요소는 ','로 구분된 문자열로 만들어서 연결한다.
	let add = fruits + numbers;
	console.log(add);
	console.log(typeof add);
	
//	2개 이상의 배열을 연결하려면 concat() 함수를 사용해야 한다.
	let result = fruits.concat(numbers)
	console.log(result);
	console.log(typeof result);
	
//	join() 함수는 배열 요소 사이사이에 인수로 지정한 문자열을 삽입해서 문자열로 만든다.
	let result2 = fruits.join(', ');
	console.log(result2);
	console.log(typeof result2);
}

function alphaSort() {
//	배열이름.sort(): 코드값을 기준으로 오름차순으로 정렬한다. 무조건 문자 데이터로 취급한다.
//	null도 문자열로 취급하고 숫자도 문자열로 취급한다.
	let array = ['a', 5, null, 'c', 'b', 'A', 100, 'nt', 'nv'];
	array.sort();
	console.log(array); // [100, 5, 'A', 'a', 'b', 'c', 'nt', null, 'nv']
}

function numberSort() {
	let array = [1, 4, 3, 8, 9, 7, 10];
//	배열을 구성하는 모든 데이터가 숫자라도 무조건 문자 데이터로 취급해서 코드값의 오름차순으로 정렬한다.
	array.sort();
	console.log(array); // [1, 10, 3, 4, 7, 8, 9]
	
//	숫자 순서로 데이터를 정렬하려면 sort() 함수의 인수로 비교 함수를 넣어줘야 한다.
//	sort() 함수가 자동으로 비교 함수에 데이터를 넘겨주기 때문에 비교 함수는 ()를 생략한다.

//	숫자 비교 함수를 만든다.
//	오름차순으로 정렬시키려면 앞의 인수가 크면 양수, 같으면 0, 작으면 음수를 리턴시킨다.
//	내림차순으로 정렬시키려면 앞의 인수가 크면 음수, 같으면 0, 작으면 양수를 리턴시킨다.
	/*
	function compare(a, b) {
		// return a - b; // 오름차순 정렬
		return -(a - b); // 내림차순 정렬
	}
	array.sort(compare);
	*/
	
//	비교 함수는 익명으로 구현해도 된다.
//	array.sort(function (a, b) {
//		return a - b;
//	});
	array.sort((a, b) => a - b);
	console.log(array);
}

function reverseTest() {
	let names = ['홍길동', '임꺽정', '장길산', '일지매'];
	
	names.sort();
	console.log(names);
	
//	문자열 비교 함수를 만든다. => 오름차순 정렬
//	문자열을 내림차순 정렬하는 함수로 수정하려면 조건식의 부등호를 반대로 변경하거나 리턴 값의 부호를
//	반대로 변경하면 된다.
	function compare(a, b) {
		if (a > b) {
			return 1;
		} else if (a < b) {
			return -1;
		} else {
			return 0;
		}
	}
	
	names.sort(compare);
	console.log(names);
	
//	배열이름.reverse(): 배열에 저장된 데이터를 뒤집는다.
	names.reverse();
	console.log(names);
}

