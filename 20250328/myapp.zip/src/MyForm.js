import React from "react";

function MyForm() {
  const submitHandler = event => {
    console.log(event);
    event.preventDefault(); // 이벤트의 기본 동작을 실행하지 않는다.
    alert('submit 버튼이 클릭됨');
  }
  return (
    <div align='center'>
      <h1>MyForm</h1>
      <form onSubmit={submitHandler}>
        <input type="submit" value="눌러봐" />
      </form>
    </div>
  );
}

export default MyForm;
