package com.mbcit.k20250117_4_springBoot_SimpleBBS;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class K202501174SpringBootSimpleBbsApplicationTests {

	@Test
	void contextLoads() {
	}

}
