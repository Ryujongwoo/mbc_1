package com.mbcit.springWEB_controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/contentView")
//	컨트롤러 클래스에 @RequestMapping 어노테이션을 붙여주면 컨트롤러에 붙여준 @RequestMapping
//	어노테이션과 메소드에 붙여준 @RequestMapping 어노테이션의 요청을 합쳐서 요청해야 viewpage를
//	제대로 찾아갈 수 있다.
//	"/contentView/board" 형태로 요청해야 board.jsp를 요청할 수 있다.
public class YourController {

	private static final Logger logger = LoggerFactory.getLogger(YourController.class);
	
	@RequestMapping("/board")
	public String board() {
		logger.info("YourController 클래스의 board() 메소드 실행");
		return "board/board";
	}
	
}
