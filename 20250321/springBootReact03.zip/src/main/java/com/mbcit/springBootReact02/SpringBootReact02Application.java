package com.mbcit.springBootReact02;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.mbcit.springBootReact02.domain.Car;
import com.mbcit.springBootReact02.domain.CarRepository;
import com.mbcit.springBootReact02.domain.Owner;
import com.mbcit.springBootReact02.domain.OwnerRepository;

@SpringBootApplication
//	H2 데이터베이스에 데이터를 추가하기 위해 CommandLineRunner 인터페이스를 구현받는다.
public class SpringBootReact02Application implements CommandLineRunner {

	private static final Logger logger = LoggerFactory.getLogger(SpringBootReact02Application.class);
	
	@Autowired
	private CarRepository carRepository;
	@Autowired
	private OwnerRepository ownerRepository;
	
	public static void main(String[] args) {
		SpringApplication.run(SpringBootReact02Application.class, args);
	}

//	CommandLineRunner 인터페이스를 구현받으면 가변 인자를 인수로 가지는 run() 메소드를 Override 시켜서
//	사용해야 하며 이 메소드는 springBoot가 실행된 후 애플리케이션이 완전히 실행되기 전에 자동 실행된다.
	@Override
	public void run(String... args) throws Exception {
		System.out.println("SpringBootReact02Application 클래스의 run() 메소드 실행");
		System.out.println("carRepository: " + carRepository);
		
//		소유자 객체를 추가하고 데이터베이스에 저장한다.
		Owner owner1 = new Owner("장", "용훈");
		Owner owner2 = new Owner("강", "재성");
		ownerRepository.save(owner1);
		ownerRepository.save(owner2);
		
		carRepository.save(new Car("기아", "모닝", "빨강", "123가 1234", 2024, 1400, owner1));
		carRepository.save(new Car("현대", "액센트", "검정", "123나 1234", 2022, 2100, owner2));
		carRepository.save(new Car("쉐보레", "스파크", "파랑", "123다 1234", 2024, 1500, owner2));
		
//		모든 자동차를 가져와서 콘솔에 로그로 출력한다.
		for (Car car : carRepository.findAll()) {
//			logger.info(car.toString());
//			logger.info(String.valueOf(car));
//			logger.info(car + "");
			logger.info(car.getBrand() + ": " + car.getModel());
		}
	}

}
