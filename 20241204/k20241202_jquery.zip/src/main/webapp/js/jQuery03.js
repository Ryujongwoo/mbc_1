function imgSize() {
//	$('img').css('width', '200px');
//	$('img').css('height', '200px');
//	$('img').css('width', '200px').css('height', '200px');
	$('img').css({'width': '200px', 'height': '200px'});
}

function idSelector() {
//	$('#selId').css('display', 'none');
	$('#selId').hide();
}

function classSelector() {
	$('.selClass').css('opacity', '0.5');
}

//	속성 선택자
//	태그와 태그에 지정된 속성 및 속성 값으로 요소 찾기
//	태그이름[속성이름]: 지정된 속성을 가지고있는 모든 태그들을 선택한다.
//	태그이름[속성이름=문자열]: 지정된 속성과 속성 값을 정확히 가지고있는 모든 태그들을 선택한다. => 완전일치
//	태그이름[속성이름~=문자열]: 지정된 속성과 속성 값이 공백을 경계로 문자열을 포함된 모든 태그들을 선택한다. => 단어포함
//	태그이름[속성이름*=문자열]: 지정된 속성과 속성 값에 문자열이 포함되는 모든 태그들을 선택한다. => 문장포함 
//	태그이름[속성이름$=문자열]: 지정된 속성과 속성 값이 문자열로 끝나는 모든 태그들을 선택한다. => ~로 끝나는
//	태그이름[속성이름^=문자열]: 지정된 속성과 속성 값이 문자열로 시작하는 모든 태그들을 선택한다. => ~로 시작하는
//	태그이름[속성이름!=문자열]: 지정된 속성과 속성 값이 문자열과 같지 않은 모든 태그들을 선택한다.
//	태그이름[속성이름|=문자열]: 지정된 속성과 속성 값을 정확히 '문자열-'으로 시작하는 모든 태그들을 선택한다.

function attributeSelector() {
//	img 태그 중에서 id 속성이 지정된 요소만 선택한다.
//	$('img[id]').css('opacity', '0.3');
//	img 태그 중에서 title 속성 값이 정확히 'img02'인 요소만 선택한다.
//	$('img[title=img02]').css('opacity', '0.3');
//	img 태그 중에서 title 속성 값에 'img02'가 단어로 포함된 요소만 선택한다.
//	$('img[title~=img02]').css('opacity', '0.3');
//	img 태그 중에서 title 속성 값에 'img02'가 포함된 요소만 선택한다.
	$('img[title*=img02]').css('opacity', '0.3');
//	img 태그 중에서 title 속성 값이 '04'로 끝나는 요소를 선택한다.
//	$('img[title$=04]').css('opacity', '0.3');
//	img 태그 중에서 title 속성 값이 'image'로 시작하는 요소를 선택한다.
//	$('img[title^=image]').css('opacity', '0.3');
//	img 태그 중에서 title 속성 값이 'img04'가 아닌 요소를 선택한다.
//	$('img[title!=img04]').css('opacity', '0.3');
//	img 태그 중에서 title 속성 값이 'img01-'으로 시작하는 요소를 선택한다.
//	$('img[title|=img01]').css('opacity', '0.3');
}

//	속성과 프로퍼티 설정
//	.attr(): 선택된 요소 집합의 첫 번째 요소로 지정된 속성 값을 얻어오거나 선택된 소요의 지정된 속성을
//		     변경한다.
//	.removeAttr(): 지정된 속성을 제거한다.
//	.prop(): 선택된 요소 집합의 첫 번째 요소로 지정된 프로퍼티 값을 얻어오거나 선택된 소요의 지정된 프로퍼티를
//		     변경한다.
//	.removeProp(): 지정된 프로퍼티를 제거한다.
//	checked="checked"에서 checked는 속성 이름이고 "checked"는 속성 값이다.
//	checked="checked"를 지정하면 라디오 버튼이 체크 박스가 체크된다. 이 때, 체크된 상태를 의미하는 true와
//	체크되지 않은 상태를 false를 프로퍼티라고 한다.

function changeImg() {
//	attr('속성이름'): 인수로 지정된 속성의 값을 얻어온다.
	console.log($('img').eq(4).attr('id'));
	console.log($('img:eq(4)').attr('title'));
	console.log($('img:eq(4)').attr('src'));
//	attr('속성이름', '속성값'): 인수로 지정된 속성의 값을 변경한다.
	$('img:eq(4)').attr('src', './images/img05.jpg');
//	removeAttr('속성이름'): 인수로 지정된 속성을 제거한다.
	$('img:eq(5)').removeAttr('src');
}

