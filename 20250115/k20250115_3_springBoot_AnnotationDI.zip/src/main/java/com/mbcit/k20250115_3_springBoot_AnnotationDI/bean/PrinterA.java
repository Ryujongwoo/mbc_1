package com.mbcit.k20250115_3_springBoot_AnnotationDI.bean;

import org.springframework.stereotype.Component;

//	bean으로 등록하려는 클래스는 @Component 어노테이션을 붙여준다.
//	@Component 어노테이션의 인수로 자동으로 등록할 bean의 이름을 저정할 수 있다.
@Component("printerA")
public class PrinterA implements Printer {

	@Override
	public void print(String message) {
		System.out.println("PrinterA: " + message);
	}

}
