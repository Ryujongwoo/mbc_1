package com.mbcit.memo;

import java.util.ArrayList;

//	게시글 목록을 기억하는 클래스
public class MemoList {

	private ArrayList<MemoVO> memoList = new ArrayList<MemoVO>();

	public ArrayList<MemoVO> getMemoList() {
		return memoList;
	}
	public void setMemoList(ArrayList<MemoVO> memoList) {
		this.memoList = memoList;
	}
	
	@Override
	public String toString() {
		String str = "";
		
		if (memoList.size() == 0) { // 저장된 글이 있는가?
//			저정된 글이 없으므로 글이 없다고 출력한다.
			str += "저장된 글이 없습니다.\n";
		} else {
			str += "총 " + memoList.size() + "개의 저장된 글이 있습니다.\n";
//			입력한 순서대로 출력한다.
//			for (int i = 0; i < memoList.size(); i++) {
//				str += memoList.get(i) + "\n";
//			}
//			입력 순서의 역순으로(최신글 부터) 출력한다.
			for (int i = memoList.size() - 1; i >= 0; i--) {
				str += memoList.get(i) + "\n";
			}
		}
		
		return str;
	}
	
//	MemoMain 클래스에서 호출되는 memoList라는 ArrayList에 저장할 데이터 저장된 MemoVO 클래스 객체를
//	넘겨받아 memoList라는 ArrayList에 저장하는 메소드
	public void addMemo(MemoVO vo) {
		System.out.println("MemoList 클래스의 addMemo() 메소드 실행");
		memoList.add(vo);
	}
	
//	MemoMain 클래스에서 호출되는 memoList라는 ArrayList에 저장된 글 1건을 얻어와서 리턴하는 메소드
	public MemoVO selectMemo(int idx) {
		System.out.println("MemoList 클래스의 selectMemo() 메소드 실행");
		try {
			return memoList.get(idx - 1);
		} catch (IndexOutOfBoundsException e) {
			return null;
		}
	}
	
//	MemoMain 클래스에서 호출되는 삭제할 글번호를 넘겨받아 memoList라는 ArrayList에 저장된 글 1건을
//	삭제하는 메소드
	public void removeMemo(int idx) {
		System.out.println("MemoList 클래스의 removeMemo() 메소드 실행");
		memoList.remove(idx - 1);
		
//		ArrayList는 데이터가 삽입될 경우 삽입되는 위치 이후의 데이터가 자동을 뒤로 이동되고
//		데이터가 삭제될 경우 삭제되는 위치 이후의 데이터가 자동으로 앞으로 이동된다.
//		메모 삭제 후 인덱스가 변경되므로 인덱스에 맞춰서 글번호를 다시 붙여준다.
//		이러한 현상은 데이터베이스를 사용하지 않고 ArrayList를 사용해서 발생되는 현상이다.
		
//		메모 삭제 후 글번호를 1부터 다시 붙여준다.
		for (int i = 0; i < memoList.size(); i++) {
			memoList.get(i).setIdx(i + 1);
		}
		
//		글이 삭제된 후 새글이 입력될 때 idx가 기존 idx 값에 이어서 1씩 증가할 수 있도록
//		count 변수의 값을 수정한다.
		MemoVO.count = memoList.size();
	}
	
	
//	MemoMain 클래스에서 호출되는 수정할 글번호와 수정할 메모를 넘겨받아 memoList라는 ArrayList에
//	저장된 글 1건을 수정하는 메소드
	public void updateMemo(int idx, String memo) {
		System.out.println("MemoList 클래스의 updateMemo() 메소드 실행");
		memoList.get(idx - 1).setMemo(memo);
	}
	
}
















