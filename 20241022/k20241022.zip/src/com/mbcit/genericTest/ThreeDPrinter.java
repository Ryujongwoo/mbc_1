package com.mbcit.genericTest;

//	재료로 Plastic과 Powder를 모두 사용하는 3D 프린터 => 겸용 프린터
public class ThreeDPrinter {

//	재료로 Plastic과 Powder를 모두 사용하는 3D 프린터는 Plastic과 Powder를 모두 재료로
//	받을 수 있어야 하기 때문에 Plastic과 Powder 클래스의 부모 클래스가 Object 클래스이므로
//	Object 타입으로 선언해야 한다.
	private Object material;

	public Object getMaterial() {
		return material;
	}

	public void setMaterial(Object material) {
		this.material = material;
	}

	@Override
	public String toString() {
		return material + "을(를) 재료로 사용하는 3D 프린터 사용중";
	}
	
}
