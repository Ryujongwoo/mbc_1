package com.mbcit.k20250121_1_springBoot_JPA1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class K202501211SpringBootJpa1Application {

	public static void main(String[] args) {
		SpringApplication.run(K202501211SpringBootJpa1Application.class, args);
	}

}
