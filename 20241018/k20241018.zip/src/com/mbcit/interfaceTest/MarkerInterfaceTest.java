package com.mbcit.interfaceTest;

//	모든 유닛의 최고 조상 클래스 Unit을 만든다.
class Unit {
	
	public final int MAX_HP; // 최대 HP, 상수
	public int currentHP; // 현재 HP, 멤버 변수
	
	public Unit(int hp) {
		MAX_HP = hp;
	}
	
}

//	Unit 클래스를 상속받아 육상 유닛의 조상 클래스 GroundUnit을 만든다.
class GroundUnit extends Unit {
	
}

//	Unit 클래스를 상속받아 공중 유닛의 조상 클래스 AirUnit을 만든다.
class AirUnit extends Unit {
	
}

//	GroundUnit 클래스를 상속받아 Tank를 만든다.
class Tank extends GroundUnit {
	
}

//	GroundUnit 클래스를 상속받아 Marine을 만든다.
class Marine extends GroundUnit {
	
}

//	GroundUnit 클래스를 상속받아 SCV을 만든다.
class SCV extends GroundUnit {
	
}

//	AirUnit 클래스를 상속받아 DropShip을 만든다.
class DropShip extends AirUnit {
	
}

public class MarkerInterfaceTest {

	public static void main(String[] args) {
		
		
		
	}
	
}
