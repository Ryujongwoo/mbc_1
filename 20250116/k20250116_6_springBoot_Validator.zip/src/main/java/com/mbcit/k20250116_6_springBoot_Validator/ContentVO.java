package com.mbcit.k20250116_6_springBoot_Validator;

import lombok.Data;

@Data
public class ContentVO {

	private int id;
	private String writer;
	private String content;
	
}
