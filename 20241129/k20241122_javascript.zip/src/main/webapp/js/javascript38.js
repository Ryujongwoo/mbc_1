onload = () => {
//	alert('꺄~~~~~~~~~~~~~');
	let a = document.querySelectorAll('a');
	let img = document.querySelectorAll('img')[0];
	let count = 3;
	
//	'◀'에 onclick 이벤트를 할당한다.
	a[0].onclick = () => {
		// getAttribute('속성이름'): 인수로 지정된 속성의 속성 값을 얻어온다.
		let alt = img.getAttribute('alt');
		// console.log(alt);
		if (alt === 'img01') {
			alert('첫 번째 이미지 입니다.');
		} else {
			img.setAttribute('src', './images/img0' + --count + '.jpg');
			img.setAttribute('alt', 'img0' + count);
		}
	}

//	'▶'에 onclick 이벤트를 할당한다.
	a[1].onclick = () => {
		// let alt = img.getAttribute('alt');
		if (count > 4) {
			alert('마지막 이미지 입니다.');
		} else {
			img.setAttribute('src', `./images/img0${++count}.jpg`);
			img.setAttribute('alt', `img0${count}`);
		}
	}
}

