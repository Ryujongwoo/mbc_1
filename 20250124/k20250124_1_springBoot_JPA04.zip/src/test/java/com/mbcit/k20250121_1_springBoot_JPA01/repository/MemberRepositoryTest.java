package com.mbcit.k20250121_1_springBoot_JPA01.repository;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.persistence.Column;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;

import org.assertj.core.util.Lists;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.domain.Sort.Order;

import com.mbcit.k20250121_1_springBoot_JPA01.domain.Gender;
import com.mbcit.k20250121_1_springBoot_JPA01.domain.Member;
import com.mbcit.k20250121_1_springBoot_JPA01.repository.MemberRepository;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@SpringBootTest
class MemberRepositoryTest {

	@Autowired
	private MemberRepository memberRepository;
	
	@Test
	void test() {
		System.out.println("MemberRepositoryTest 클래스의 test() 메소드 실행");
		log.info("결과: {}", memberRepository.findAll());
		memberRepository.findAll().forEach(System.out::println);
	}
	
	@Test
	public void insertAndUpdateTest() {
		System.out.println("MemberRepositoryTest 클래스의 insertAndUpdateTest() 메소드 실행");
		System.out.println("@Column(updatable = false), @Column(insertable = false) 테스트");
		
		Member member = new Member();
		member.setName("손오공");
		member.setEmail("son@mbcit.com");
		memberRepository.save(member);
		
		Member member2 = memberRepository.findById(1L).orElse(null);
		member2.setName("저팔계");
		memberRepository.save(member2);
		memberRepository.findAll().forEach(System.out::println);
	}

	@Test
	public void enumTest() {
		System.out.println("MemberRepositoryTest 클래스의 enumTest() 메소드 실행");
		Member member = memberRepository.findById(1L).orElse(null);
		memberRepository.save(member);
		memberRepository.findAll().forEach(System.out::println);
		Map<String, Object> map = memberRepository.findRecord();
		for (String key : map.keySet()) {
			System.out.println(key + ": " + map.get(key));
		}
	}
	
	@Test
	public void basicMethod() {
		System.out.println("MemberRepositoryTest 클래스의 basicMethod() 메소드 실행");
		List<Member> members = memberRepository.findAll();
		members.forEach(System.out::println);
		
		members = memberRepository.findAll(Sort.by(Direction.ASC, "name"));
		members.forEach(System.out::println);
		
		members = memberRepository.findAll(Sort.by(Direction.DESC, "id"));
		members.forEach(System.out::println);
		
		Member member = memberRepository.findById(10L).orElse(null);
		System.out.println(member);
		
		members = memberRepository.findAllById(Lists.newArrayList(1L, 3L, 4L));
		members.forEach(System.out::println);
		
		memberRepository.save(new Member("손오공1", "son1@mbcit.com"));
		memberRepository.save(new Member("손오공2", "son2@mbcit.com"));
		memberRepository.flush();
		memberRepository.saveAndFlush(new Member("손오공3", "son3@mbcit.com")); // 즉시 적용
		members = memberRepository.findAll();
		members.forEach(System.out::println);
		
		Member member1 = new Member("저팔계", "jeo@mbcit.com");
		Member member2 = new Member("사오정", "sa@mbcit.com");
		Member member3 = new Member("오로라공주", "aurora@mbcit.com");
		memberRepository.saveAll(Lists.newArrayList(member1, member2, member3));
		members = memberRepository.findAll();
		members.forEach(System.out::println);
		
		long count = memberRepository.count();
		System.out.println(count);
		
		boolean exists = memberRepository.existsById(1L);
		System.out.println(exists);
		System.out.println(exists ? "있음" : "없음");
		
//		Page<Member> page = memberRepository.findAll(PageRequest.of(2, 5));
//		Page<Member> page = memberRepository.findAll(PageRequest.of(2, 5, Sort.by(Direction.ASC, "name")));
		Page<Member> page = memberRepository.findAll(PageRequest.of(2, 5, Sort.by(Direction.DESC, "id")));
		System.out.println(page);
		page.getContent().forEach(System.out::println);
		System.out.println(page.getTotalElements());
		System.out.println(page.getNumberOfElements());
		System.out.println(page.getSort());
		System.out.println(page.getSize());
		
		memberRepository.delete(memberRepository.findById(1L).orElse(null));
		memberRepository.deleteById(4L);
		members = memberRepository.findAll();
		members.forEach(System.out::println);
		
		memberRepository.deleteAll(memberRepository.findAllById(Lists.newArrayList(6L, 7L)));
		members = memberRepository.findAll();
		members.forEach(System.out::println);
		
		memberRepository.deleteAll();
		members = memberRepository.findAll();
		members.forEach(System.out::println);
		
		memberRepository.save(new Member("유비", "yoo@mbcit.com"));
		members = memberRepository.findAll();
		members.forEach(System.out::println);
		
		member = new Member();
		member.setId(13L);
		member.setName("관우");
		member.setEmail("kwan@mbcit.com");
		memberRepository.save(member);
		members = memberRepository.findAll();
		members.forEach(System.out::println);
	}
	
	@Test
	public void select() {
		System.out.println("MemberRepositoryTest 클래스의 select() 메소드 실행");
		
//		id 필드 이외의 필드 조회하기
//		Member member = memberRepository.findByName("임꺽정"); // 정상 실행
//		Member member = memberRepository.findByName("홍길동"); // 에러 발생
//		List<Member> members = memberRepository.findByName("임꺽정"); // 정상 실행
		List<Member> members = memberRepository.findByName("홍길동"); // 정상 실행
		members.forEach(System.out::println);
		
//		특정 접두어로 시작하는 메소드 실행하기
		members = memberRepository.findByEmail("hong@mbcit.com");
		members.forEach(System.out::println);
		System.out.println("findByEmail() 메소드 실행 결과");
		
		members = memberRepository.getByEmail("hong@mbcit.com");
		members.forEach(System.out::println);
		System.out.println("getByEmail() 메소드 실행 결과");
		
		members = memberRepository.queryByEmail("hong@mbcit.com");
		members.forEach(System.out::println);
		System.out.println("queryByEmail() 메소드 실행 결과");
		
		members = memberRepository.readByEmail("hong@mbcit.com");
		members.forEach(System.out::println);
		System.out.println("readByEmail() 메소드 실행 결과");
		
		members = memberRepository.searchByEmail("hong@mbcit.com");
		members.forEach(System.out::println);
		System.out.println("searchByEmail() 메소드 실행 결과");
		
		members = memberRepository.streamByEmail("hong@mbcit.com");
		members.forEach(System.out::println);
		System.out.println("streamByEmail() 메소드 실행 결과");
		
//		limit를 지정하는 메소드 실행하기
		members = memberRepository.findTopByName("홍길동");
		members.forEach(System.out::println);
		System.out.println("findTopByName() 메소드 실행 결과");
		
		members = memberRepository.findTop2ByName("홍길동");
		members.forEach(System.out::println);
		System.out.println("findTop2ByName() 메소드 실행 결과");
		
		members = memberRepository.findFirst2ByName("홍길동");
		members.forEach(System.out::println);
		System.out.println("findFirst2ByName() 메소드 실행 결과");
		
		members = memberRepository.findBottom2ByName("홍길동");
		members.forEach(System.out::println);
		System.out.println("findBottom2ByName() 메소드 실행 결과");
		
		members = memberRepository.findLast2ByName("홍길동");
		members.forEach(System.out::println);
		System.out.println("findLast2ByName() 메소드 실행 결과");
	}
	
	@Test
	public void select2() {
		System.out.println("MemberRepositoryTest 클래스의 select2() 메소드 실행");

//		and, or 조건을 사용하는 메소드 실행하기
		List<Member> members = memberRepository.findByNameAndEmail("홍길동", "hong@mbcit.com");
		members.forEach(System.out::println);
		System.out.println("findByNameAndEmail() 메소드 실행 결과");
		
		members = memberRepository.findByEmailAndName("hong@mbcit.com", "홍길동");
		members.forEach(System.out::println);
		System.out.println("findByEmailAndName() 메소드 실행 결과");
		
		members = memberRepository.findByNameOrEmail("장길산", "lim@mbcit.com");
		members.forEach(System.out::println);
		System.out.println("findByNameOrEmail() 메소드 실행 결과");
		
		members = memberRepository.findByEmailOrName("gildong@mbcit.com", "일지매");
		members.forEach(System.out::println);
		System.out.println("findByEmailOrName() 메소드 실행 결과");
		
//		초과, 미만 조건을 사용하는 메소드 실행하기
		members = memberRepository.findByIdAfter(3L);
		members.forEach(System.out::println);
		System.out.println("findByIdAfter() 메소드 실행 결과");
		
		members = memberRepository.findByIdGreaterThan(3L);
		members.forEach(System.out::println);
		System.out.println("findByIdGreaterThan() 메소드 실행 결과");
		
		members = memberRepository.findByIdBefore(4L);
		members.forEach(System.out::println);
		System.out.println("findByIdBefore() 메소드 실행 결과");
		
		members = memberRepository.findByIdLessThan(4L);
		members.forEach(System.out::println);
		System.out.println("findByIdLessThan() 메소드 실행 결과");
		
//		이상, 이하 조건을 사용하는 메소드 실행하기
		members = memberRepository.findByIdGreaterThanEqual(3L);
		members.forEach(System.out::println);
		System.out.println("findByIdGreaterThanEqual() 메소드 실행 결과");
		
		members = memberRepository.findByIdLessThanEqual(4L);
		members.forEach(System.out::println);
		System.out.println("findByIdLessThanEqual() 메소드 실행 결과");
		
//		between 조건을 사용하는 메소드 실행하기
		members = memberRepository.findByIdGreaterThanEqualAndIdLessThanEqual(2L, 5L);
		members.forEach(System.out::println);
		System.out.println("findByIdGreaterThanEqualAndIdLessThanEqual() 메소드 실행 결과");
		
		members = memberRepository.findByIdBetween(2L, 5L);
		members.forEach(System.out::println);
		System.out.println("findByIdBetween() 메소드 실행 결과");
		
		members = memberRepository.findByIdGreaterThanAndIdLessThan(2L, 5L);
		members.forEach(System.out::println);
		System.out.println("findByIdGreaterThanAndIdLessThan() 메소드 실행 결과");
		
		members = memberRepository.findByIdAfterAndIdBefore(2L, 5L);
		members.forEach(System.out::println);
		System.out.println("findByIdAfterAndIdBefore() 메소드 실행 결과");
		
		members = memberRepository.findByIdGreaterThanAndIdBefore(2L, 5L);
		members.forEach(System.out::println);
		System.out.println("findByIdGreaterThanAndIdBefore() 메소드 실행 결과");
		
		members = memberRepository.findByIdAfterAndIdLessThan(2L, 5L);
		members.forEach(System.out::println);
		System.out.println("findByIdAfterAndIdLessThan() 메소드 실행 결과");
	}
	
	@Test
	public void select3() {
		System.out.println("MemberRepositoryTest 클래스의 select3() 메소드 실행");

		memberRepository.save(new Member("손오공", "son@mbcit.com"));
		memberRepository.save(new Member("사오정", "sa@mbcit.com"));
		List<Member> members = memberRepository.findAll();
		members.forEach(System.out::println);
		System.out.println("save() 메소드 실행 결과");
		
//		null, not null을 사용하는 메소드 실행하기
		members = memberRepository.findByCreateDateIsNull();
		members.forEach(System.out::println);
		System.out.println("findByCreateDateIsNull() 메소드 실행 결과");
		
		members = memberRepository.findByCreateDateIsNotNull();
		members.forEach(System.out::println);
		System.out.println("findByCreateDateIsNotNull() 메소드 실행 결과");
		
//		in, not in을 사용하는 메소드 실행하기
		List<String> names = new ArrayList<>();
		names.add("임꺽정");
		names.add("장길산");
		names.add("일지매");
		
		members = memberRepository.findByNameIn(names);
		members.forEach(System.out::println);
		System.out.println("findByNameIn() 메소드 실행 결과");
		
		members = memberRepository.findByNameNotIn(Lists.newArrayList("임꺽정", "장길산", "일지매"));
		members.forEach(System.out::println);
		System.out.println("findByNameNotIn() 메소드 실행 결과");
		
//		like(부분일치)를 사용하는 메소드 실행하기
		members = memberRepository.findByNameLike("홍%");
		members.forEach(System.out::println);
		System.out.println("findByNameLike() 메소드 실행 결과");
		
		members = memberRepository.findByNameLike("%정");
		members.forEach(System.out::println);
		System.out.println("findByNameLike() 메소드 실행 결과");
		
		members = memberRepository.findByNameLike("%길%");
		members.forEach(System.out::println);
		System.out.println("findByNameLike() 메소드 실행 결과");
		
		members = memberRepository.findByNameStartingWith("홍");
		members.forEach(System.out::println);
		System.out.println("findByNameStartingWith() 메소드 실행 결과");
		
		members = memberRepository.findByNameEndingWith("정");
		members.forEach(System.out::println);
		System.out.println("findByNameEndingWith() 메소드 실행 결과");
		
		members = memberRepository.findByNameContains("길");
		members.forEach(System.out::println);
		System.out.println("findByNameContains() 메소드 실행 결과");
	}
	
	@Test
	public void sort() {
		System.out.println("MemberRepositoryTest 클래스의 sort() 메소드 실행");
		
//		정렬 메소드 실행하기
		memberRepository.save(new Member("손오공", "son@mbcit.com"));
		memberRepository.save(new Member("사오정", "sa@mbcit.com"));
		List<Member> members = memberRepository.findAllByOrderByNameAsc();
		members.forEach(System.out::println);
		System.out.println("findAllByOrderByNameAsc() 메소드 실행 결과");
		
		members = memberRepository.findAllByOrderByEmailDesc();
		members.forEach(System.out::println);
		System.out.println("findAllByOrderByEmailDesc() 메소드 실행 결과");
		
		members = memberRepository.findByNameOrderByEmailAsc("홍길동");
		members.forEach(System.out::println);
		System.out.println("findByNameOrderByEmailAsc() 메소드 실행 결과");
		
		members = memberRepository.findByNameOrderByIdDesc("홍길동");
		members.forEach(System.out::println);
		System.out.println("findByNameOrderByIdDesc() 메소드 실행 결과");
		
		members = memberRepository.findTop3AllByOrderByNameAsc();
		members.forEach(System.out::println);
		System.out.println("findTop3AllByOrderByNameAsc() 메소드 실행 결과");
		
		members = memberRepository.findTop2ByNameOrderByIdDesc("홍길동");
		members.forEach(System.out::println);
		System.out.println("findTop2ByNameOrderByIdDesc() 메소드 실행 결과");
		
		members = memberRepository.findAllByOrderByNameDescEmailAsc();
		members.forEach(System.out::println);
		System.out.println("findAllByOrderByNameDescEmailAsc() 메소드 실행 결과");
		
		members = memberRepository.findAllByOrderByEmailAscIdDesc();
		members.forEach(System.out::println);
		System.out.println("findAllByOrderByEmailAscIdDesc() 메소드 실행 결과");
		
		members = memberRepository.findAllByOrderByNameDescEmailAscIdDesc();
		members.forEach(System.out::println);
		System.out.println("findAllByOrderByNameDescEmailAscIdDesc() 메소드 실행 결과");
		
		members = memberRepository.findAll(getSort());
		members.forEach(System.out::println);
		System.out.println("findFirst3ByName() 메소드 실행 결과");
	}
	
//	정렬 기준이 지정된 Sort 클래스 객체를 리턴하는 메소드
	private Sort getSort() {
		return Sort.by(
			Order.desc("name"), 
			Order.asc("email"), 
			Order.asc("id")
		);
	}
	
	@Test
	public void paging() {
		System.out.println("MemberRepositoryTest 클래스의 paging() 메소드 실행");

		memberRepository.save(new Member("손오공", "son@mbcit.com"));
		memberRepository.save(new Member("사오정", "sa@mbcit.com"));

//		페이징 메소드 실행하기
//		PageRequest.of(페이지 번호, 페이지 크기, [정렬 방식])
//		Page<Member> page = memberRepository.findAll(PageRequest.of(1, 3));
//		Page<Member> page = memberRepository.findAll(PageRequest.of(1, 3, Sort.by(Direction.ASC, "name")));
		Page<Member> page = memberRepository.findAll(PageRequest.of(1, 3, 
			Sort.by(
				Order.asc("name"),
				Order.desc("email")
			)
		));
		
		System.out.println(page);
		System.out.println(page.getTotalElements());
		System.out.println(page.getSize());
		System.out.println(page.getTotalPages());
		System.out.println(page.getNumber());
		System.out.println(page.getNumberOfElements());
		page.getContent().forEach(System.out::println);
		System.out.println(page.getSort());
		
		System.out.println(page.hasContent());
		System.out.println(page.isFirst());
		System.out.println(page.isLast());
		System.out.println(page.hasNext());
		System.out.println(page.hasPrevious());
		
		page = memberRepository.findAll(PageRequest.of(0, 3, Sort.by(Order.desc("id"))));
		System.out.println("현재 페이지");
		page.getContent().forEach(System.out::println);
		int number = 0; int size = 0; Sort sort = null;
		
//		다음 페이지가 있으면 다음 페이지를 리턴하고 없으면 현재 페이지를 리턴한다.
		if (page.hasNext()) {
			System.out.println("다음 페이지 있음");
			number = page.nextPageable().getPageNumber();
			size = page.nextPageable().getPageSize();
			sort = page.nextPageable().getSort();
			page = memberRepository.findAll(PageRequest.of(number, size, sort));
			page.getContent().forEach(System.out::println);
		} else {
			System.out.println("다음 페이지 없음");
			number = page.getPageable().getPageNumber();
			size = page.getPageable().getPageSize();
			sort = page.getPageable().getSort();
			page = memberRepository.findAll(PageRequest.of(number, size, sort));
			page.getContent().forEach(System.out::println);
		}
		
		page = memberRepository.findAll(PageRequest.of(2, 3, Sort.by(Order.desc("id"))));
		System.out.println("현재 페이지");
		page.getContent().forEach(System.out::println);
		
//		이전 페이지가 있으면 이전 페이지를 리턴하고 없으면 현재 페이지를 리턴한다.
		if (page.hasPrevious()) {
			System.out.println("이전 페이지 있음");
			number = page.previousPageable().getPageNumber();
			size = page.previousPageable().getPageSize();
			sort = page.previousPageable().getSort();
			page = memberRepository.findAll(PageRequest.of(number, size, sort));
			page.getContent().forEach(System.out::println);
		} else {
			System.out.println("이전 페이지 없음");
			number = page.getPageable().getPageNumber();
			size = page.getPageable().getPageSize();
			sort = page.getPageable().getSort();
			page = memberRepository.findAll(PageRequest.of(number, size, sort));
			page.getContent().forEach(System.out::println);
		}
	
//		default 메소드
		page = memberRepository.findAll(PageRequest.of(2, 3, Sort.by(Order.desc("id"))));
		System.out.println("현재 페이지");
		page.getContent().forEach(System.out::println);
		
		number = page.nextOrLastPageable().getPageNumber();
		size = page.nextOrLastPageable().getPageSize();
		sort = page.nextOrLastPageable().getSort();
		page = memberRepository.findAll(PageRequest.of(number, size, sort));
		page.getContent().forEach(System.out::println);
		
		page = memberRepository.findAll(PageRequest.of(0, 3, Sort.by(Order.desc("id"))));
		System.out.println("현재 페이지");
		page.getContent().forEach(System.out::println);
		
		number = page.previousOrFirstPageable().getPageNumber();
		size = page.previousOrFirstPageable().getPageSize();
		sort = page.previousOrFirstPageable().getSort();
		page = memberRepository.findAll(PageRequest.of(number, size, sort));
		page.getContent().forEach(System.out::println);
	}
	
	@Test
	public void eventTest() {
		System.out.println("MemberRepositoryTest 클래스의 eventTest() 메소드 실행");

//		JPA가 제공하는 엔티티 이벤트 테스트
		Member member = new Member();
		member.setName("손오공");
		member.setEmail("son@mbcit.com");
		System.out.println(member);
		memberRepository.save(member); // insert
		
		Member member2 = memberRepository.findById(1L).orElse(null); // select
		
		member2.setName("장용훈");
		System.out.println(member2);
		memberRepository.save(member2); // update
		
		memberRepository.deleteById(2L); // delete
		
		List<Member> members = memberRepository.findAll(); // select
		members.forEach(System.out::println);
	}
	
	@Test
	public void prePersistTest() {
		System.out.println("MemberRepositoryTest 클래스의 prePersistTest() 메소드 실행");
	
//		@PrePersist 엔티티 이벤트 테스트
		Member member = new Member();
		member.setName("손오공");
		member.setEmail("son@mbcit.com");
		
//		최초 저장 시간이나 최종 수정 시간을 엔티티가 저장되거나 수정되는 시점에서 코딩하면 사소한 실수를
//		유발할 수 있다.
//		이 문제를 해결하기 위해서 @PrePersist, @PreUpdate 어노테이션을 붙여서 선언한 메소드에서 처리를
//		하는 것을 권장한다.
//		member.setCreateDate(LocalDateTime.now());
//		member.setUpdateDate(LocalDateTime.now());
		
		memberRepository.save(member);
		
		List<Member> members = memberRepository.findAll();
		members.forEach(System.out::println);
	}
	
	@Test
	public void preUpdateTest() {
		System.out.println("MemberRepositoryTest 클래스의 preUpdateTest() 메소드 실행");
		
//		@PreUpdate 엔티티 이벤트 테스트
		Member member2 = memberRepository.findById(1L).orElse(null);
		member2.setName("장용훈");
		memberRepository.save(member2);
		
		List<Member> members = memberRepository.findAll();
		members.forEach(System.out::println);
	}
		
}























