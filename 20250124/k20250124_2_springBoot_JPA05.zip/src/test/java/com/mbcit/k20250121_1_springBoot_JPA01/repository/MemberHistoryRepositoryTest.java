package com.mbcit.k20250121_1_springBoot_JPA01.repository;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class MemberHistoryRepositoryTest {

	@Test
	void test() {
		System.out.println("MemberHistoryRepositoryTest 클래스의 test() 메소드 실행");
	}

}
