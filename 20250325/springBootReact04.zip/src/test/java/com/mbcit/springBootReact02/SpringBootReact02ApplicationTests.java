package com.mbcit.springBootReact02;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.mbcit.springBootReact02.web.CarController;

//	@SpringBootTest 어노테이션은 해당 클래스가 springBoot 기반 테스트를 실행하는 클래스임을 알려준다.
@SpringBootTest
class SpringBootReact02ApplicationTests {

	@Autowired
	private CarController carController;
	
//	@Test 어노테이션은 해당 메소드를 테스트 케이스로 실행할 수 있다고 JUnit에게 알려준다.
	@Test
//	@DisplayName 어노테이션으로 테스트 케이스에 대한 자세한 이름을 지정할 수 있다.
	@DisplayName("First exalpme test case")
	void contextLoads() {
		assertThat(carController).isNotNull();
	}

}
