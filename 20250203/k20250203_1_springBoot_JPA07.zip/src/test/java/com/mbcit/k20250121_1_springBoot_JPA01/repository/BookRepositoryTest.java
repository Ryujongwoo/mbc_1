package com.mbcit.k20250121_1_springBoot_JPA01.repository;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.mbcit.k20250121_1_springBoot_JPA01.domain.Book;

@SpringBootTest
class BookRepositoryTest {

	@Autowired
	private BookRepository bookRepository;
	
	@Test
	void test() {
		System.out.println("BookRepositoryTest 클래스의 test() 메소드 실행");
		
		Book book = new Book();
		book.setName("홍길동");
//		book.setAuthor("날로먹는 springBoot JPA"); // author를 제거했으므로 주석으로 처리한다.
		book.setCategory("java");
		book.setAuthorId(10L);
		book.setPublisherId(20L);
		bookRepository.save(book);
		
		List<Book> books = bookRepository.findAll();
		books.forEach(System.out::println);
		
//		try {
//			Thread.sleep(3000);
//		} catch (InterruptedException e) {
//			e.printStackTrace();
//		}
		
//		book = bookRepository.findById(1L).orElse(null);
//		book.setName("임꺽정");
//		bookRepository.save(book);
		
//		books = bookRepository.findAll();
//		books.forEach(System.out::println);
	}

}












