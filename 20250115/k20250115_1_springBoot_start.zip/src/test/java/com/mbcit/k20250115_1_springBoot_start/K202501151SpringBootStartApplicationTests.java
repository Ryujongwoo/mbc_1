package com.mbcit.k20250115_1_springBoot_start;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class K202501151SpringBootStartApplicationTests {

	@Test
	void contextLoads() {
	}

}
