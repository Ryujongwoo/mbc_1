package com.mbcit.springBootBoard.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.mbcit.springBootBoard.dto.ArticleForm;

import lombok.extern.slf4j.Slf4j;

@Controller
@Slf4j
public class ArticleController {

//	데이터를 입력하는 폼을 띄우는 요청 처리한다.
	@GetMapping("/articles/new")
	public String newArticleForm() {
//		@Slf4j 어노테이션 로그 레벨, 로그는 반드시 문자열로 지정한다.
//		log.trace("가장 디테일한 로그");
//		log.warn("경고 로그");
//		log.info("정보성 로그");
//		log.debug("디버깅용 로그");
//		log.error("에러 로그");
		log.info("ArticleController의 newArticleForm() 메소드 실행");
		return "articles/new";
	}
	
	@PostMapping("/articles/create")
//	form에서 넘어오는 데이터는 커맨드 객체로 받으면 편리하다.
	public String createArticle(/* HttpServletRequest request, */ArticleForm articleForm, Model model) {
		log.info("ArticleController의 createArticle() 메소드 실행");
//		log.info("title: " + request.getParameter("title"));
//		log.info("content: " + request.getParameter("content"));
//		model.addAttribute("title", request.getParameter("title"));
//		model.addAttribute("content", request.getParameter("content"));
		log.info("articleForm: " + articleForm);
		
		
		
		
//		return "goodbye";
		return "articles/new";
	}
	
}















