package com.mbcit.k20250121_1_springBoot_JPA01.domain;

import java.time.LocalDateTime;

import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;

public class MyEntityListener {

//	엔티티 리스너는 여러 엔티티 클래스에서 사용될 수 있으므로 @PrePersist, @PreUpdate 어노테이션을 붙여서
//	구현한 메소드로 넘어오는 객체가 달라지므로 모든 객체를 받아서 처리할 수 있도록 Object 타입으로 인수를
//	지정해야 한다.
	
	@PrePersist
	public void prePersist(Object object) {
		System.out.println("MyEntityListener 리스너의 prePersist() 메소드 실행됨");
//		createDate = LocalDateTime.now();
//		updateDate = LocalDateTime.now();
//		prePersist() 메소드의 인수로 넘어온 객체가 Auditable 인터페이스로 정상적으로 형변환이 된다면
//		엔티티 리스너를 사용하는 엔티티 클래스이므로 작성일과 수정일 저장한다.
		if (object instanceof Auditable) {
			((Auditable) object).setCreateDate(LocalDateTime.now());
			((Auditable) object).setUpdateDate(LocalDateTime.now());
		}
	}
	
	@PreUpdate
	public void preUpdate(Object object) {
		System.out.println("MyEntityListener 리스너의 preUpdate() 메소드 실행됨");
//		updateDate = LocalDateTime.now();
//		prePersist() 메소드의 인수로 넘어온 객체가 Auditable 인터페이스로 정상적으로 형변환이 된다면
//		엔티티 리스너를 사용하는 엔티티 클래스이므로 수정일을 저장한다.
		if (object instanceof Auditable) {
			((Auditable) object).setUpdateDate(LocalDateTime.now());
		}
	}

}









