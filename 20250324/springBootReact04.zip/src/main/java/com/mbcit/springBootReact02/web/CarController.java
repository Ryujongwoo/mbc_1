package com.mbcit.springBootReact02.web;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mbcit.springBootReact02.domain.Car;
import com.mbcit.springBootReact02.domain.CarRepository;

@RestController
public class CarController {

	@Autowired
	private CarRepository carRepository;
	
	@RequestMapping("/cars")
	public Iterable<Car> getCars() {
		System.out.println("CarController 클래스의 getCars() 메소드 실행");
		return carRepository.findAll();
	}

//	spring security를 사용하려면 pom.xml에 아래의 dependency를 추가해야 한다.
//	<!-- 애플리케이션용 security -->
//	<dependency>
//		<groupId>org.springframework.boot</groupId>
//		<artifactId>spring-boot-starter-security</artifactId>
//	</dependency>
//	
//	<!-- 테스트용 security -->
//	<dependency>
//		<groupId>org.springframework.security</groupId>
//		<artifactId>spring-security-test</artifactId>
//		<scope>test</scope>
//	</dependency>
	
//	리액트로 프론트엔드를 개발할 때는 RESTful 웹 서비스 기본 인증을 이용할 수 없으므로 JWT 인증을
//	이용해야 한다.
//	JWT(JSON Web Token)는 최신 앱 애플리케이션에서 간단하게 인증을 구현하는 방법으로 JWT는 크기가
//	아주 작기때문에 URL POST 매개변수 또는 헤더에 넣어서 전송할 수 있다. 또한 그러면서도 사용자에 대한
//	모든 필수 정보를 담고 있다.
	
//	JWT는 xxxxx.yyyyy.zzzzz와 같이 마침표로 구분된 세 부분으로 구성되며, 다음과 같은 내용을 포함한다.
//	첫 번째 부분(xxxxx)은 토큰의 유형과 해싱 알고리즘을 정의하는 헤더이다.
//	두 번째 부분(yyyyy)은 페이로드이며, 일반적으로 인증의 경우 사용자 정보를 포함한다.
//	세 번째 부분(zzzzz)은 토큰이 변조되지 않았음을 증명하기 위한 서명이다.
//	인증이 성공하고 나면 클라이언트가 보내는 요청에는 항상 인증 과정에서 받은 JWT을 포함해야 한다.
	
//	자바와 안드로이드용 JWT 라이브러리인 jjwt 라이브러리(https://github.com/jwtk/jjwt)를 pom.xml 파일에
//	의존성을 추가해야 한다. jjwt 라이브러리에는 JWT를 생성하고 파싱하는 기능이 있다.
//	JWT를 사용하려면 pom.xml에 아래의 dependency를 추가해야 한다.
//	<dependency>
//    	<groupId>io.jsonwebtoken</groupId>
//	    <artifactId>jjwt-api</artifactId>
//	    <version>0.12.6</version>
//	</dependency>
//	<dependency>
//	    <groupId>io.jsonwebtoken</groupId>
//	    <artifactId>jjwt-impl</artifactId>
//	    <version>0.12.6</version>
//	    <scope>runtime</scope>
//	</dependency>
//	<dependency>
//	    <groupId>io.jsonwebtoken</groupId>
//	    <artifactId>jjwt-jackson</artifactId> <!-- or jjwt-gson if Gson is preferred -->
//	    <version>0.12.6</version>
//	    <scope>runtime</scope>
//	</dependency>
	
}


















