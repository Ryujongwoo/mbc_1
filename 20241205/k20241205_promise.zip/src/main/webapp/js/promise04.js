//	콜백 지옥

//	아이디와 비밀번호를 입력받는다.
const id = prompt('아이디를 입력하세요');
const pw = prompt('비밀번호를 입력하세요');

//	아이디와 비밀번호를 입력받아서 로그인 처리와 로그인 후 역할을 받아오는 처리를 하는 클래스
class UserStorage {
	
//	로그인 처리함수
//	loginUser(아이디, 비밀번호, 로그인 성공시 실행할 callback 함수, 로그인 실패시 실행할 callback 함수)
	loginUser(id, pw, onSuccess, onError) {
//		setTimeout(function () {
		setTimeout(() => {
			if (id === '홍길동' && pw === '1111' || id === '임꺽정' && pw === '2222') {
				// 로그인에 성공했으므로 역할을 받아오는 callback 함수를 실행한다.
				onSuccess(id);
			} else {
				// 로그인에 실패했을 때 실행할 callback 함수를 실행한다.
				onError('로그인 실패');
			}
		}, 2000);
	}

//	로그인 후 아이디에 따른 역할을 받아오는 함수
//	getRoles(아이디, 역할을 받아오면 실행할 callback 함수, 역할을 받아오지 못하면 실행할 callback 함수)
	getRoles(id, onSuccess, onError) {
		setTimeout(function () {
			if (id === '홍길동') {
				onSuccess({
					name: '홍길동',
					role: '관리자'
				});
			} else {
				onError('역할을 받아오지 못함');
			}
		}, 1000);
	}
}

//	로그인 처리를 하기위해서 UserStorage 클래스 객체를 생성한다.
const userStorage = new UserStorage();

/*
//	로그인에 성공했을 때 실행할 함수
const onSuccess = function (id) {
	console.log(id + '님 로그인 성공');
//	로그인에 성공했으므로 아이디에 따른 역할을 받아온다.
	userStorage.getRoles(id, onSuccess2, onError2);
}
//	로그인에 실패했을 때 실행할 함수
const onError = function (error) {
	console.log(error);
}
//	역할을 받아왔을 때 실행할 함수
const onSuccess2 = function (role) {
	console.log(`안녕하세요 ${role.name}님 당신의 권한은 ${role.role} 입니다.`);
} 
//	역할을 받아오지 못했을 때 실행할 함수
const onError2 = function (error) {
	console.log(error);
}

//	loginUser() 함수를 호출해서 로그인 처리를 한다.
userStorage.loginUser(id, pw, onSuccess, onError);
*/

/*
userStorage.loginUser(id, pw, function (id) {
	console.log(id + '님 로그인 성공');
	userStorage.getRoles(id, function (role) {
		console.log(`안녕하세요 ${role.name}님 당신의 권한은 ${role.role} 입니다.`);
	}, function (error) {
		console.log(error);
	});
}, function (error) {
	console.log(error);
});
*/

/*
userStorage.loginUser(id, pw, id => {
	console.log(id + '님 로그인 성공');
	userStorage.getRoles(id, role => {
		console.log(`안녕하세요 ${role.name}님 당신의 권한은 ${role.role} 입니다.`);
	}, error => console.log(error));
}, error => console.log(error));
*/

userStorage.loginUser(
	id, 
	pw, 
	id => {
		console.log(id + '님 로그인 성공');
		userStorage.getRoles(
			id, 
			role => console.log(`안녕하세요 ${role.name}님 당신의 권한은 ${role.role} 입니다.`), 
			error => console.log(error));
	}, 
	error => console.log(error)
);



















