import { Button, Dialog, DialogActions, DialogContent, DialogTitle, Stack, TextField } from "@mui/material";
import React, { useState } from "react";

function AddCar(props) {
  // 추가할 데이터를 입력할 모달창 표시 여부를 지정하는 open 상태를 추가하고
  // 처음에는 보이면 안되기 때문에 초기값은 false로 지정한다.
  const [open, setOpen] = useState(false);
  // 추가할 자동차 정보를 기억할 car 상태를 추가하고 초기값은 공백으로 지정한다.
  const [car, setCar] = useState({brand: '', model: '', color: '', year: '', price: ''});

  // 모달 창이 열리도록 open 상태값을 true로 수정하는 함수
  const handleOpen = () => setOpen(true);
  // 모달 창이 닫히도록 open 상태값을 false로 수정하는 함수
  const handleClose = () => setOpen(false);

  // 입력된 자동차 정보로 car 상태를 수정하는 함수
  const handleChange = function (event) {
    setCar({...car, [event.target.name]: event.target.value});
  }

  // 자동차를 저장하고 모달 창을 닫는 함수
  const handleSave = function () {
    props.addCar(car);
    handleClose();
  }

  return (
    <div>
      <br/>
      <Button type="button" variant="outlined" onClick={handleOpen}>New Car</Button>
      <br/><br/>
      {/*
      <Stack mt={2} mb={2}>
        <Button type="button" variant="outlined" onClick={handleOpen}>New Car</Button>
      </Stack>
      */}
      <Dialog open={open} onClose={handleClose}>
        <DialogTitle>New Car</DialogTitle>
        <DialogContent>
          {/*
          <input name="brand" placeholder="Brand" value={car.brand} onChange={handleChange}/><br/>
          <input name="model" placeholder="Model" value={car.model} onChange={handleChange}/><br/>
          <input name="color" placeholder="Color" value={car.color} onChange={handleChange}/><br/>
          <input name="year" placeholder="Year" value={car.year} onChange={handleChange}/><br/>
          <input name="price" placeholder="Price" value={car.price} onChange={handleChange}/>
          */}
          <Stack spacing={2} mt={1}>
            <TextField name="brand" label="Brand" value={car.brand} onChange={handleChange}/>
            <TextField name="model" label="Model" value={car.model} onChange={handleChange}/>
            <TextField name="color" label="Color" value={car.color} onChange={handleChange}/>
            <TextField name="year" label="Year" value={car.year} onChange={handleChange}/>
            <TextField name="price" label="Price" value={car.price} onChange={handleChange}/>
          </Stack>
        </DialogContent>
        <DialogActions>
          <Button type="button" variant="outlined" onClick={handleSave}>Save</Button>
          <Button type="button" variant="outlined" onClick={handleClose}>Cancel</Button>
        </DialogActions>
      </Dialog>
    </div>
  )
}

export default AddCar;