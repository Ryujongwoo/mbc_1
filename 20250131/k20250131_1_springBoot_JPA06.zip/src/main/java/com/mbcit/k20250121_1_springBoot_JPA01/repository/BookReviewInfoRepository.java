package com.mbcit.k20250121_1_springBoot_JPA01.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mbcit.k20250121_1_springBoot_JPA01.domain.BookReviewInfo;

public interface BookReviewInfoRepository extends JpaRepository<BookReviewInfo, Long> {

	
	
}
