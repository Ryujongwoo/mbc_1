import React, { useEffect, useState } from "react";

function CarList() {

  // springBoot에 REST API로 요청해서 응답받은 정보를 저장할 cars라는 상태를 선언하고
  // 빈 배열로 초기화 한다.
  const [cars, setCars] = useState([]);

  // CarList 컴포넌트가 최초 렌더링된 후 useEffect()에서 fetch()를 이용해서 springBoot에
  // 자동차 정보를 요청한다.
  // 최초 렌더링 후에만 useEffect()를 실행해야 하므로 두 번째 인수로 빈 배열을 전달한다.
  useEffect(function () {
    fetch('http://localhost:9090/api/cars')
      .then(function (response) {
        // console.log(response.json());
        return response.json();
      })
      .then(function (data) {
        console.log(data._embedded.cars);
      })
      .catch(function (error) {
        console.log('에러 발생', error);
      })
  }, []);

  return (
    <div>
      CarList
    </div>
  )
}

export default CarList;