package com.mbcit.springBootReact01;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;

public class Car {

	@Autowired
	private Owner owner;
	@Resource
	private ConfigFileResource configFileResource;
	
	public Car() {
		owner = new Owner(); // 클래스의 객체 생성
	}

	public Car(Owner owner) {
		this.owner = owner; // 생성자에 클래스 객체를 인수로 전달
	}

	public void setOwner(Owner owner) {
		this.owner = owner; // setter 메소드에 클래스 객체를 인수로 전달
	}
	
}
