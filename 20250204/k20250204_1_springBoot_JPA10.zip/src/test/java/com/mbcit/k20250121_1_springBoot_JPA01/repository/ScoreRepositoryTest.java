package com.mbcit.k20250121_1_springBoot_JPA01.repository;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.mbcit.k20250121_1_springBoot_JPA01.domain.Score;

@SpringBootTest
class ScoreRepositoryTest {

	@Autowired
	private ScoreRepository scoreRepository;
	
	@Test
	void JPQLTest() {
		System.out.println("ScoreRepositoryTest 클래스의 JPQLTest() 메소드 실행");
		
		List<Score> scores = scoreRepository.findAll();
		scores.forEach(System.out::println);
		
		scores = scoreRepository.findByScore(75, 80);
		scores.forEach(System.out::println);
		
		scores = scoreRepository.findByScoreParam(75, 80);
		scores.forEach(System.out::println);
		
		scores = scoreRepository.findByNative();
		scores.forEach(System.out::println);
		
		List<String> tables = scoreRepository.showTables();
		tables.forEach(System.out::println);
	}

}














