package com.mbcit.k20250121_1_springBoot_JPA01.repository;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import javax.persistence.ManyToOne;
import javax.transaction.Transactional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.mbcit.k20250121_1_springBoot_JPA01.domain.Book;
import com.mbcit.k20250121_1_springBoot_JPA01.domain.Member;
import com.mbcit.k20250121_1_springBoot_JPA01.domain.Publisher;
import com.mbcit.k20250121_1_springBoot_JPA01.domain.Review;

@SpringBootTest
class BookRepositoryTest {

	@Autowired
	private BookRepository bookRepository;
	
	@Autowired
	private ReviewRepository reviewRepository;
	@Autowired
	private PublisherRepository publisherRepository;
	@Autowired
	private MemberRepository memberRepository;
	
	@Test
	@Transactional
	void test() {
		System.out.println("BookRepositoryTest 클래스의 test() 메소드 실행");
		
		Book book = new Book();
		book.setName("홍길동");
//		book.setAuthor("날로먹는 springBoot JPA"); // author를 제거했으므로 주석으로 처리한다.
		book.setCategory("java");
//		book.setAuthorId(10L);
//		book.setPublisherId(20L);
		bookRepository.save(book);
		
		List<Book> books = bookRepository.findAll();
		books.forEach(System.out::println);
		
//		try {
//			Thread.sleep(3000);
//		} catch (InterruptedException e) {
//			e.printStackTrace();
//		}
		
//		book = bookRepository.findById(1L).orElse(null);
//		book.setName("임꺽정");
//		bookRepository.save(book);
		
//		books = bookRepository.findAll();
//		books.forEach(System.out::println);
	}

	@Test
	@Transactional
	void bookRelationTest() {
		System.out.println("BookRepositoryTest 클래스의 bookRelationTest() 메소드 실행");

		givenReview(givenMember(), givenBook(givenPublisher()));
		
		Member member = memberRepository.findByEmail("jang@mbcit.com").get(0);
		System.out.println("Member: " + member);
		System.out.println("Review: " + member.getReviews());
		System.out.println("Book: " + member.getReviews().get(0).getBook());
		System.out.println("Publisher: " + member.getReviews().get(0).getBook().getPublisher());
	}

	private void givenReview(Member member, Book book) {
		Review review = new Review();
		review.setTitle("간지 좔좔~~~~~");
		review.setContent("간지가 좔좔 흐르는 책이었어요");
		review.setScore(4.5F);
//		@ManyToOne로 설정된 필드는 직접 값을 넣어줘야 한다.
		review.setMember(member);
		review.setBook(book);
		reviewRepository.save(review);
	}
	
	private Member givenMember() {
		return memberRepository.findByEmail("jang@mbcit.com").get(0);
	}
	
	private Book givenBook(Publisher publisher) {
		Book book = new Book();
		book.setName("간지나는 JPA");
		book.setCategory("springBoot");
//		@ManyToOne로 설정된 필드는 직접 값을 넣어줘야 한다.
		book.setPublisher(publisher);
		return bookRepository.save(book);
	}
	
	private Publisher givenPublisher() {
		Publisher publisher = new Publisher();
		publisher.setName("MBC 출판사");
		return publisherRepository.save(publisher);
	}
	
}












