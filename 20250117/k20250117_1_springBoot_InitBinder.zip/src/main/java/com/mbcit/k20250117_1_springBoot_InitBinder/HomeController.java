package com.mbcit.k20250117_1_springBoot_InitBinder;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
public class HomeController {

	@RequestMapping("/")
	public @ResponseBody String home() {
		log.info("HomeController 클래스의 home() 메소드 실행");
		return "@InitBinder 테스트";
	}
	
	@RequestMapping("/insertForm")
	public String insertForm() {
		log.info("HomeController 클래스의 insertForm() 메소드 실행");
		return "insertForm";
	}
	
	@RequestMapping("/create")
//	@Valid 어노테이션을 사용해서 ContentVO 클래스 객체에 유효성 검증을 하겠다고 표시한다.
//	파라미터로 객체가 넘어오면 spring이 @InitBinder 어노테이션을 붙여서 선언한 메소드의 인수로 지정된
//	WebDataBinder 클래스 객체를 통해서 즉시 유효성을 검사하고 유효성 검사 결과는 BindingResult 인터페이스
//	객체 저장한다.
	public String create(@ModelAttribute("vo") @Valid ContentVO contentVO, BindingResult bindingResult) {
		log.info("HomeController 클래스의 create() 메소드 실행");
		log.info("{}", contentVO);
	
//		일일히 new를 사용하지 않고 @InitBinder 어노테이션을 지정해서 선언한 메소드를 이용해서
//		유효성을 검사할 것이므로 아래 2줄은 주석으로 처리한다.
//		ContentValidator contentValidator = new ContentValidator();
//		contentValidator.validate(contentVO, bindingResult);
		
		String viewpage = "createDone";
		if (bindingResult.hasErrors()) {
			
			if (bindingResult.getFieldError("writer") != null) {
				log.info("writer: {}", bindingResult.getFieldError("writer").getCode());
			}
			if (bindingResult.getFieldError("content") != null) {
				log.info("content: {}", bindingResult.getFieldError("content").getCode());
			}
			
			viewpage = "insertForm";
		}
		
		return viewpage;
	}
	
//	@InitBinder 어노테이션을 지정해서 선언한 메소드는 form의 submit 버튼이 클릭되면 요청을 받아서 실행되는
//	메소드가 시작되기 전에 자동으로 실행된다.
	@InitBinder
	public void initBinder(WebDataBinder binder) {
		log.info("HomeController 클래스의 initBinder() 메소드 실행");
//		메소드의 인수로 지정한 WebDataBinder 클래스 객체에 유효성 검증에 사용할 클래스를 등록한다.
		binder.setValidator(new ContentValidator());
	}
	
}









