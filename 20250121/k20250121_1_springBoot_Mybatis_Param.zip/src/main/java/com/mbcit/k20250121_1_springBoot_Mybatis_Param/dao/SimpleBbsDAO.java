package com.mbcit.k20250121_1_springBoot_Mybatis_Param.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.mbcit.k20250121_1_springBoot_Mybatis_Param.vo.SimpleBbsVO;


@Mapper
public interface SimpleBbsDAO {

//	void insert(SimpleBbsVO simpleBbsVO);
//	방법1
	void insert(String name, String title, String content);
	List<SimpleBbsVO> selectList();
	SimpleBbsVO selectByIdx(int idx);
	void update(SimpleBbsVO simpleBbsVO);
//	void delete(int idx);
//	방법3
	void delete(@Param("id") int idx);
	
}
