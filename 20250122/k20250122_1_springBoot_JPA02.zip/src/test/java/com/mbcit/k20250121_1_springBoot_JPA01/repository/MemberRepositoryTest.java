package com.mbcit.k20250121_1_springBoot_JPA01.repository;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.persistence.Column;

import org.assertj.core.util.Lists;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;

import com.mbcit.k20250121_1_springBoot_JPA01.domain.Gender;
import com.mbcit.k20250121_1_springBoot_JPA01.domain.Member;
import com.mbcit.k20250121_1_springBoot_JPA01.repository.MemberRepository;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@SpringBootTest
class MemberRepositoryTest {

	@Autowired
	private MemberRepository memberRepository;
	
	@Test
	void test() {
//		log.info("memberRepository: {}", memberRepository);
		System.out.println("MemberRepositoryTest 클래스의 test() 메소드 실행");
//		1줄 출력
		log.info("결과: {}", memberRepository.findAll());
//		람다 식을 사용한 여러줄 출력
		memberRepository.findAll().forEach(System.out::println);
	}
	
	@Test
	public void insertAndUpdateTest() {
		System.out.println("MemberRepositoryTest 클래스의 insertAndUpdateTest() 메소드 실행");
		
//		@Column(updatable = false), @Column(insertable = false) 테스트
		System.out.println("@Column(updatable = false), @Column(insertable = false) 테스트");
		
		Member member = new Member();
		member.setName("손오공");
		member.setEmail("son@mbcit.com");
//		member.setNickname("원숭이");
		memberRepository.save(member); // insert
		
		Member member2 = memberRepository.findById(1L).orElse(null);
		member2.setName("저팔계");
		memberRepository.save(member2); // update
		
		memberRepository.findAll().forEach(System.out::println);
	}

	@Test
	public void enumTest() {
		System.out.println("MemberRepositoryTest 클래스의 enumTest() 메소드 실행");
		
		Member member = memberRepository.findById(1L).orElse(null);
//		member.setGender(Gender.MALE);
		memberRepository.save(member);
		memberRepository.findAll().forEach(System.out::println);
		
		Map<String, Object> map = memberRepository.findRecord();
		for (String key : map.keySet()) {
			System.out.println(key + ": " + map.get(key));
		}
	}
	
	@Test
	public void basicMethod() {
		System.out.println("MemberRepositoryTest 클래스의 basicMethod() 메소드 실행");
		
//		전체 데이터 가져오기: findAll()
//		select * from member
		List<Member> members = memberRepository.findAll();
		members.forEach(System.out::println);
		
//		전체 데이터를 정렬해서 가져오기: Sort.by(Direction.정렬방식, "필드이름")
//		select * from member order by name asc
		members = memberRepository.findAll(Sort.by(Direction.ASC, "name")); // 오름차순
		members.forEach(System.out::println);
//		select * from member order by idx desc
		members = memberRepository.findAll(Sort.by(Direction.DESC, "id")); // 내림차순
		members.forEach(System.out::println);
		
//		지정된 id에 해당되는 단일 데이터 가져오기: findById()
//		select * from member where id = 1
//		Optional<Member> member = memberRepository.findById(1L);
		Member member = memberRepository.findById(10L).orElse(null);
		System.out.println(member);
		
//		전체 데이터에서 지정된 id에 해당되는 모든 데이터 가져오기: findAllById()
//		select * from member where id = 1 or id = 3 or id = 4
//		List<Long> ids = new ArrayList<>();
//		ids.add(1L);
//		ids.add(3L);
//		ids.add(4L);
//		members = memberRepository.findAllById(ids);
		
//		org.assertj.core.util.Lists
		members = memberRepository.findAllById(Lists.newArrayList(1L, 3L, 4L));
		members.forEach(System.out::println);
		
//		단일 데이터 저장하기: save()
//		IDENTITY
//		insert into member (name, emal) values ('손오공1', 'son1@mbcit.com')
//		SEQUENCE
//		insert into member (id, name, emal) values (nextval('member_id_seq'), '손오공1', 'son1@mbcit.com')
		memberRepository.save(new Member("손오공1", "son1@mbcit.com"));
		memberRepository.save(new Member("손오공2", "son2@mbcit.com"));
		memberRepository.flush(); // 즉시 적용
		memberRepository.saveAndFlush(new Member("손오공3", "son3@mbcit.com")); // 즉시 적용
		members = memberRepository.findAll();
		members.forEach(System.out::println);
		
//		일괄 데이터 저장하기: saveAll()
		Member member1 = new Member("저팔계", "jeo@mbcit.com");
		Member member2 = new Member("사오정", "sa@mbcit.com");
		Member member3 = new Member("오로라공주", "aurora@mbcit.com");
		memberRepository.saveAll(Lists.newArrayList(member1, member2, member3));
		members = memberRepository.findAll();
		members.forEach(System.out::println);
		
//		저장된 데이터 개수 얻어오기: count()
//		select count(*) from member
		long count = memberRepository.count();
		System.out.println(count);
		
//		지정된 id에 해당되는 데이터 존재 여부 얻어오기: existsById()
		boolean exists = memberRepository.existsById(1L);
		System.out.println(exists);
		System.out.println(exists ? "있음" : "없음");
		
//		org.springframework.data.domain
//		페이징 => Page 인터페이스
//		PageRequest.of(얻어올 페이지 번호, 페이지 크기, [정렬 방식])
//		Page<Member> page = memberRepository.findAll(PageRequest.of(2, 5));
//		Page<Member> page = memberRepository.findAll(PageRequest.of(2, 5, Sort.by(Direction.ASC, "name")));
		Page<Member> page = memberRepository.findAll(PageRequest.of(2, 5, Sort.by(Direction.DESC, "id")));
		
		System.out.println(page); // 페이징 객체 출력
		page.getContent().forEach(System.out::println); // 현재 페이지의 데이터를 얻어온다.
		System.out.println(page.getTotalElements()); // 전체 데이터의 개수를 얻어온다.
		System.out.println(page.getNumberOfElements()); // 현재 페이지의 데이터 개수를 얻어온다.
		System.out.println(page.getSort()); // 정렬 여부를 얻어온다.
		System.out.println(page.getSize()); // 1페이지의 크기를 얻어온다.
		
//		단일 데이터 삭제하기: delete(), deleteById()
//		delete from member where id = 1
		memberRepository.delete(memberRepository.findById(1L).orElse(null));
		memberRepository.deleteById(4L);
		members = memberRepository.findAll();
		members.forEach(System.out::println);
		
//		전체 데이터에서 지정된 id에 해당되는 데이터만 삭제하기: deleteAll()
//		delete from member where id = 6 or id = 7
		memberRepository.deleteAll(memberRepository.findAllById(Lists.newArrayList(6L, 7L)));
		members = memberRepository.findAll();
		members.forEach(System.out::println);
		
//		전체 데이터 삭제하기: deleteAll()
//		delete from member
		memberRepository.deleteAll();
		members = memberRepository.findAll();
		members.forEach(System.out::println);
		
//		단일 데이터 수정하기: save()
//		save() 메소드가 테이블에 없는 id를 가지고 실행되면 insert sql 명령이 실행되고 있는 id를 가지고
//		실행되면 update sql 명령이 실행된다.
//		insert into member (id, name, emal) values (nextval('member_id_seq'), '유비', 'yoo@mbcit.com')
		memberRepository.save(new Member("유비", "yoo@mbcit.com"));
		members = memberRepository.findAll();
		members.forEach(System.out::println);
		
//		update member set name = '관우', email = 'kwan@mbcit.com' where id = 13
		member = new Member();
		member.setId(13L);
		member.setName("관우");
		member.setEmail("kwan@mbcit.com");
		memberRepository.save(member);
		members = memberRepository.findAll();
		members.forEach(System.out::println);
	}
	
}























