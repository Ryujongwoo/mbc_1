import React, { useState } from "react";

function MyForm4() {

  // 하나의 상태 객체 대신 성, 이름, 이메일을 별도의 상태로 구현한다.
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [email, setEmail] = useState('');
  
  const submitHandler = event => {
    event.preventDefault();
    alert(`Hello ${firstName}${lastName} ${email}`);
  }

  return (
    <div align='center'>
      <h1>MyForm4</h1>
      <form onSubmit={submitHandler}>
        <label>
          firstname: <input type="text" name="firstName" value={firstName} 
            onChange={event => setFirstName(event.target.value)}/>
        </label><br/>
        <label>
          lastname: <input type="text" name="lastName" value={lastName}
            onChange={event => setLastName(event.target.value)}/>
        </label><br/>
        <label>
          email: <input type="text" name="email" value={email}
            onChange={event => setEmail(event.target.value)}/>
        </label><br/>
        <input type="submit" value="눌러봐" />
      </form>
    </div>
  )
}

export default MyForm4;
