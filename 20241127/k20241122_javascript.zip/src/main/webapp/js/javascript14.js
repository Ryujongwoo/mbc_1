const slime = {
	name: '슬라임'
}
console.log(slime);

const cuteSlime = {
	name: '슬라임',
	attribute: 'cute'
}
console.log(cuteSlime);

const purpleCuteSlime = {
	name: '슬라임',
	attribute: 'cute',
	color: 'purple'
}
console.log(purpleCuteSlime);
console.log('1. =================================');

//	... => spread 연산자 => ES6에서 추가 => 객체의 내용을 다른 객체에 퍼트린다. 확산키킨다. 복사한다.

const slime2 = {
	name: '슬라임'
}
console.log(slime2);

const cuteSlime2 = {
	...slime2, // slime2 객체의 내용을 cuteSlime2 객체 내부에 확산시킨다.
	attribute: 'cute'
}
console.log(cuteSlime2);

const purpleCuteSlime2 = {
	...cuteSlime2, // cuteSlime2 객체의 내용을 purpleCuteSlime2 객체 내부에 확산시킨다.
	color: 'purple'
}
console.log(purpleCuteSlime2);
console.log('2. =================================');

//	spread 연산자는 배열에도 사용할 수 있다.
const animals = ['개', '고양이', '토오끼'];
console.log(animals);
const animals2 = animals.concat('비둘기');
console.log(animals2);
const animals3 = [...animals, '닭둘기'];
console.log(animals3);
console.log('3. =================================');

