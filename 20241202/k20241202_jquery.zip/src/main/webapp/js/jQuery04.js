//	input 태그의 type 속성별 선택자
//	:button: type 속성 값이 'button'인 모든 요소를 선택한다.
//	:checkbox: type 속성 값이 'checkbox'인 모든 요소를 선택한다.
//	:file: type 속성 값이 'file'인 모든 요소를 선택한다.
//	:image: type 속성 값이 'image'인 모든 요소를 선택한다.
//	:password: type 속성 값이 'password'인 모든 요소를 선택한다.
//	:radio: type 속성 값이 'radio'인 모든 요소를 선택한다.
//	:reset: type 속성 값이 'reset'인 모든 요소를 선택한다.
//	:submit: type 속성 값이 'submit'인 모든 요소를 선택한다.
//	:text: type 속성 값이 'text'인 모든 요소를 선택한다.

//	input 태그의 property별 선택자
//	:checked: type 속성 값이 'checkbox' 또는 'radio'인 요소 체크된 모든 요소를 선택한다.
//	:selected: select 태그의 option 요소 중에서 선택된 모든 요소를 선택한다.
//	:focus: 현재 포커스를 가지고 있는 요소를 선택한다.
//	:disabled: 비활성화 되어있는 모든 요수를 선택한다.
//	:enabled: 활성화 되어있는 모든 요수를 선택한다.

function choice1() {
	let names = ['홍길동', '임꺽정'];
	
//	javascript
//	let texts = document.getElementsByTagName('input');
//	let texts = document.querySelectorAll('input');
//	let texts = document.querySelectorAll('[type="text"]');
//	console.log(texts.length);
//	for (let i = 0; i < names.length; i++) {
//		texts[i].value = names[i];
//	}

//	jQuery
//	let texts = $('input'); // input 태그 전체를 얻어온다.
//	let texts = $('input[type=text]'); // input 태그 중에서 type 속성의 속성 값이 정확히 text인 요소만 선택한다.
	let texts = $('input:text'); // input 태그 중에서 type 속성이 text인 요소만 선택한다.
//	console.log(texts.length);
//	console.log(typeof texts);
//	console.log(texts);

//	javascript를 value 속성을 사용해서 '~~~~~.value' 형태로 값을 얻어오고 '~~~~~.value = 값' 형태로 넣어준다.
//	jQuery는 value 속성을 사용하지 않고 val() 함수를 사용해서 '~~~~~.val()' 형태로 값을 얻어오고 '~~~~~.val(값)'
//	형태로 넣어준다.

	let i = 0;
	for (let text of texts) {
		text.value = names[i++];
		// form 태그 요소를 선택할 때는 $('input:text')를 사용해서 jQuery 방식으로 선택했지만 texts라는 배열을
		// 사용하기 때문에 val() 함수를 사용할 수 없다. => val() 함수는 $()로 선택된 요소에만 사용할 수 있다.
		// text.val(names[i++]); // 에러
	}
	
//	변수나 배열 요소에 값을 얻어오거나 넣어주려면 value 속성을 사용하고 '$()'와 같이 jQuery로 선택된 요소에 값을
//	넣어주거나 얻어오려면 val() 함수를 사용한다.
	let doc1 = document.querySelectorAll('[type="text"]')[0].value;
	console.log(doc1);
	let doc2 = $('input:text:eq(1)').val();
	console.log(doc2);
	let doc3 = $('input:text:eq(1)');
	console.log(doc3.val());
	
	document.querySelectorAll('[type="text"]')[0].value = '손오공';
	$('input:text:eq(1)').val('저팔계');
}

function choice2() {
//	javascript
//	let radio = document.getElementsByTagName('input')[3];
//	let radio = document.querySelectorAll('input')[3];
//	let radio = document.querySelectorAll('[type="radio"]')[0];
//	console.log(radio);
//	document.getElementById('result').innerHTML = '<h1>' + radio.value + '</h1>';
//	document.querySelector('#result').innerHTML = '<h1>' + radio.value + '</h1>';
//	document.getElementsByTagName('div')[0].innerHTML = `<h1>${radio.value}</h1>`;
//	document.querySelectorAll('div')[0].innerHTML = `<h1>${radio.value}</h1>`;

//	jQuery
//	let radio = $('input:eq(3)')
//	let radio = $('input[type=radio]:eq(0)');
	let radio = $('input:radio:eq(0)');
//	console.log(radio);

//	javascript는 div 태그나 span 태그 내부에 텍스트를 넣어줄때 innerText나 innerHTML을 사용한다.
//	jQuery는 innerText 대신 text() 함수를 innerHTML 대신 html() 함수를 사용한다.
//	$('#result').text('<h1>' + radio.val() + '</h1>'); // text() 함수는 태그가 적용되지 않는다.
	$('div:eq(0)').html(`<h1>${radio.val()}</h1>`); // html() 함수는 태그가 적용된다.
}

function choice3() {
	let checkbox = $('input:checkbox:eq(0)');
	$('div:eq(0)').html(checkbox.val());
}

//	onload 이벤트
//	$(document).ready(function () {
//	$().ready(function () {
//	$(function () {
$(() => {
//	javascript
	/*
//	let select = document.getElementsByTagName('select')[0];
	let select = document.querySelectorAll('select')[0];
//	console.log(select);

//	이벤트를연결할객체.이벤트 = function () { }
//	이벤트를연결할객체.이벤트 = () => { }
	select.onchange = () => {
		// console.log(select.selectedIndex); // 몇 번째 option이 선택되었나 얻어온다.
		// console.log(select.options); // option 목록을 배열 형태로 얻어온다.
		// console.log(select.options[select.selectedIndex]); // 선택된 option을 얻어온다.
		console.log(select.options[select.selectedIndex].value); // 선택된 option의 값을 얻어온다.
		// document.getElementsByTagName('input')[0].value = select.options[select.selectedIndex].value;
		document.querySelectorAll('[type="text"]')[0].value = select.options[select.selectedIndex].value;
	}
	*/
	
//	jQuery
	let select = $('select:eq(0)');
//	console.log(select);

//	javascript는 onclick, onchange와 같이 이벤트 이름이 'on'으로 시작하지만 jQuery는 이벤트 함수 이름이
//	'on'으로 시작하지 않는다. => click(), change()

//	이벤트를연결할객체.이벤트함수(function () { });
//	select.change(function () {
//	이벤트를연결할객체.이벤트함수(() => { });
	select.change(() => {
		// console.log('select 태그에서 change 이벤트가 실행됨');
		// 모든 select 태그 중에서 0번째 인덱스의 select 태그를 선택하고 그 자식 중에서 option 태그를 선택한다.
		// console.log($('select:eq(0) > option'));
		// 모든 select 태그 중에서 0번째 인덱스의 select 태그를 선택하고 그 자식 중에서 선택된 option 태그를 선택한다.
		// console.log($('select:eq(0) > option:selected'));
		console.log($('select:eq(0) > option:selected').val());
		// $('input:eq(0)').val($('select:eq(0) > option:selected').val());
		// $('input[type=text]:eq(0)').val($('select:eq(0) > option:selected').val());
		$('input:text:eq(0)').val($('select:eq(0) > option:selected').val());
	});
	
//	모든 input 태그 중에서 name 속성의 속성 값이 gender인 모든 요소를 선택한다.
//	console.log($('input[name=gender]'));
	$('input[name=gender]').click(() => {
		let check = $('input[name=gender]:checked').val();
		// console.log(check);
		$('input:text:eq(1)').val(check);
	});
});

