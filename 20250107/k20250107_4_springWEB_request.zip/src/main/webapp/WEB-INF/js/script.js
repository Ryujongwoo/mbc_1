function hello() {
	alert('헬로~~~~~')
}