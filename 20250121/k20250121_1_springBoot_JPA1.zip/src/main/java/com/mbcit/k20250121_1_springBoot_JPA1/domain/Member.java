package com.mbcit.k20250121_1_springBoot_JPA1.domain;

import java.time.LocalDateTime;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@NoArgsConstructor // 기본 생성자
@AllArgsConstructor // 모든 멤버를 초기화 하는 생성자
@RequiredArgsConstructor // @NonNull 어노테이션을 붙여준 멤버만 초기화 하는 생성자
//	@Getter // 모든 멤버의 getter 메소드
//	@Setter // 모든 멤버의 setter 메소드
//	@ToString // toString() 메소드
//	@EqualsAndHashCode // equals(), hashCode() 메소드
@Data // @Getter, @Setter, @ToString, @EqualsAndHashCode 어노테이션을 모두 실행한다.
@Builder // 생성자를 대신해서 객체를 생성할 수 있다.

//	클래스에 @Entity 어노테이션을 붙여주면 JPA가 자동으로 테이블을 만들어준다.
@Entity
public class Member {

//	필드에 @Id 어노테이션을 붙여주면 기본키 필드로 선언한다.
	@Id
//	@GeneratedValue 어노테이션으로 기본키 필드 값을 자동으로 증가시키는 방법을 지정한다.
//	GenerationType.IDENTITY는 AUTO_INCREMENT를 사용해서 자동으로 1씩 증가하는 값이 입력된다.
//	@GeneratedValue(strategy = GenerationType.IDENTITY)
//	GenerationType.SEQUENCE는 SEQUENCE를 사용해서 자동으로 1씩 증가하는 값이 입력된다.
//	@GeneratedValue(strategy = GenerationType.SEQUENCE)
//	GenerationType.TABLE는 키 생성 전용 테이블을 생성해서 데이터베이스 시퀀스 처럼 사용한다.
//	@GeneratedValue(strategy = GenerationType.TABLE)
//	GenerationType.AUTO는 데이터베이스에 따라 위 3가지 방법 중에서 자동으로 하나를 선택해서 사용한다.
//	@GeneratedValue(strategy = GenerationType.AUTO) // 기본값
	@GeneratedValue
	private Long id;
	
	
	@NonNull // null 값을 허용하지 않는다.
	private String name;
	@NonNull
	private String email;
	private LocalDateTime createDate;
	private LocalDateTime updateDate;
	
}










