package com.mbcit.k20250116_2_springBoot_JspUse;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class K202501162SpringBootJspUseApplication {

	public static void main(String[] args) {
		SpringApplication.run(K202501162SpringBootJspUseApplication.class, args);
	}

}
