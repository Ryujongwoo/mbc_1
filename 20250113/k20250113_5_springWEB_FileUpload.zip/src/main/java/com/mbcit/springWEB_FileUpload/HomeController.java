package com.mbcit.springWEB_FileUpload;

import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

@Controller
public class HomeController {
	
	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);
	
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Locale locale, Model model) {
		logger.info("Welcome home! The client locale is {}.", locale);
		
		Date date = new Date();
		DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG, locale);
		
		String formattedDate = dateFormat.format(date);
		
		model.addAttribute("serverTime", formattedDate );
		
		return "home";
	}
	
	@RequestMapping("/fileUploadForm")
	public String fileUploadForm(HttpServletRequest request, Model model) {
		logger.info("HomeController 클래스의 fileUploadForm() 메소드 실행");
		return "fileUploadForm";
	}
	
	@RequestMapping("/fileUploadResult")
//	form의 enctype 속성 값이 multipart/form-data일 경우 HttpServletRequest 인터페이스 객체가 아니라
//	MultipartHttpServletRequest 인터페이스 객체로 받는다.
	public String fileUploadResult(MultipartHttpServletRequest request, Model model) {
		logger.info("HomeController 클래스의 fileUploadResult() 메소드 실행");
		
		// 업로드하는 파일이 저장될 폴더를 지정한다.
		// spring에서 폴더와 폴다, 폴더와 파일을 구분하는 구분자("\")를 사용할 때 "\"를 1개만 입력하면
		// escape sequence(\b, \t, \n, \f, \r, \", \', \\)로 지정되지 않은 문자가 "\"  뒤에 위치하면 에러가
		// 발생되므로 "\\"와 같이 입력하거나 File.separator를 사용한다.
		// String uploadDir = "D:\\upload";
		// logger.info("{}", File.separator);
		// String uploadDir = "D:" + File.separator + "upload";
		// logger.info("{}", uploadDir);
		File dir = new File("D:\\upload");
		
		// 업로드 폴더가 존재하지 않을 경우 업로드 폴더를 만든다.
		// exists() 메소드는 File 클래스 객체가 존재하면 true, 존재하지 않으면 false를 리턴한다.
		// logger.info("{}", dir.exists());
		// File 클래스 객체 dir에 지정된 폴더가 존재하지 않을 경우 mkdirs() 메소드로 폴더를 만든다.
		if (!dir.exists()) {
			dir.mkdirs();
		}
		
		// 업로드되는 파일 정보를 수집한다.(2개: file1, file2)
		Iterator<String> iterator = request.getFileNames();
		ArrayList<String> fileList = new ArrayList<String>();
		
		// 업로드 되는 파일의 있는 동안 반복하며 업로드 한다.
		// hasNext() 메소드는 Iterator 인터페이스 객체에 다음에 읽을 데이터가 있으면 true, 없으면
		// false를 리턴한다.
		while (iterator.hasNext()) {
			// next() 메소드는 Iterator 인터페이스 객체에 다음에 읽을 데이터 얻어온다.
			String uploadFilename = iterator.next();
			// logger.info("uploadFilename: {}", uploadFilename);
			// getFile() 메소드로 업로드 되는 파일을 얻어온다.
			MultipartFile multipartFile = request.getFile(uploadFilename);
			// getOriginalFilename() 메소드로 업로드 되는 실제 파일 이름을 얻어온다.
			String originalFilename = multipartFile.getOriginalFilename();
			// logger.info("originalFilename: {}", originalFilename);
			
			if (originalFilename != null && originalFilename.trim().length() != 0) {
				// MultipartFile 인터페이스 객체에서 transferTo() 메소드로 File 객체를 만들어 업로드 한다.
				try {
					String uploadName = dir + File.separator + originalFilename + System.currentTimeMillis();
					multipartFile.transferTo(new File(uploadName));
					fileList.add("원본 파일명: " + originalFilename + ", 업로드된 파일명: " + uploadName);
				} catch (Exception e) {
					e.printStackTrace();
					logger.info("파일 업로드 중 에러 발생");
					fileList.add("파일 업로드 중 에러 발생");
				}
			}
		}
		
		// 업로드된 파일 목록을 viewpage로 넘겨주기 위해서 Model 인터페이스 객체에 저장한다.
		model.addAttribute("fileList", fileList);
		return "fileUploadResult";
	}
	
}























