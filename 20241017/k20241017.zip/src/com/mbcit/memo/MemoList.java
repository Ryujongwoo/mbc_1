package com.mbcit.memo;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Scanner;
import java.util.StringTokenizer;

public class MemoList {

	private ArrayList<MemoVO> memoList = new ArrayList<MemoVO>();

	public ArrayList<MemoVO> getMemoList() {
		return memoList;
	}
	public void setMemoList(ArrayList<MemoVO> memoList) {
		this.memoList = memoList;
	}
	
	@Override
	public String toString() {
		String str = "";
		
		if (memoList.size() == 0) {
			str += "저장된 글이 없습니다.\n";
		} else {
			str += "총 " + memoList.size() + "개의 저장된 글이 있습니다.\n";
			for (int i = memoList.size() - 1; i >= 0; i--) {
				str += memoList.get(i) + "\n";
			}
		}
		
		return str;
	}
	
	public void addMemo(MemoVO vo) {
		System.out.println("MemoList 클래스의 addMemo() 메소드 실행");
		memoList.add(vo);
	}
	
	public MemoVO selectMemo(int idx) {
		System.out.println("MemoList 클래스의 selectMemo() 메소드 실행");
		try {
			return memoList.get(idx - 1);
		} catch (IndexOutOfBoundsException e) {
			return null;
		}
	}
	
	public void removeMemo(int idx) {
		System.out.println("MemoList 클래스의 removeMemo() 메소드 실행");
		memoList.remove(idx - 1);
		for (int i = 0; i < memoList.size(); i++) {
			memoList.get(i).setIdx(i + 1);
		}
		MemoVO.count = memoList.size();
	}
	
	public void updateMemo(int idx, String memo) {
		System.out.println("MemoList 클래스의 updateMemo() 메소드 실행");
		memoList.get(idx - 1).setMemo(memo);
	}
	
//	MemoMain 클래스에서 호출되는 저장할 텍스트 파일의 이름을 넘겨받아 memoList라는 ArrayList에
//	저장된 내용을 텍스트 파일에 저장하는 메소드
	public void writeMemo(String filename) {
		System.out.println("MemoList 클래스의 writeMemo() 메소드 실행");
		PrintWriter printWriter = null;
		
		try {
//			텍스트 파일이 저장될 경로와 텍스트 파일의 이름을 연결한다.
//			String filepath = "./src/com/mbcit/memo/" + filename + ".txt";
			String filepath = String.format("./src/com/mbcit/memo/%s.txt", filename);
//			System.out.println(filepath);
			printWriter = new PrintWriter(filepath);
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss");
			
//			memoList라는 ArrayList에 저장된 데이터 1건을 공백으로 구분해서 텍스트 파일에 1줄로
//			연결해서 저장한다.
			/*
//			일반 for
			for (int i = 0; i < memoList.size(); i++) {
//				System.out.println(memoList.get(i));
				MemoVO vo = memoList.get(i);
				String str = vo.getIdx() + " ";
				str += vo.getName().replace(" ", "`") + " ";
				str += vo.getPassword() + " ";
				str += vo.getMemo().replace(" ", "`") + " ";
				str += sdf.format(vo.getWriteDate());
//				System.out.println(str);
				printWriter.write(str + "\r\n");
			}*/
//			향상된 for
			for (MemoVO vo : memoList) {
				String str = String.format("%d %s %s %s %s", vo.getIdx(), vo.getName().replace(" ", "`"), 
						vo.getPassword(), vo.getMemo().replace(" ", "`"), sdf.format(vo.getWriteDate()));
				printWriter.write(str + "\r\n");
			}
			System.out.println(filename + ".txt 파일로 저장완료!!!");
		} catch (FileNotFoundException e) {
			System.out.println("파일이 없거나 경로 지정이 올바르지 않습니다.");
			System.out.println(filename + ".txt 파일로 저장실패!!!");
		} finally {
			if (printWriter != null) {
				printWriter.close();
			}
		}
	}
	
//	MemoMain 클래스에서 호출되는 읽어올 텍스트 파일의 이름을 넘겨받아 텍스트 파일에서 읽어온
//	내용을 memoList라는 ArrayList에 저장하는 메소드
	public void readMemo(String filename) {
		System.out.println("MemoList 클래스의 readMemo() 메소드 실행");
		Scanner scanner = null;
		
		try {
//			텍스트 파일이 저장될 경로와 텍스트 파일의 이름을 연결한다.
			String filepath = String.format("./src/com/mbcit/memo/%s.txt", filename);
			scanner = new Scanner(new File(filepath));
			
//			텍스트 파일에 저장된 데이터를 끝까지 읽어서 memoList라는 ArrayList에 저장한다.
			while (scanner.hasNextLine()) {
//				텍스트 파일에서 1줄을 읽어들인다.
				String str = scanner.nextLine().trim();
//				System.out.println(str);
				
//				읽어들인 데이터를 공백을 경계로 읽어서 각각의 변수에 저장한다.
				Scanner scan = new Scanner(str);
				int idx = scan.nextInt();
				String name = scan.next().replace("`", " ");
				String password = scan.next();
				String memo = scan.next().replace("`", " ");
				String temp = scan.nextLine().trim();
//				System.out.println(temp);
				
//				텍스트 파일에서 읽어들인 문자열로 변환되서 저장된 날짜 데이터를 Date 클래스를 이용해서
//				날짜 데이터로 변환한다.
				
//				substring() 메소드 사용
//				int year = Integer.parseInt(temp.substring(0, 4)) - 1900;
//				int month = Integer.parseInt(temp.substring(5, 7)) - 1;
//				int day = Integer.parseInt(temp.substring(8, 10));
//				int hour = Integer.parseInt(temp.substring(11, 13));
//				int minute = Integer.parseInt(temp.substring(14, 16));
//				int second = Integer.parseInt(temp.substring(17));
//				Date writeDate = new Date(year, month, day, hour, minute, second);
//				System.out.println(writeDate);
				
//				split() 메소드 사용
//				split() 메소드의 구분자를 "."을 지정하면 제대로 동작하지 않는다.
//				split() 메소드의 구분자로 "."을 사용해야한다면 "\\." 또는 "[.]"로 지정한다.
//				String[] date = temp.split("\\.");
//				String[] date = temp.split("[.]");
//				System.out.println(Arrays.toString(date));
//				int year = Integer.parseInt(date[0]) - 1900;
//				int month = Integer.parseInt(date[1]) - 1;
//				int day = Integer.parseInt(date[2]);
//				int hour = Integer.parseInt(date[3]);
//				int minute = Integer.parseInt(date[4]);
//				int second = Integer.parseInt(date[5]);
//				Date writeDate = new Date(year, month, day, hour, minute, second);
//				System.out.println(writeDate);
				
//				StringTokenizer 클래스 사용
//				StringTokenizer st = new StringTokenizer(temp, ".");
//				int year = Integer.parseInt(st.nextToken()) - 1900;
//				int month = Integer.parseInt(st.nextToken()) - 1;
//				int day = Integer.parseInt(st.nextToken());
//				int hour = Integer.parseInt(st.nextToken());
//				int minute = Integer.parseInt(st.nextToken());
//				int second = Integer.parseInt(st.nextToken());
//				Date writeDate = new Date(year, month, day, hour, minute, second);
//				System.out.println(writeDate);
				
				String date1 = temp.substring(0, 10);
				String date2 = temp.substring(11);
				String date3 = date1.replace(".", "/") + " " + date2.replace(".", ":");
				Date writeDate = new Date(date3);
//				System.out.println(date1);
//				System.out.println(date2);
//				System.out.println(date3);
//				System.out.println(writeDate);
				
//				읽어들인 데이터를 MemoVO 클래스 객체로 만든다.
				
//				기본 생성자
//				MemoVO vo = new MemoVO();
//				vo.setIdx(idx);
//				vo.setName(name);
//				vo.setPassword(password);
//				vo.setMemo(memo);
//				vo.setWriteDate(writeDate);
				
//				MemoVO(String name, String password, String memo) 생성자
//				MemoVO vo = new MemoVO(name, password, memo);
//				vo.setIdx(idx);
//				vo.setWriteDate(writeDate);
//				System.out.println(vo);
				
//				MemoVO(int idx, String name, String password, String memo, Date writeDate) 생성자
				MemoVO vo = new MemoVO(idx, name, password, memo, writeDate);
//				System.out.println(vo);
				
//				MemoVO 클래스 객체에 저장된 텍스트 파일에서 읽어온 데이터를 ArrayList에 저장한다.
				memoList.add(vo);
			}
			
			System.out.println(filename + ".txt 파일로 읽기완료!!!");
		} catch (FileNotFoundException e) {
			System.out.println("파일이 없거나 경로 지정이 올바르지 않습니다.");
			System.out.println(filename + ".txt 파일에서 읽기실패!!!");
		}
	}
	
}
















