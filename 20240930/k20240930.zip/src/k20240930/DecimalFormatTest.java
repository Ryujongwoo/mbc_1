package k20240930;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.Locale;

public class DecimalFormatTest {

	public static void main(String[] args) {
		
		NumberFormat nf1 = NumberFormat.getNumberInstance(); // 천 단위 쉼표
		System.out.println(nf1.format(1000));
		NumberFormat nf2 = NumberFormat.getCurrencyInstance(Locale.KOREA); // 통화 기호
		System.out.println(nf2.format(1000));
		NumberFormat nf3 = NumberFormat.getPercentInstance(); // 백분율
		System.out.println(nf3.format(1000));
		
		DecimalFormat df1 = new DecimalFormat("#,##0"); // 천 단위 쉼표
		System.out.println(df1.format(1000000));
		DecimalFormat df2 = new DecimalFormat("€#,##0"); // 통화 기호
		System.out.println(df2.format(1000000));
		DecimalFormat df3 = new DecimalFormat("#,##0%"); // 백분율
		System.out.println(df3.format(1000000));
		DecimalFormat df4 = new DecimalFormat("#,##0.00"); // 소수점 아래 데이터 출력
		System.out.println(df4.format(1000000));
		DecimalFormat df5 = new DecimalFormat("#,##0원"); // 소수점 아래 데이터 출력
		System.out.println(df5.format(1000000));
		
	}
	
}
