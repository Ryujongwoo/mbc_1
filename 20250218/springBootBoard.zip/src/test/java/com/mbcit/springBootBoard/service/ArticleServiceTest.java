package com.mbcit.springBootBoard.service;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.mbcit.springBootBoard.dto.ArticleForm;
import com.mbcit.springBootBoard.entity.Article;

import lombok.extern.slf4j.Slf4j;

//	@SpringBootTest 어노테이션을 붙여서 springBoot와 연동한 통합 테스를 수행한다.
@SpringBootTest
@Slf4j
class ArticleServiceTest {

	@Autowired
	private ArticleService articleService;
	
//	article 테이블 전체 글 목록 조회 테스트
	@Test
	void index_테스트는_메소드_이름을_한글로_해도_상관없다() {
//		예상
//		index() 메소드가 실행되었을 때 예상되는 결과를 만든다.
		List<Article> expected = new ArrayList();
		expected.add(new Article(4L, "일지매", "4등 입니다."));
		expected.add(new Article(3L, "장길산", "3등 입니다."));
		expected.add(new Article(2L, "임꺽정", "2등 입니다."));
		expected.add(new Article(1L, "홍길동", "1등 입니다."));
		log.info("expected: " + expected);
//		실제
//		index() 메소드가 실제로 실행되었을 때 결과를 얻어온다.
		List<Article> actual = articleService.index();
		log.info("actual: " + actual);
//		비교
//		예상되는 결과와 실제로 실행되었을 때 결과를 비교한다.
		assertEquals(expected.toString(), actual.toString());
	}

//	article 테이블 전체 특정 글 조회 테스트 => 성공시
	@Test
	void show_성공시_존재하는_id가_입력된_경우() {
//		예상
		Article expected = new Article(1L, "홍길동", "1등 입니다.");
//		실제
		Article actual = articleService.show(1L);
//		비교
		assertEquals(expected.toString(), actual.toString());
	}
	
//	article 테이블 전체 특정 글 조회 테스트 => 실패시
	@Test
	void show_실패시_존재하지_않는_id가_입력된_경우() {
//		예상
		Article expected = null;
//		실제
		Article actual = articleService.show(5L);
//		비교
		assertEquals(expected, actual);
	}

//	article 테이블 글 저장 테스트 => 성공시
	@Test
//	여러 테스트를 한꺼번에 실행할 경우 이전 테스트 결과가 다음 테스트 결과에 영향을 미치지 않게 하려면
//	@Transactional 어노테이션을 붙여서 테스트 종료 후 변경된 데이터를 rollback 처리한다.
	@Transactional
	void createArticle_성공시_id가_없는_글_저장() {
		String title = "손오공";
		String content = "5등 입니다.";
//		예상
		Article expected = new Article(5L, title, content);
//		실제
		Article actual = articleService.createArticle(new ArticleForm(null, title, content));
//		비교
		assertEquals(expected.toString(), actual.toString());
	}
	
//	article 테이블 글 저장 테스트 => 실패시
	@Test
	@Transactional
	void createArticle_실패시_id가_있는_글_저장() {
		String title = "손오공";
		String content = "5등 입니다.";
//		예상
		Article expected = null;
//		실제
		Article actual = articleService.createArticle(new ArticleForm(5L, title, content));
//		비교
		assertEquals(expected, actual);
	}

//	article 테이블 글 수정 테스트 => 성공시
	@Test
	@Transactional
	void update_성공시_존재하는_id와_title_content가_있는_경우() {
		Long id = 3L;
		String title = "손오공";
		String content = "5등 입니다.";
//		예상
		Article expected = new Article(3L, title, content);
//		실제
		Article actual = articleService.update(id, new ArticleForm(id, title, content));
//		비교
		assertEquals(expected.toString(), actual.toString());
	}
	
	@Test
	@Transactional
	void update_성공시_존재하는_id와_title만_있는_경우() {
		Long id = 3L;
		String title = "손오공";
		String content = null;
//		예상
		Article expected = new Article(3L, title, "3등 입니다.");
//		실제
		Article actual = articleService.update(id, new ArticleForm(id, title, content));
//		비교
		assertEquals(expected.toString(), actual.toString());
	}
	
	@Test
	@Transactional
	void update_성공시_존재하는_id와_content만_있는_경우() {
		Long id = 3L;
		String title = null;
		String content = "5등 입니다.";
//		예상
		Article expected = new Article(3L, "장길산", content);
//		실제
		Article actual = articleService.update(id, new ArticleForm(id, title, content));
//		비교
		assertEquals(expected.toString(), actual.toString());
	}

//	article 테이블 글 수정 테스트 => 실패시
	@Test
	@Transactional
	void update_실패시_존재하지_않는_id가_있는_경우() {
		Long id = 5L;
		String title = "손오공";
		String content = "5등 입니다.";
//		예상
		Article expected = null;
//		실제
		Article actual = articleService.update(id, new ArticleForm(id, title, content));
//		비교
		assertEquals(expected, actual);
	}
	
	@Test
	@Transactional
	void update_실패시_id가_다를_경우() {
		Long id = 5L;
		String title = "손오공";
		String content = "5등 입니다.";
//		예상
		Article expected = null;
//		실제
		Article actual = articleService.update(4L, new ArticleForm(id, title, content));
//		비교
		assertEquals(expected, actual);
	}
	
	@Test
	@Transactional
	void update_실패시_id만_존재하고_title과_content가_없을_경우() {
		Long id = 2L;
		String title = null;
		String content = null;
//		예상
		Article expected = null;
//		실제
		Article actual = articleService.update(id, new ArticleForm(id, title, content));
//		비교
		assertEquals(expected, actual);
	}
	
//	article 테이블 글 삭제 테스트 => 성공시
	@Test
	void delete_성공시_존재하는_id() {
		Long id = 2L;
		String title = "임꺽정";
		String content = "2등 입니다.";
//		예상
		Article expected = new Article(id, title, content);
//		실제
		Article actual = articleService.delete(id);
//		비교
		assertEquals(expected.toString(), actual.toString());
	}
	
//	article 테이블 글 삭제 테스트 => 실패시
	@Test
	void delete_실패시_존재하지_않는_id() {
		Long id = 5L;
		String title = "임꺽정";
		String content = "2등 입니다.";
//		예상
		Article expected = null;
//		실제
		Article actual = articleService.delete(id);
//		비교
		assertEquals(expected, actual);
	}

}









