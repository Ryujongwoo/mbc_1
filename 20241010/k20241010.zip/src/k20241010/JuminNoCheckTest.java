package k20241010;

import java.util.Scanner;

public class JuminNoCheckTest {

	public static void main(String[] args) {
		
//		주민등록번호 13자리를 "-"없이 입력받아 성별 판단하기
		Scanner scanner = new Scanner(System.in);
//		아기공룡 둘리 주민등록번호 => 8304221185600
		System.out.print("주민등록번호 13자리를 '-'없이 입력하세요: ");
		
//		long jumin = scanner.nextLong();
//		System.out.println(jumin);
//		System.out.println(jumin / 1000000);
//		System.out.println(jumin / 1000000 % 10);
		
		String jumin = scanner.nextLine().trim();
		System.out.println(jumin);
		System.out.println(jumin.charAt(6));
		
//		숫자(2진수)와 문자(유니코드)는 표현 방법이 다르다.
//		숫자 1(00000001)과 문자 '1'(00110001)은 다른 데이터로 취급된다.
		
//		jumin.charAt(6) == 와 같이 비교하면 조건 비교 결과는 무조건 거짓이 된다.
		if (jumin.charAt(6) == 1 || jumin.charAt(6) == 3) {
			System.out.println("남자");
		} else {
			System.out.println("여자");
		}
		
//		'1'와 같이 숫자인데 문자화된 데이터를 다시 숫자로 변경하려면 '0' 또는 48을 빼주면 된다.
		if (jumin.charAt(6) == '1' || jumin.charAt(6) - '0' == 3) {
			System.out.println("남자");
		} else {
			System.out.println("여자");
		}
		
		if (jumin.charAt(6) % 2 == 1) {
			System.out.println("남자");
		} else {
			System.out.println("여자");
		}
		
	}
	
}






















