package com.mbcit.k20250121_1_springBoot_JPA01.domain;

import java.time.LocalDateTime;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@NoArgsConstructor
@Data
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
@Entity
public class BookReviewInfo extends BaseEntity {

	@Id
//	@GeneratedValue
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id; // PK
//	멤버 선언시 기본 자료형을 사용하면 테이블 생성시 not null을 사용해 null check를 한다.
//	null check를 하지 않으려면 랩퍼 클래스를 사용하면 된다.
	private float averageReviewScore;
	private int reviewCount;
//	createDate, updateDate는 BaseEntity에서 상속받아 사용한다.
//	private LocalDateTime createDate;
//	private LocalDateTime updateDate;
	
//	@OneToOne 어노테이션으로 1:1 연관 관계를 설정할 것이므로 bookId는 제거한다.
//	private Long bookId; // FK
	
//	1:1 연관 관계를 설정해서 Book 엔티티를 직접 참조하게 설정한다.
//	@OneToOne 어노테이션으로 참조하게 될 엔티티에 지정해서 1:1 연관 관계를 설정한다.
//	@OneToOne
//	@OneToOne(optional = true)
	
//	@OneToOne 어노테이션만 사용하거나 optional = true 옵션을 지정해서 @OneToOne 어노테이션을
//	사용하면 아래와 같이 create table sql 명령이 실행되며 테이블이 만들어진다.
//	create table book_review_info (
//		...
//		자동으로 추가된 외래키 필드가 null 값을 허용하고 내부적으로 left outer join이 걸리게 된다.
//		왼쪽 테이블은 있을 수도 있고 없을 수도 있는 값(모든값) 오른쪽 테이블에는 반드시 존재하는
//		값을 얻어온다.
//		테이블을 만들때 외래키로 사용할 필드가 자동으로 추가된다.
//		book_id bigint, // book_id bigint unique => springBoot 3.x 버전은 unique가 붙는다.
//		...
//	)
	
//	테이블이 만들어진 후 아래와 같이 book 엔티티의 기본키를 참조하는 외래키가 설정된다.
//	alter table book_review_info 
//		add constraint FKp5fhkokpbtoxmc3mxo8ay9e5l // 참조 무결성 제약 사항 추가
//		foreign key (book_id) // 외래키로 사용될 필드 설정 
//		references book // 외래키가 참조할 엔티티, 외래키는 참조할 엔티티의 기본키를 참조한다.
	
	@OneToOne(optional = false)
//	@OneToOne 어노테이션만 사용하거나 optional = true 옵션을 지정해서 @OneToOne 어노테이션을
//	사용하면 아래와 같이 create table sql 명령이 실행되며 테이블이 만들어진다.
//	create table book_review_info (
//		...
//		자동으로 추가된 외래키 필드가 null 값을 허용하지 않으므로 내부적으로 inner join이 걸리게 된다.
//		두 테이블에 반드시 존재하는 값만 얻어온다.
//		테이블을 만들때 외래키로 사용할 필드가 자동으로 추가된다.
//		book_id bigint not null, // book_id bigint not null unique
//		...
//	)
	private Book book; // 참조하게 될 엔티티 객체, 객체이름_id 필드가 자동으로 만들어진다.
	
}














