package k20240930;

public class HelloJava {

	public static void main(String[] args) {

//		주석: 프로그램에 대한 간단한 설명 => 컴파일러가 번역하지 않는다. => 프로그램 실행에 영향을 주지 않는다.
//		1줄 주석: "/"를 연속해서 2개를 입력한다.
//		1줄 주석 단축키: ctrl + /, 누를 때마다 주석이 지정 또는 해제된다.
//		범위 주석: "/*" ~ "*/" 사이에 입력한다.
//		범위 주석 단축키: 블록을 지정하고 ctrl + shift + /를 누르면 주석이 설정되고 ctrl + shift + \를
//		누르면 주석이 해제된다.

//		자동완성 단축키: ctrl + space
//		프로그램 실행 단축키: ctrl + F11

//		코드 복사 단축키: ctrl + alt + ↑(위로 복사), ctrl + alt + ↓(아래로 복사)
//		코드 이동 단축키: alt + ↑(위로 이동), alt + ↓(아래로 이동)
//		코드 삭제 단축키: ctrl + d
//		들여쓰기 정리 단축키: ctrl + shift + f
//		들여쓰기 단축키: tab
//		내어쓰기 단축키: shift + tab

//		println: 괄호 안의 내용을 출력하고 줄을 바꾼다.
//		print: 괄호 안의 내용을 출력하고 줄을 바꾸지 않는다.
//		printf: 출력 서식을 지정해서 출력한다.
		System.out.print("안녕 자바1");
		System.out.println("안녕\n자바2"); // \n: new line => 줄을 바꾼다.
		System.out.println("안녕 자바3");

	}

}
