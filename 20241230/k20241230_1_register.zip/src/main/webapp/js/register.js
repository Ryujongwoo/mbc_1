function passwordCheckFunction() {
	let password = $('#password').val()
	let password2 = $('#password2').val()
	
	if (password == password2) {
		$('#passwordCheckMessage').html('비밀번호가 일치합니다.')
	} else {
		$('#passwordCheckMessage').html('비밀번호가 일치하지 않습니다.')
	}
}













