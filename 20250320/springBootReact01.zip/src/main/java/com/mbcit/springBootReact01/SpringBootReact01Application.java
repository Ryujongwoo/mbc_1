package com.mbcit.springBootReact01;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootReact01Application {
	
	private static final Logger logger = LoggerFactory.getLogger(SpringBootReact01Application.class);

	public static void main(String[] args) {
		SpringApplication.run(SpringBootReact01Application.class, args);
		logger.info("springBoot 어플리케이션 시작");
	}

}
