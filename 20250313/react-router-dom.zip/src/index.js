import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';
import reportWebVitals from './reportWebVitals';

// BrowserRouter를 사용하려면 먼저 import를 해야한다.
// BrowserRouter는 리액트 라우터의 도움을 받으려는 컴포넌트의 최상위 컴포넌트를 감싸주는
// 랩퍼 컴포넌트 이다.
// HashRouter를 사용하면 URL 창에 hash(#)가 포함되서 라우팅을 한다.
import { BrowserRouter/*, HashRouter*/ } from 'react-router-dom';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <BrowserRouter>
    {/* <HashRouter> */}
      <App />
    {/* </HashRouter> */}
    </BrowserRouter>
  </React.StrictMode>
);

reportWebVitals();
