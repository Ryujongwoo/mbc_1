package com.mbcit.k20250121_2_springBoot_Mybatis_ResultNum;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.mbcit.k20250121_2_springBoot_Mybatis_ResultNum.dao.SimpleBbsDAO;
import com.mbcit.k20250121_2_springBoot_Mybatis_ResultNum.vo.SimpleBbsVO;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
public class HomeController {

	@Autowired
	private SimpleBbsDAO dao;
	
	@RequestMapping("/")
	public String home() {
		log.info("HomeController 클래스의 home() 메소드 실행");
		return "redirect:list";
	}
	
	@RequestMapping("/insert")
	public String insert() {
		log.info("HomeController 클래스의 insert() 메소드 실행");
		return "insert";
	}
	
	@RequestMapping("/insertOK")
	public String insertOK(SimpleBbsVO simpleBbsVO) {
		log.info("HomeController 클래스의 insertOK() 메소드 실행");
		int result = dao.insert(simpleBbsVO.getName(), simpleBbsVO.getTitle(), simpleBbsVO.getContent());
		log.info("저장한 글 개수: {}", result);
		return "redirect:list";
	}
	
	@RequestMapping("/list")
	public String list(Model model) {
		log.info("HomeController 클래스의 list() 메소드 실행");
		model.addAttribute("list", dao.selectList());
		int result = dao.selectCount();
		log.info("저장된 글 개수: {}", result);
		return "list";
	}
	
	@RequestMapping("/view")
	public String view(HttpServletRequest request, Model model) {
		log.info("HomeController 클래스의 view() 메소드 실행");
		int idx = Integer.parseInt(request.getParameter("idx"));
		model.addAttribute("vo", dao.selectByIdx(idx));
		return "view";
	}
	
	@RequestMapping("/update")
	public String update(HttpServletRequest request, Model model) {
		log.info("HomeController 클래스의 update() 메소드 실행");
		int idx = Integer.parseInt(request.getParameter("idx"));
		model.addAttribute("vo", dao.selectByIdx(idx));
		return "update";
	}
	
	@RequestMapping("/updateOK")
	public String updateOK(SimpleBbsVO simpleBbsVO) {
		log.info("HomeController 클래스의 updateOK() 메소드 실행");
		int result = dao.update(simpleBbsVO);
		log.info("수정한 글 개수: {}", result);
		return "redirect:list";
	}
	
	@RequestMapping("/delete")
	public String delete(HttpServletRequest request) {
		log.info("HomeController 클래스의 delete() 메소드 실행");
		int idx = Integer.parseInt(request.getParameter("idx"));
		int result = dao.delete(idx);
		log.info("삭제한 글 개수: {}", result);
		return "redirect:list";
	}
}


















