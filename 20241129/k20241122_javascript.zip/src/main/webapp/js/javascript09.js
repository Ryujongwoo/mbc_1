//	배열이름.splice(인덱스, 개수): 배열에서 인덱스 번째 위치부터 지정된 개수만큼 추출해서 배열로 리턴한다.

const numbers = [10, 20, 30, 40];
const spliced = numbers.splice(1, 2); // 1번째 인덱스 부터 2개를 추출한다.
console.log('spliced: ' + spliced);
//	spliced 함수는 원본 배열에서 데이터를 추출하기 때문에 원본 배열의 데이터가 제거된다.
console.log('numbers: ' + numbers);

//	배열이름.slice(시작인덱스, 끝인덱스): 배열에서 시작 인덱스 부터 끝 인덱스 - 1번째 인덱스까지 복사해서 배열로
//	리턴한다.

const numbers2 = [10, 20, 30, 40];
const sliced = numbers2.slice(1, 2); // 1번째 인덱스 부터 1번째 인덱스까지 복사한다.
console.log('sliced: ' + sliced);
//	slice 함수는 원본 배열에서 데이터를 복사하므로 원본 배열의 데이터가 변경되지 않는다.
console.log('numbers2: ' + numbers2);
console.log('1. =================================');

//	배열에 데이터 추가, 제거 함수
//	push(): 배열의 맨 뒤에 데이터를 추가하고 배열의 크기가 리턴된다.
//	unshift(): 배열의 맨 앞에 데이터를 추가하고 배열의 크기가 리턴된다.
//	pop(): 배열의 맨 뒤의 데이터를 얻어온 후 제거한다.
//	shift(): 배열의 맨 앞의 데이터를 얻어온 후 제거한다.

const numbers3 = [10, 20, 30, 40];
console.log(`numbers: ${numbers3}, length: ${numbers3.length}`);
let len = numbers3.push(999);
console.log(`numbers: ${numbers3}, length: ${len}`);
len = numbers3.unshift(777);
console.log(`numbers: ${numbers3}, length: ${len}`);

let popData = numbers3.pop();
console.log(`popData: ${popData}, numbers: ${numbers3}, length: ${numbers3.length}`);
let shiftData = numbers3.shift();
console.log(`shiftData: ${shiftData}, numbers: ${numbers3}, length: ${numbers3.length}`);
console.log('2. =================================');

//	배열이름.concat(배열이름[, 배열이름, ...]): 배열에 인수로 지정된 배열을 연결한 새 배열을 리턴한다.

const array = [1, 2, 3];
const array2 = [10, 20, 30];
const array3 = [100, 200, 300];

const concated = array.concat(array2);
console.log(concated);
const concated2 = array.concat(array2, array3);
console.log(concated2);
console.log('3. =================================');

//	배열이름.join('문자열'): 배열 요소들 사이에 인수로 지정한 문자열을 삽입해서 하나의 문자열로 리턴한다.
//	join 함수의 인수를 생략하면 ','가 기본값으로 사용된다.

const names = ['홍길동', '임꺽정', '장길산', '일지매'];
console.log(names.join());
console.log(names.join(' '));
console.log(names.join(', '));
console.log(names.join('/'));
console.log(names.join('~(^^!)'));
console.log(names.join('      '));
console.log(names.join('\t')); // tab 키
console.log(names.join('\n')); // enter 키
console.log('4. =================================');

