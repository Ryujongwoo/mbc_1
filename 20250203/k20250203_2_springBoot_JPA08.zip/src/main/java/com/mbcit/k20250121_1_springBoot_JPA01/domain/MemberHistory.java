package com.mbcit.k20250121_1_springBoot_JPA01.domain;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.ToString;

@NoArgsConstructor
@Data
@Entity
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class MemberHistory extends BaseEntity {

	@Id
//	@GeneratedValue
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
//	MemberHistory 엔티티에 선언한 필드 memberId는 테이블에는 member_id로 저장되므로 외래키 연결을 
//	위해서 Member 엔티티의 @JoinColumn 어노테이션의 name 속성에서 지정한 이름으로 @Column 어노테이션의
//	name 속성으로 지정한다.
	@Column(name = "member_idx")
	private Long memberId; // 외래키로 사용될 필드
	private String name;
	private String email;

//	MemberHistory 엔티티와 Member 엔티티의 N:1 연관 관계를 설정한다.
	@ManyToOne
//	StackOverflowError가 발생되므로 toString() 메소드를 제외시킨다.
	@ToString.Exclude
//	MemberHistory 엔티티에 관련된 Member 엔티티는 한 개이기 때문에 Member 엔티티 타입으로 선언한다.
	private Member member;
	
}










