package com.mbcit.category.vo;

import java.util.ArrayList;

//	카테고리 목록을 기억하는 클래스
public class CategoryList {

	private ArrayList<CategoryVO> categoryList = new ArrayList<CategoryVO>();

	public ArrayList<CategoryVO> getCategoryList() {
		return categoryList;
	}
	public void setCategoryList(ArrayList<CategoryVO> categoryList) {
		this.categoryList = categoryList;
	}
	
	@Override
	public String toString() {
		return "CategoryList [categoryList=" + categoryList + "]";
	}
	
}
