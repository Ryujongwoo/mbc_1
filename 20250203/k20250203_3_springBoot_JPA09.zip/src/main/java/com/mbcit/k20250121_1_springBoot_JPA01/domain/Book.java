package com.mbcit.k20250121_1_springBoot_JPA01.domain;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@NoArgsConstructor
@Data
@Entity
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class Book extends BaseEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private String name;
	private String category;
	
	@OneToOne
	private BookReviewInfo bookReviewInfo;

	@OneToMany
	@JoinColumn(name = "book_id")
	private List<Review> reviews = new ArrayList<>();

	@ManyToOne
	private Publisher publisher;
	
//	1권의 책(Book)은 어려명의 저자(Author)가 같이 쓸 수 있고 1명의 저자는 여러권의 책을 쓸 수 있으므로
//	책과 저자는 N:M 관계가 성립되므로 @ManyToMany 어노테이션을 사용해서 N:M 관계로 설정한다.
	@ManyToMany
	private List<Author> authors = new ArrayList<>();
	
	public void addAuthor(Author ... authors) {
//		if (authors != null) {
//			for (Author author : authors) {
//				this.authors.add(author);
//			}
//		}
		Collections.addAll(this.authors, authors);
	}
	
}












