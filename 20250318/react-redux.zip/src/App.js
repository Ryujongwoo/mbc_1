import './App.css';
import './style.css';
import { useState } from 'react';

// redux와 react-redux를 사용하려면 npm install redux react-redux를 실행해서 설치한다.
// redux를 사용하려면 createStore를 import 해야한다. => 취소선이 나온다.
// 취소선 없이 createStore를 import 해서 사용하려면 legacy_createStore as를 앞에 붙여서
// import 시켜 사용하면 된다.
import { legacy_createStore as createStore } from 'redux';

// Provider는 state를 적용할 컴포넌트들의 가장 바깥쪽에 울타리를 씌우는 역할을 한다.
// 컴포넌트에 redux를 사용해서 state 값을 표시하려면 useSelector 함수를 사용해야 한다.
// useDispatch 함수로 reducer 함수를 실행한다.
import { Provider, useSelector, useDispatch } from 'react-redux';

// redux를 사용하려면 createStore 함수로 스토어를 만들어야 한다.
// 스토어를 생성할 때 반드시 reducer 함수를 주입해야 하는데 reducer는 스토어에 있는 state를 
// 어떻게 바꿀것인지 결정하는 역할을 하는 함수이다.
function reducer(currentState, action) {
  // currentState의 값이 undefined라면 state가 정의되지 않았다는 것이므로 기본 state 값을
  // 리턴하므로써 기본값을 설정할 수 있다.
  if (currentState === undefined) {
    return {
      // count state의 기본값을 1로 설정한다.
      count: 100
    }
  }
  // currentState의 정의된 상태라면 currentState를 복사해서 새 state 값을 리턴한다.
  const newState = { ...currentState };
  // 
  if (action.type === 'PLUS') {
    newState.count++;
  }
  return newState;
}
const store = createStore(reducer);

function Left1(props) {
  // console.log(props, props.number);
  return (
    <div>
      <h1>Left1: {props.number}</h1>
      <Left2 number={props.number} onIncrement={
        function () {
          props.onIncrement();
        }
      }></Left2>
    </div>
  )
}

function Left2(props) {
  return (
    <div>
      <h1>Left2: {props.number}</h1>
      <Left3 number={props.number} onIncrement={
        function () {
          props.onIncrement();
        }
      }></Left3>
    </div>
  )
}

function Left3(props) {
  // useSelector 함수는 함수 1개를 인수로 받는다.
  // 인수로 받은 함수는 state를 입력값으로 받고 입력값으로 받은 state 중에서 어떤 값을 사용할 
  // 것인지 리턴한다. 
  // function func(state) {
  //   return state.count;
  // }
  // const func = state => state.count;
  const count = useSelector(state => state.count);

  return (
    <div>
      <h1>Left3: {props.number}, {count}</h1>
      <button type="button" onClick={
        function () {
          props.onIncrement();
        }
      }>+</button>
    </div>
  )
}

function Right1(props) {
  // console.log('Right1:', props);
  return (
    <div>
      <h1>Right1: {props.number}</h1>
      <Right2 number={props.number} onIncrement={props.onIncrement}></Right2>
    </div>
  )
}

function Right2(props) {
  // console.log('Right2:', props);
  const count = useSelector(state => state.count);
  return (
    <div>
      <h1>Right2: {props.number}, {count}</h1>
      <Right3 number={props.number} onIncrement={props.onIncrement}></Right3>
    </div>
  )
}

function Right3(props) {
  // console.log('Right3:', props);
  const dispatch = useDispatch();
  return (
    <div>
      <h1>Right3: {props.number}</h1>
      <button type="button" onClick={
        props.onIncrement
      }>+</button>
      <button type="button" onClick={() => {
        // reducer 함수의 2번째 인수 action으로 { type: 'PLUS'} 객체가 전달된다.
        dispatch({ type: 'PLUS'})
      }}>redux</button>
    </div>
  )
}

function App() {
  const [number, setNumber] = useState(1);
  return (
    <div id="container" className="App">
      <h1>Root: {number}</h1>
      <div id="grid">

        {/*
        Provider는 state를 어떤 컴포넌트들에 제공할 것인지 가장 바깥쪽 울타리를 정의한다.
        Provider 컴포넌트는 props 중에 store를 반드시 지정해야 한다.
        이때 지정하는 스토어는 createStore(리듀서함수) 함수로 생성한 store이다.
        */}
        <Provider store={store}>
          <Left1 number={number} onIncrement={
            function () {
              setNumber(number - 1)
            }
          }></Left1>
          <Right1 number={number} onIncrement={() => setNumber(number + 1)}></Right1>
        </Provider>

      </div>
    </div>
  );
}

export default App;
