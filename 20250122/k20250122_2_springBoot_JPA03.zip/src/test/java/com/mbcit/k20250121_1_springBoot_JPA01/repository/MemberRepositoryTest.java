package com.mbcit.k20250121_1_springBoot_JPA01.repository;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.persistence.Column;

import org.assertj.core.util.Lists;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;

import com.mbcit.k20250121_1_springBoot_JPA01.domain.Gender;
import com.mbcit.k20250121_1_springBoot_JPA01.domain.Member;
import com.mbcit.k20250121_1_springBoot_JPA01.repository.MemberRepository;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@SpringBootTest
class MemberRepositoryTest {

	@Autowired
	private MemberRepository memberRepository;
	
	@Test
	void test() {
		System.out.println("MemberRepositoryTest 클래스의 test() 메소드 실행");
		log.info("결과: {}", memberRepository.findAll());
		memberRepository.findAll().forEach(System.out::println);
	}
	
	@Test
	public void insertAndUpdateTest() {
		System.out.println("MemberRepositoryTest 클래스의 insertAndUpdateTest() 메소드 실행");
		System.out.println("@Column(updatable = false), @Column(insertable = false) 테스트");
		
		Member member = new Member();
		member.setName("손오공");
		member.setEmail("son@mbcit.com");
		memberRepository.save(member);
		
		Member member2 = memberRepository.findById(1L).orElse(null);
		member2.setName("저팔계");
		memberRepository.save(member2);
		memberRepository.findAll().forEach(System.out::println);
	}

	@Test
	public void enumTest() {
		System.out.println("MemberRepositoryTest 클래스의 enumTest() 메소드 실행");
		Member member = memberRepository.findById(1L).orElse(null);
		memberRepository.save(member);
		memberRepository.findAll().forEach(System.out::println);
		Map<String, Object> map = memberRepository.findRecord();
		for (String key : map.keySet()) {
			System.out.println(key + ": " + map.get(key));
		}
	}
	
	@Test
	public void basicMethod() {
		System.out.println("MemberRepositoryTest 클래스의 basicMethod() 메소드 실행");
		List<Member> members = memberRepository.findAll();
		members.forEach(System.out::println);
		
		members = memberRepository.findAll(Sort.by(Direction.ASC, "name"));
		members.forEach(System.out::println);
		
		members = memberRepository.findAll(Sort.by(Direction.DESC, "id"));
		members.forEach(System.out::println);
		
		Member member = memberRepository.findById(10L).orElse(null);
		System.out.println(member);
		
		members = memberRepository.findAllById(Lists.newArrayList(1L, 3L, 4L));
		members.forEach(System.out::println);
		
		memberRepository.save(new Member("손오공1", "son1@mbcit.com"));
		memberRepository.save(new Member("손오공2", "son2@mbcit.com"));
		memberRepository.flush();
		memberRepository.saveAndFlush(new Member("손오공3", "son3@mbcit.com")); // 즉시 적용
		members = memberRepository.findAll();
		members.forEach(System.out::println);
		
		Member member1 = new Member("저팔계", "jeo@mbcit.com");
		Member member2 = new Member("사오정", "sa@mbcit.com");
		Member member3 = new Member("오로라공주", "aurora@mbcit.com");
		memberRepository.saveAll(Lists.newArrayList(member1, member2, member3));
		members = memberRepository.findAll();
		members.forEach(System.out::println);
		
		long count = memberRepository.count();
		System.out.println(count);
		
		boolean exists = memberRepository.existsById(1L);
		System.out.println(exists);
		System.out.println(exists ? "있음" : "없음");
		
//		Page<Member> page = memberRepository.findAll(PageRequest.of(2, 5));
//		Page<Member> page = memberRepository.findAll(PageRequest.of(2, 5, Sort.by(Direction.ASC, "name")));
		Page<Member> page = memberRepository.findAll(PageRequest.of(2, 5, Sort.by(Direction.DESC, "id")));
		System.out.println(page);
		page.getContent().forEach(System.out::println);
		System.out.println(page.getTotalElements());
		System.out.println(page.getNumberOfElements());
		System.out.println(page.getSort());
		System.out.println(page.getSize());
		
		memberRepository.delete(memberRepository.findById(1L).orElse(null));
		memberRepository.deleteById(4L);
		members = memberRepository.findAll();
		members.forEach(System.out::println);
		
		memberRepository.deleteAll(memberRepository.findAllById(Lists.newArrayList(6L, 7L)));
		members = memberRepository.findAll();
		members.forEach(System.out::println);
		
		memberRepository.deleteAll();
		members = memberRepository.findAll();
		members.forEach(System.out::println);
		
		memberRepository.save(new Member("유비", "yoo@mbcit.com"));
		members = memberRepository.findAll();
		members.forEach(System.out::println);
		
		member = new Member();
		member.setId(13L);
		member.setName("관우");
		member.setEmail("kwan@mbcit.com");
		memberRepository.save(member);
		members = memberRepository.findAll();
		members.forEach(System.out::println);
	}
	
	@Test
	public void select() {
		System.out.println("MemberRepositoryTest 클래스의 select() 메소드 실행");
		
//		id 필드 이외의 필드 조회하기
//		Member findByName(String name) 메소드는 인수로 전달되는 값에 해당되는 데이터가 1개일 경우
//		정상적으로 실행되지만 여러 개일 경우 에러가 발생된다.
//		Member member = memberRepository.findByName("임꺽정"); // 정상 실행
//		Member member = memberRepository.findByName("홍길동"); // 에러 발생
//		System.out.println(member);
		
//		List<Member> findByName(String name) 메소드는 실행할 때 인수로 전달되는 값에 해당되는 데이터
//		개수와 관계 없이 모두 정상 실행된다.
//		List<Member> members = memberRepository.findByName("임꺽정"); // 정상 실행
		List<Member> members = memberRepository.findByName("홍길동"); // 정상 실행
		members.forEach(System.out::println);
		
		members = memberRepository.findByEmail("hong@mbcit.com");
		members.forEach(System.out::println);
	}
	
}























