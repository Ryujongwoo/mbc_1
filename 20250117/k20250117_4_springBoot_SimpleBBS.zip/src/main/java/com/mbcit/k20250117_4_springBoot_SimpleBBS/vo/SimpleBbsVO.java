package com.mbcit.k20250117_4_springBoot_SimpleBBS.vo;

import lombok.Data;

@Data
public class SimpleBbsVO {

	private int idx;
	private String name;
	private String title;
	private String content;
	
}
