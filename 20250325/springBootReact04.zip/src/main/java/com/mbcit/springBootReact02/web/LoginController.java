package com.mbcit.springBootReact02.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.mbcit.springBootReact02.domain.AccountCredentials;
import com.mbcit.springBootReact02.service.JwtService;

//	로그인을 위한 컨트롤러
//	이 컨트롤러를 이용하여 로그인하려면 요청 본문에 사용자 이름과 암호를 넣고 POST 방식으로
//	"/login" 엔드포인트로 호출한다.
@RestController
public class LoginController {
	
//	로그인 성공시 서명된 JWT를 생성하는데 필요한 JwtService 인스턴스를 주입한다.
	@Autowired
	private JwtService jwtService;
	
	@Autowired
	private AuthenticationManager authenticationManager;

//	로그인 기능을 처리하는 메소드
	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public ResponseEntity<?> getToken(@RequestBody AccountCredentials accountCredentials) {
		System.out.println("LoginController 클래스의 getToken() 메소드 실행");
		
//		토큰을 생성하고 응답의 Authorization 헤더로 보낸다.
		UsernamePasswordAuthenticationToken creds = 
			new UsernamePasswordAuthenticationToken(
				accountCredentials.getUsername(), accountCredentials.getPassword()
			);
		Authentication auth = authenticationManager.authenticate(creds);
		
//		JWS 토큰을 만든다.
		String jwts = jwtService.getToken(auth.getName());
		
//		생성된 토큰으로 응답한다.
		return ResponseEntity.ok()
				.header(HttpHeaders.AUTHORIZATION, "Bearer " + jwts)
				.header(HttpHeaders.ACCESS_CONTROL_EXPOSE_HEADERS, "Authorization")
				.build();
	}
	
}
















