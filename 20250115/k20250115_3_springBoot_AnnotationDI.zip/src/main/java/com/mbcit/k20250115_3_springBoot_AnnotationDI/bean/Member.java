package com.mbcit.k20250115_3_springBoot_AnnotationDI.bean;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

//	bean으로 등록하려는 클래스는 @Component 어노테이션을 붙여준다.
@Component
public class Member {

//	bean이 생성될 때 필드의 기본값을 지정하려면 @Value 어노테이션을 붙여준다.
	@Value("홍길동")
	private String name;
	@Value("도적")
	private String nickname;
//	bean이 생성될 때 참조할 객체를 자동으로 찾아오려면 @Autowired 어노테이션을 붙여준다.
	@Autowired
//	유사한 객체가 여러개 있을 경우 bean의 이름을 정확히 지정하려면 @Qualifier 어노테이션을 붙여준다.
	@Qualifier("printerA")
	private Printer printer;
	
	public Member() { }
	public Member(String name, String nickname, Printer printer) {
		this.name = name;
		this.nickname = nickname;
		this.printer = printer;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getNickname() {
		return nickname;
	}
	public void setNickname(String nickname) {
		this.nickname = nickname;
	}
	public Printer getPrinter() {
		return printer;
	}
	public void setPrinter(Printer printer) {
		this.printer = printer;
	}
	
	@Override
	public String toString() {
		return "Member [name=" + name + ", nickname=" + nickname + ", printer=" + printer + "]";
	}
	
	public void print() {
		printer.print("Hello " + name + ": " + nickname);
	}
	
}




