package com.mbcit.springWEB_DBCP_board;

import java.util.Locale;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mbcit.springWEB_DBCP_board.service.ContentViewService;
import com.mbcit.springWEB_DBCP_board.service.DeleteService;
import com.mbcit.springWEB_DBCP_board.service.IncrementService;
import com.mbcit.springWEB_DBCP_board.service.InsertService;
import com.mbcit.springWEB_DBCP_board.service.MvcboardService;
import com.mbcit.springWEB_DBCP_board.service.ReplyService;
import com.mbcit.springWEB_DBCP_board.service.SelectService;
import com.mbcit.springWEB_DBCP_board.service.UpdateService;

@Controller
public class HomeController {
	
	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);
	
//	JdbcTemplate을 사용하려면 servlet-context.xml 파일에서 프로젝트가 시작될 때 DriverManagerDataSource
//	클래스의 bean(데이터베이스 연결 정보)를 참조해서 생성한 JdbcTemplate 클래스의 bean은 컨트롤러에서
//	JdbcTemplate 클래스 타입의 객체를 생성한다.
	private JdbcTemplate template;
	
//	JdbcTemplate 클래스 타입 객체의 setter를 만든다.
//	@Autowired 어노테이션을 붙여서 선언한 메소드는 서버 구동 단계에서 자동으로 실행된다.
//	프로젝트를 실행하면 spring 환경 설정 파일인 servlet-context.xml 파일이 읽혀진 다음 특정 메소드가 
//	자동으로 실행되게 하려면 메소드에 @Autowired 어노테이션 붙여서 선언하면 된다.
//	@Autowired 어노테이션을 붙여서 선언한 메소드는 서버가 구동되는 단계에서 자동으로 실행되며 메소드의
//	인수로 spring이 알아서 인수의 테이터 타입(JdbcTemplate)에 해당되는 bean을 자동으로 전달한다.
//	@Autowired 어노테이션을 붙여 선언한 메소드는 인수로 넘겨받은 JdbcTemplate 객체로 멤버로 선언한
//	JdbcTemplate 객체를 초기화 시킨다.
	@Autowired
	public void setTemplate(JdbcTemplate template) {
		// logger.info("꺄오~~~~~");
		// logger.info("{}", template);
		this.template = template;
		
		// 여기까지 정상적으로 실행되면 컨트롤러에서 DBCP Template을 사용할 수 있다.
		// 프로젝트에서 실행할 sql 명령은 데이터베이스와 연결한 후 주로 DAO 클래스에서 실행하므로
		// 컨트롤러 이외의 클래스에서 JdbcTemplate 사용할 수 있게 하기 위해서 적당한 패키지에
		// 적당한 클래스를 만들고 정적 멤버에 servlet-context.xml 파일에서 생성해서 @Autowired
		// 어노테이션을 붙여 선언한 메소드에서 초기화한 JdbcTemplate 클래스의 bean을 넣어준다.
		
		// 적당한 패키지(base-package)에 적당한 클래스(Constant)를 선언하고 정적(public static)
		// 필드를 선언해서 JdbcTemplate 클래스의 객체를 넣어준다.
		Constant.template = this.template;
	}
	
	
	@RequestMapping("/")
	public String home(Locale locale, Model model) {
		logger.info("Mvcboard 게시판 실행");
		return "redirect:list";
	}

	@RequestMapping("/insert")
	public String insert(HttpServletRequest request, Model model) {
		logger.info("HomeController 컨트롤러의 insert() 메소드 실행");
		return "insert";
	}
	
	@RequestMapping("/insertOK")
	public String insertOK(HttpServletRequest request, Model model) {
		logger.info("HomeController 컨트롤러의 insertOK() 메소드 실행");
		model.addAttribute("request", request);
		AbstractApplicationContext ctx = new GenericXmlApplicationContext("classpath:/applicationCTX.xml");
		MvcboardService service = ctx.getBean("insert", InsertService.class);
		service.execute(model);
		return "redirect:list";
	}
	
	@RequestMapping("/list")
	public String list(HttpServletRequest request, Model model) {
		logger.info("HomeController 컨트롤러의 list() 메소드 실행");
		model.addAttribute("request", request);
		AbstractApplicationContext ctx = new GenericXmlApplicationContext("classpath:/applicationCTX.xml");
		MvcboardService service = ctx.getBean("select", SelectService.class);
		service.execute(model);
		return "list";
	}
	
	@RequestMapping("/increment")
	public String increment(HttpServletRequest request, Model model) {
		logger.info("HomeController 컨트롤러의 increment() 메소드 실행");
		model.addAttribute("request", request);
		AbstractApplicationContext ctx = new GenericXmlApplicationContext("classpath:/applicationCTX.xml");
		MvcboardService service = ctx.getBean("increment", IncrementService.class);
		service.execute(model);
		model.addAttribute("idx", request.getParameter("idx"));
		model.addAttribute("currentPage", request.getParameter("currentPage"));
		return "redirect:contentView";
	}
	
	@RequestMapping("/contentView")
	public String contentView(HttpServletRequest request, Model model) {
		logger.info("HomeController 컨트롤러의 contentView() 메소드 실행");
		model.addAttribute("request", request);
		AbstractApplicationContext ctx = new GenericXmlApplicationContext("classpath:/applicationCTX.xml");
		MvcboardService service = ctx.getBean("contentView", ContentViewService.class);
		service.execute(model);
		return "contentView";
	}
	
	@RequestMapping("/update")
	public String update(HttpServletRequest request, Model model) {
		logger.info("HomeController 컨트롤러의 update() 메소드 실행");
		model.addAttribute("request", request);
		AbstractApplicationContext ctx = new GenericXmlApplicationContext("classpath:/applicationCTX.xml");
		MvcboardService service = ctx.getBean("update", UpdateService.class);
		service.execute(model);
		return "redirect:list";
	}
	
	@RequestMapping("/delete")
	public String delete(HttpServletRequest request, Model model) {
		logger.info("HomeController 컨트롤러의 delete() 메소드 실행");
		model.addAttribute("request", request);
		AbstractApplicationContext ctx = new GenericXmlApplicationContext("classpath:/applicationCTX.xml");
		MvcboardService service = ctx.getBean("delete", DeleteService.class);
		service.execute(model);
		return "redirect:list";
	}
	
	@RequestMapping("/reply")
	public String reply(HttpServletRequest request, Model model) {
		logger.info("HomeController 컨트롤러의 reply() 메소드 실행");
		model.addAttribute("request", request);
		AbstractApplicationContext ctx = new GenericXmlApplicationContext("classpath:/applicationCTX.xml");
		MvcboardService service = ctx.getBean("contentView", ContentViewService.class);
		service.execute(model);
		return "reply";
	}
	
	@RequestMapping("/replyInsert")
	public String replyInsert(HttpServletRequest request, Model model) {
		logger.info("HomeController 컨트롤러의 replyInsert() 메소드 실행");
		model.addAttribute("request", request);
		AbstractApplicationContext ctx = new GenericXmlApplicationContext("classpath:/applicationCTX.xml");
		MvcboardService service = ctx.getBean("reply", ReplyService.class);
		service.execute(model);
		return "redirect:list";
	}
	
}
















