import './App.css';
import Home from './Home';
import Contact from './Contact';
import PageNotFound from './PageNotFound';
import { BrowserRouter, Link, Route, Routes } from 'react-router-dom';

function App() {
  return (
    <div className="App">
      <BrowserRouter>
        <nav>
          <Link to="/">Home</Link>{' '}
          <Link to="/contact">Contact</Link>
        </nav>
        <Routes>
          <Route path='/' element={<Home />}/>
          <Route path='/contact' element={<Contact />}/>
          {/* Route 컴포넌트의 path 프롭에 와일드카드(*)를 이용해서 PageNotFound 경로를 지정할 수 있다. */}
          <Route path='*' element={<PageNotFound />}/>
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
