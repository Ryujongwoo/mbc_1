package com.mbcit.springBootBoard.service;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mbcit.springBootBoard.dto.CommentDto;
import com.mbcit.springBootBoard.entity.Article;
import com.mbcit.springBootBoard.entity.Comment;
import com.mbcit.springBootBoard.repository.ArticleRepository;
import com.mbcit.springBootBoard.repository.CommentRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class CommentService {

//	article 테이블에 JPA 메소드를 실행하기 위해서 ArticleRepository 인터페이스의 bean을 얻어온다.
	@Autowired
	private ArticleRepository articleRepository;
//	comment 테이블에 JPA 메소드를 실행하기 위해서 CommentRepository 인터페이스의 bean을 얻어온다.
	@Autowired
	private CommentRepository commentRepository;
	
//	질문글 id에 따른 답변글 목록 조회
	public List<CommentDto> comments(Long articleId) {
		log.info("CommentService의 comments() 메소드 실행");
//		log.info("articleRepository: " + articleRepository);
//		log.info("commentRepository: " + commentRepository);
//		log.info("articleId: " + articleId);
		
//		메인글의 id에 따른 답변글 목록 조회
		List<Comment> comments = commentRepository.findByArticleId(articleId);
//		comments.forEach(System.out::println);
		
//		Comment 엔티티 객체를 CommentDto 객체로 변환한다.
		List<CommentDto> commentDtos = new ArrayList<>();
		
//		for (int i=0; i<comments.size(); i++) {
//			Comment 엔티티 객체를 CommentDto 클래스 객체로 변환하는 메소드를 호출한다.
//			Comment comment = comments.get(i);
//			CommentDto commentDto = CommentDto.createCommentDto(comment);
//			commentDtos.add(commentDto);
//		}
		
		for (Comment comment : comments) {
			CommentDto commentDto = CommentDto.createCommentDto(comment);
			commentDtos.add(commentDto);
		}
		
		return commentDtos;
	}

//	답변글 입력
//	댓글 입력에 실패하면 실행전 상태로 되돌려야 하므로 트랜잭션 처리를 한다.
	@Transactional
	public CommentDto create(Long articleId, CommentDto commentDto) {
		log.info("CommentService의 create() 메소드 실행");
//		log.info("articleId: {}, commentDto: {}", articleId, commentDto);
		
//		답변글을 저장하려는 질문글이 없으면 예외를 발생시킨다.
		Article article = articleRepository.findById(articleId).orElseThrow(
			() -> new IllegalArgumentException("답변글 저장 실패!!! 질문글이 없습니다.")
		);
		
//		답변글 엔티티를 생성한다.
		Comment comment = Comment.createComment(article, commentDto);
//		log.info("comment: " + comment);
//		답변글 엔티티를 테이블에 저장한다.
		Comment saved = commentRepository.save(comment);
		
//		저장된 Comment 엔티티 객체를 CommentDto 클래스 객체로 변환해서 리턴시킨다.
		return CommentDto.createCommentDto(saved);
	}

//	답변글 수정
//	답변글 수정에 실패하면 실행전 상태로 되돌려야 하므로 트랜잭션 처리를 한다.
	@Transactional
	public CommentDto update(Long id, CommentDto commentDto) {
		log.info("CommentService의 update() 메소드 실행");
//		log.info("id: {}, commentDto: {}", id, commentDto);
		
//		수정할 답변글이 없으면 예외를 발생시킨다.
		Comment comment = commentRepository.findById(id).orElseThrow(
			() -> new IllegalArgumentException("답변글 수정 실패!!! 수정할 답변글이 없습니다.")
		);
		
//		답변글 엔티티를 수정한다.
		comment.updateComment(commentDto);
//		답변글 엔티티를 테이블에 저장한다.
		Comment updated = commentRepository.save(comment);

//		수정된 Comment 엔티티 객체를 CommentDto 클래스 객체로 변환해서 리턴시킨다.
		return CommentDto.createCommentDto(updated);
	}

//	답변글 삭제
//	답변글 삭제에 실패하면 실행전 상태로 되돌려야 하므로 트랜잭션 처리를 한다.
	@Transactional
	public CommentDto delete(Long id) {
		log.info("CommentService의 delete() 메소드 실행");
//		log.info("id: " + id);
		
//		삭제할 답변글이 없으면 예외를 발생시킨다.
		Comment comment = commentRepository.findById(id).orElseThrow(
			() -> new IllegalArgumentException("답변글 삭제 실패!!! 삭제할 답변글이 없습니다.")
		);
		
//		답변글을 삭제한다.
		commentRepository.delete(comment);
		
//		삭제된 Comment 엔티티 객체를 CommentDto 클래스 객체로 변환해서 리턴시킨다.
		return CommentDto.createCommentDto(comment);
	}
	
	
	
}


















