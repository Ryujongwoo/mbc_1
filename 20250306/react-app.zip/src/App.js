import logo from './logo.svg';
import './App.css';

// 사용자 정의 컴포넌트(사용자 정의 함수, 이하 컴포넌트)를 만든다.
// 컴포넌트 이름은 반드시 대문자로 시작해야 한다.
// 컴포넌트의 인수로 컴포넌트가 호출될 때 전달되는 데이터(prop)를 받는다.
// 인수 이름은 props라고 지정했는데 인수 이름은 반드시 props라고 할 필요는 없다.
// 남들다 props로 하니까 우리도 props라고 했다.
function Header(props) {
  // props로 넘어온 속성에 할당된 속성 값은 '.'을 찍어서 얻어온다.
  console.log(`props: ${props}, props.title: ${props.title}`)
  // 컴포넌트는 반드시 html 코드를 return 시켜야 한다.
  return (
    <header>
      {/* props로 넘어온 데이터를 사용하려면 {}로 묶어준다. */}
      <h1><a href='/'>{props.title}{props.subject}</a></h1>
    </header>
  )
}

function Nav() {
  return (
    <nav>
      <ol>
        <li><a href='/read/1'>html</a></li>
        <li><a href='/read/2'>css</a></li>
        <li><a href='/read/3'>js</a></li>
      </ol>
    </nav>
  )
}

function Article() {
  return (
    <article>
      <h2>Welcome</h2>
      Hello, WEB
    </article>
  )
}

function App() {
  return (
    <div className="App">
      {/*
      html 태그는 속성을 가지고 있다.
      컴포넌트도 html 태그처럼 속성을 지정할 수 있다. 이를 prop이라 한다.
      */}
      <Header title="React"></Header>
      <Header title="Node.js"></Header>
      <Header subject="밥먹자"></Header>
      <Nav />
      <Article />
    </div>
  );
}

export default App;

