package com.mbcit.springBootReact02.domain;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.context.SpringBootTest;

//	JPA 컴포넌트 중심의 테스트에는 @SpringBootTest 어노테이션 대신에 @DataJpaTest 어노테이션을
//	이용할 수 있다.
@DataJpaTest
class OwnerRepositoryTest {
	
	@Autowired
	private OwnerRepository ownerRepository;

//	데이터베이스에 새 소유자를 추가하는 기능을 테스트하는 테스트 케이스
	@Test
	void saveOwner() {
		ownerRepository.save(new Owner("권", "예린"));
		assertThat(ownerRepository.findByFirstname("권").isPresent()).isTrue();
	}
	
//	데이터베이스에서 소유자를 삭제하는 테스트 케이스
	@Test
	public void deleteOwners() {
		ownerRepository.deleteAll();
		assertThat(ownerRepository.count()).isEqualTo(0);
	}

}
