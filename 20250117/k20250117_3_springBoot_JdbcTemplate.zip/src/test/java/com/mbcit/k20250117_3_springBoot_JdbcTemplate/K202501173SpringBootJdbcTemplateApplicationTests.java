package com.mbcit.k20250117_3_springBoot_JdbcTemplate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class K202501173SpringBootJdbcTemplateApplicationTests {

	@Test
	void contextLoads() {
	}

}
