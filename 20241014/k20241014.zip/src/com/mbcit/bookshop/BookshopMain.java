package com.mbcit.bookshop;

import java.util.Date;

public class BookshopMain {

	public static void main(String[] args) {
		
//		클래스이름 객체(변수)이름 = new 생성자();
		BookVO vo = new BookVO(); // 기본 생성자로 BookVO 클래스의 객체를 만든다.
//		System.out.println(vo.title); // private 권한으로 선언된 변수에 직접 접근하면 에러가 발생된다.
		System.out.println(vo.toString());
//		클래스로 만든 객체를 출력하면 자동으로 toString() 메소드가 실행된다.
		System.out.println(vo);
		System.out.println("====================================");
		
//		도서 정보를 만든다.
//		출판일을 날짜 데이터를 만들어서 BookVO 클래의 date 멤버 변수에 넣어주면 다른곳에서 사용할 일이없다.
//		Date date = new Date(2020, 5, 15);
//		BookVO book1 = new BookVO("java", "홍길동", "MBC 출판사", date, 145.55);
//		이럴 경우 익명 객체를 만들어 사용한다.
		BookVO book1 = new BookVO("java", "홍길동", "MBC 출판사", new Date(2020, 5, 15), 145.55);
		System.out.println("book1: " + book1);
		BookVO book2 = new BookVO("java", "홍길동", "MBC 출판사", new Date(2020, 5, 15), 145.55);
		System.out.println("book2: " + book2);
		
//		private 권한으로 선언된 필드에 접근하려면 getters & setters 메소드를 만들어 사용한다.
//		System.out.println(book1.getTitle());
//		book1.setTitle("spring");
//		System.out.println(book1);
		
//		"=="을 사용해서 같은지 비교할 수 있는 데이터는 기본 자료형 7가지와 null만 가능하다.
//		클래스로 만든 객체는 "=="을 사용해서 비교하면 안된다. => 데이터가 아닌 데이터가 생성된 주소를 비교한다.
		if (book1 == book2) {
			System.out.println("같다");
		} else {
			System.out.println("다르다");
		}
		
//		문자열도 클래스이므로 "=="을 사용하면 안된다. => equals() 메소드를 사용한다.
		if (book1.getAuthor().equals(book2.getAuthor())) {
			System.out.println("같다");
		} else {
			System.out.println("다르다");
		}
		
//		BookVO도 클래스이므로 "=="을 사용하면 안된다. => equals() 메소드를 사용한다.
		if (book1.equals(book2)) {
			System.out.println("같다");
		} else {
			System.out.println("다르다");
		}
		
	}
	
}














