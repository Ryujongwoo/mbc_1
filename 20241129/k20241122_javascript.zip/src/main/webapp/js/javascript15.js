const purpleCuteSlime = {
	name: '슬라임',
	attribute: 'cute',
	color: 'purple'
}
console.log(purpleCuteSlime);

//	rest: spread와 반대로 퍼져있는 것을 모아준다. 연산자는 spread와 같이 '...'을 사용한다.
//	객체에 rest를 사용할 때는 뽑아낸 값을 저장할 변수 이름이 객체를 구성하는 key와 반드시 같아야 한다.
//	지정된 속성을 제외한 나머지 속성이 rest 연산자를 사용한 객체에 저장되므로 rest 연산자는 맨 마지막에 딱 1번만
//	사용할 수 있다. => 함수의 가변인자에 rest 연산자가 사용된다.

//	console.log(purpleCuteSlime.color); // 객체이름.key
//	console.log(purpleCuteSlime['color']); // 객체이름[key]
//	purpleCuteSlime 객체에서 key가 color인 value 값을 얻어오고 나머지 key는 무시한다.
//	let {color} = purpleCuteSlime; // 객체 구조 분해
//	purpleCuteSlime 객체에서 key가 color인 value 값을 얻어오고 나머지 rest 연산자를 사용한 객체로 모아준다.
const {color, ...cuteSlime} = purpleCuteSlime;
console.log(color);
console.log(cuteSlime);

const {attribute, ...slime} = cuteSlime;
console.log(attribute);
console.log(slime);
console.log('1. =================================');

const numbers = [999, 1, 2, 3, 4, 5, 6];

//	객체는 데이터가 할당된 key가 있기때문에 변수 이름을 key와 똑같이 작성하면 되고
//	배열은 key가 존재하지 않기 때문에 변수 이름은 어떤 이름을 써도 상관없고 인덱스 순서대로 값을 얻을 수 있다.

const [a, b, ...c] = numbers;
console.log(a);
console.log(b);
console.log(c);
console.log('2. =================================');

//	spread와 rest를 사용한 합계를 계산하는 함수
function sum(...rest) {
	console.log(rest); // [[999, 1, 2, 3, 4, 5, 6]]
	console.log(typeof rest);
	console.log(rest.length); // 1
	console.log(rest[0].length); // 7
	
	let total = 0;
	for (let i = 0; i < rest[0].length; i++) {
		total += rest[0][i];
	}
	return total;
}

//	[999, 1, 2, 3, 4, 5, 6] 배열 1개를 sum 함수의 인수로 전달한다.
console.log(`합계: ${sum(numbers)}`);
console.log('3. =================================');

function sum2(...rest) {
	console.log(rest); // [999, 1, 2, 3, 4, 5, 6]
	console.log(typeof rest);
	console.log(rest.length); // 7
	
	let total = 0;
	for (let i = 0; i < rest.length; i++) {
		total += rest[i];
	}
	return total;
}

//	[999, 1, 2, 3, 4, 5, 6] 배열을 spread로 999, 1, 2, 3, 4, 5, 6 형태로 풀어서 sum 함수의 인수로 전달한다.
console.log(`합계: ${sum2(...numbers)}`); // spread
console.log('4. =================================');

function sum3(...rest) {
	/*
	function total(acc, value) {
		// console.log(acc, value);
		return acc + value;
	}
	return rest.reduce(total, 0);
	*/
	/*
	return rest.reduce(function (acc, value) {
				return acc + value;
			}, 0);
	*/
	return rest.reduce((acc, value) => acc + value, 0);
}

console.log(`합계: ${sum3(...numbers)}`);
console.log('5. =================================');

//	spread와 rest를 사용한 최대값을 계산하는 함수

function maxValue(...values) {
	/*
	function big(acc, curr) {
		// console.log(acc, curr);
		if (acc < curr) {
			return curr;
		} else {
			return acc;
		}
	}
	return values.reduce(big, values[0]);
	*/
	/*
	return values.reduce(function (acc, curr) {
				if (acc < curr) {
					return curr;
				} else {
					return acc;
				}
			}, values[0]);
	*/
//	reduce 함수가 실행할 함수의 accumulator에 들어갈 초기값을 생략하면 reduce 함수가 실행될 배열의 0번째 
//	인덱스의 값이 초기값으로 들어간다.
//	return values.reduce((acc, curr) => acc < curr ? curr : acc, values[0]);
	return values.reduce((acc, curr) => acc < curr ? curr : acc);
}

console.log(`최대값: ${maxValue(...numbers)}`);
console.log('6. =================================');

