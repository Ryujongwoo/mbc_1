function tableAdd() {
	/*
	let id = document.getElementsByName('id')[0];
	let password = document.getElementsByName('password')[0];
	let address = document.getElementsByName('address')[0];
	let phoneNumber = document.getElementsByName('phoneNumber')[0];
	console.log('id: ' + id.value);
	console.log('password: ' + password.value);
	console.log('address: ' + address.value);
	console.log('phoneNumber: ' + phoneNumber.value);
	*/

//	데이터가 입력된 form을 얻어와서 form에 입력된 데이터를 배열에 저장해서 처리한다.
//	let form = document.getElementsByTagName('form')[0];
//	let form = document.querySelectorAll('form')[0];
//	forms: 현재 문서의 모든 form을 배열 형태로 저장하고 있는 자바스크립트 객체
//	console.log(document.forms);
//	console.log(document.forms[0]);
	let form = document.forms[0];

//	console.log(form);
//	console.log(form.id);
//	form이저장된변수.name속성값.value: form에서 지정된 name 속성 값을 가지는 요소에 접근한다.
//	console.log('id: ' + form.id.value);
//	console.log('password: ' + form.password.value);
//	console.log('address: ' + form.address.value);
//	console.log('phoneNumber: ' + form.phoneNumber.value);
	
	const values = [form.id.value, form.password.value, form.address.value, form.phoneNumber.value];
//	console.log(values);

//	form에 데이터가 모두 입력되었나 확인한다.
	for (let i = 0; i < values.length; i++) {
		let value = values[i];
		if (value == null || value.trim() == '' || value == undefined) {
			switch (i) {
				case 0:
					alert('아이디를 입력하세요');
					form.id.value = '';
					form.id.focus();
					// id에 오류가 발생했으므로 tableAdd 함수를 종료한다.
					return;
				case 1:
					alert('비밀번호를 입력하세요');
					form.password.value = '';
					form.password.focus();
					// password에 오류가 발생했으므로 tableAdd 함수를 종료한다.
					return;
				case 2:
					alert('주소를 입력하세요');
					form.address.value = '';
					form.address.focus();
					// address에 오류가 발생했으므로 tableAdd 함수를 종료한다.
					return;
				case 3:
					alert('전화번호를 입력하세요');
					form.phoneNumber.value = '';
					form.phoneNumber.focus();
					// phoneNumber에 오류가 발생했으므로 tableAdd 함수를 종료한다.
					return;
			}
		}
	}
	
//	배열에 저장된 데이터를 id 속성 값이 resultTable인 테이블에 추가한다.
//	id 속성 값이 addtr인 <tbody> 태그를 얻어온다.
	let tbody = document.getElementById('addtr');
//	values 배열에 저장된 데이터를 사용해서 <tbody> 태그에 추가할 행(<tr> 태그)를 만드는 함수를
//	실행하고 함수가 리턴된 결과(<tr> 태그)를 <tbody> 태그에 데이터를 추가한다.
	tbody.appendChild(createRow(values));

//	테이블에 데이터를 추가한 후 다음 데이터를 입력받기 위해 텍스트 상자의 모든 내용을 제거한다.
	form.id.value = '';
	form.password.value = '';
	form.address.value = '';
	form.phoneNumber.value = '';
	form.id.focus();
}

//	addTable 함수에서 호출되는 <tbody> 태그에 추가할 데이터(values 배열)를 넘겨받아 <tr> 태그를 만들어서
//	리턴하는 함수
function createRow(values) {
//	console.log(values);
//	<tr> 태그를 만든다.
	let tr = document.createElement('tr'); // <tr></tr>
	
//	values 배열의 크기만큼 반복하며 <tr> 태그에 추가할 열(<td> 태그)을 만들어서 <tr> 태그에 넣어준다.
	for (let value of values) {
		// <td> 태그를 만든다.
		let td = document.createElement('td'); // <td></td>
		// <td> 태그에 데이터를 넣어준다.
		td.innerHTML = value; // <td>value</td>
		// <tr> 태그에 <td> 태그를 넣어준다.
		tr.appendChild(td);
	}
	
//	현재 데이터를 삭제하는 버튼을 <td> 태그에 만들어서 <tr> 태그에 추가한다.
	let td = document.createElement('td');
	td.innerHTML = `<input type="button" value="${values[0]} 데이터 삭제" onclick="removeCurrent(this)"/>`;
	tr.appendChild(td);
	
//	<tbody> 태그에 추가할 데이터(<tr> 태그)를 리턴한다.
	return tr;
}

function removeCurrent(removeBtn) {
//	console.log(removeBtn); // <input type="button"~ 클릭한 버튼 자신이 넘어온다.
//	console.log(removeBtn.parentNode); // <td> ~ </td>
//	console.log(removeBtn.parentNode.parentNode); // <tr> ~ </tr>
//	삭제할 행(<tr> 태그)을 선택한다.
	let tr = removeBtn.parentNode.parentNode;
//	<tbody> 태그의 자식인 <tr> 태그를 제거한다.
	let tbody = document.getElementById('addtr');
	tbody.removeChild(tr);
}

//	테이블의 마지막 행을 삭제하는 함수
function removeLast() {
//	<tbody> 태그를 선택해서 마지막 <tr> 태그를 제거한다.
	let tbody = document.getElementById('addtr');
	tbody.removeChild(tbody.lastChild);
}

//	테이블의 모든 행을 삭제하는 함수
function removeAll() {
//	<tbody> 태그를 선택해서 공백으로 채운다.
	let tbody = document.getElementById('addtr');
	tbody.innerHTML = '';
}

