import React, { useState } from "react";
import { AppBar, Container, Toolbar, Typography } from '@mui/material';
import './App.css';
import AddItem from "./AddItem";

// MUI(https://mui.com/)는 구글 머트리얼 디자인을 구현하는 리액트 컴포넌트 이다.
// MUI는 균일한 UI를 구현하는데 이용할 수 있는 다양한 컴포넌트가 포함되어 있다.

function App() {
  const [items, setItems] = useState([]);
  // 스프레드 표기법(...)을 이용해 기존 배열의 앞 부분에 새 항목을 추가한다.
  const addItem = function (item) {
    setItems([item, ...items]);
  }

  return (
    <div className="App">
      {/*
      Container는 MUI가 제공하는 기본 레이아웃 컴포넌트 이다.
      Container는 내용을 가운데 정렬할 수 있게 해주고 maxWidth prop으로 최대 너비를 지정할 수 있다.
      */}
      <Container>
        <AppBar position='static'>
          <Toolbar>
            <Typography variant='h6'>
              Shopping List
            </Typography>
          </Toolbar>
        </AppBar>
        <br />

        <AddItem />
      </Container>
    </div>
  );
}

export default App;
