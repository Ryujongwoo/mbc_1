package com.mbcit.k20250121_1_springBoot_JPA01.domain;

import java.time.LocalDateTime;

import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@NoArgsConstructor
@Data
@Entity
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class Book extends BaseEntity {

//	Book 엔티티를 ERD에 맞춰 수정한다.
	@Id
//	@GeneratedValue
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private String name;
//	private String author; // 제거
	private String category; // 추가
	private Long authorId; // 추가
	private Long publisherId; // 추가
//	createDate, updateDate는 BaseEntity에서 상속받아 사용한다.
//	private LocalDateTime createDate;
//	private LocalDateTime updateDate;
	
//	특별한 경우가 아니라면 1:1 연관 관계 설정은 단방향으로 걸어야 한다.
//	1:1 연관 관계를 설정해서 BookReviewInfo 엔티티를 직접 참조하게 설정한다.
	@OneToOne
//	@OneToOne(optional = true)
//	@OneToOne(optional = false)
//	mappedBy = "book" 옵션을 사용하면 Book 엔티티에서는 외래키를 생성하지 않는다.
//	@OneToOne(mappedBy = "book")
//	toString() 메소드에서 순환 참조 문제로 StachOverflowError가 발생되면 아래와 같이 toString() 메소드를
//	제외하고 실행하면 된다.
//	@ToString.Exclude // toString() 메소드를 제외시킨다.
	private BookReviewInfo bookReviewInfo; // 참조하게 될 엔티티 객체, 객체이름_id 필드가 자동으로 만들어진다.
	
}












