import React from "react";

function MyTable() {
  const data = [
    {brand: '기아', model: '레이'},
    {brand: '현대', model: '모닝'},
    {brand: '쉐보레', model: '스파크'},
  ];
  return (
    <div align='center'>
      <h1>MyTable</h1>
      <table border={1} cellSpacing={0} cellPadding={5}>
        <tbody>
          {
            data.map(function (item, index) {
              return (
                <tr key={index}>
                  <td>{item.brand}</td>
                  <td>{item.model}</td>
                </tr>
              );
            })
          }
        </tbody>
      </table>
    </div>
  );
}

export default MyTable;
