package com.mbcit.springBootBoard.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.mbcit.springBootBoard.entity.Comment;

public interface CommentRepository extends JpaRepository<Comment, Long> {

//	특정 질문글의 모든 댓글을 조회하는 메소드
//	@Query 어노테이션으로 sql 명령을 만들어 사용할 수 있다. nativeQuery
	@Query(value = "select * from comment where article_id = :articleId", nativeQuery = true)
//	@Query 어노테이션으로 작성할 nativeQuery를 실행할 추상 메소드를 만든다.
	List<Comment> findByArticleId(Long articleId);
	
//	특정 닉네임의 모든 댓글을 조회하는 메소드
//	@Query(value = "select * from comment where nickname = :nickname", nativeQuery = true)
//	ORM(Object Relational Mapping)은 객체와 관계형 데이터베이스의 데이터를 자동으로 매핑(연결)해주는
//	것을 말한다.
//	src/main/resources에 META-INF 폴더를 만들고 orm.xml 파일을 만들어서 sql 명령을 실행할 수 있다.
//	orm.xml 파일은 orm native query orm.xml example을 구글링해서 사용하면 된다.
	List<Comment> findByNickname(String nickname);
	
}
