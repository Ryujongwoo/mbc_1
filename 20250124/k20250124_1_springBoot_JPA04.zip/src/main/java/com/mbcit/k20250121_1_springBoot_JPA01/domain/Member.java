package com.mbcit.k20250121_1_springBoot_JPA01.domain;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Index;
import javax.persistence.PostLoad;
import javax.persistence.PostPersist;
import javax.persistence.PostRemove;
import javax.persistence.PostUpdate;
import javax.persistence.PrePersist;
import javax.persistence.PreRemove;
import javax.persistence.PreUpdate;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.persistence.UniqueConstraint;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@NoArgsConstructor
@AllArgsConstructor
@RequiredArgsConstructor
@Data
@Builder
@Entity
@SequenceGenerator(name = "seq_generator", sequenceName = "member_id_seq", initialValue = 1, allocationSize = 1)
public class Member {

	@Id
//	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_generator")
	private Long id;
	
	@NonNull
	private String name;
	@NonNull
	private String email;
	private LocalDateTime createDate;
	private LocalDateTime updateDate;
	
//	JPA가 제공하는 엔티티 이벤트는 7가지가 있다.
//	@PrePersist 어노테이션을 붙여 선언한 메소드는 엔티티가 영속화(presist, insert)되기 전 자동으로 실행된다.
	@PrePersist
	public void prePersist() { // 메소드 이름은 상관없다.
		System.out.println("prePersist() 메소드가 실행됨");
		createDate = LocalDateTime.now();
		updateDate = LocalDateTime.now();
	}
	
//	@PostPersist 어노테이션을 붙여 선언한 메소드는 엔티티가 영속화된 후 자동으로 실행된다.
	@PostPersist
	public void postPersist() {
		System.out.println("postPersist() 메소드가 실행됨");
	}
	
//	@PostLoad 어노테이션을 붙여 선언한 메소드는 엔티티가 load(select)된 후 자동으로 실행된다.
	@PostLoad
	public void postLoad() {
		System.out.println("postLoad() 메소드가 실행됨");
	}
	
//	@PreUpdate 어노테이션을 붙여 선언한 메소드는 엔티티가 update되기 전 자동으로 실행된다.
	@PreUpdate
	public void preUpdate() {
		System.out.println("preUpdate() 메소드가 실행됨");
		updateDate = LocalDateTime.now();
	}
	
//	@PostUpdate 어노테이션을 붙여 선언한 메소드는 엔티티가 update된 후 자동으로 실행된다.
	@PostUpdate
	public void postUpdate() {
		System.out.println("postUpdate() 메소드가 실행됨");
	}
	
//	@PreRemove 어노테이션을 붙여 선언한 메소드는 엔티티가 delete되기 전 자동으로 실행된다.
	@PreRemove
	public void preRemove() {
		System.out.println("preRemove() 메소드가 실행됨");
	}
	
//	@PostRemove 어노테이션을 붙여 선언한 메소드는 엔티티가 deletee된 후 자동으로 실행된다.
	@PostRemove
	public void postRemove() {
		System.out.println("postRemove() 메소드가 실행됨");
	}
	
}




















