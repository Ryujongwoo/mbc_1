package com.mbcit.k20250116_4_springBoot_Form;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class HomeController {

	@RequestMapping("/")
	public @ResponseBody String home() {
		System.out.println("HomeController 클래스의 home() 메소드 실행");
		return "Form 데이터 전송받아 사용하기";
	}
	
	@RequestMapping("/formTest")
	public String formTest() {
		System.out.println("HomeController 클래스의 formTest() 메소드 실행");
		return "formTest";
	}
	
	@RequestMapping("/formTest1")
//	formTest1 요청이 들어올 때 넘어오는 데이터를 HttpServletRequest 인터페이스 객체로 받는다.
//	HttpServletRequest 인터페이스 객체에서 파라미터 이름으로 전달된 데이터를 추출한다.
//	JSP/Servlet에서 사용하는 전형적인 방식이다.
	public String formTest1(HttpServletRequest request, Model model) {
		System.out.println("HomeController 클래스의 formTest1() 메소드 실행");
		
		String id = request.getParameter("id");
		String name = request.getParameter("name");
		
		model.addAttribute("id", id);
		model.addAttribute("name", name);
		
		return "formTest1";
	}
	
	@RequestMapping("/formTest2")
//	@RequestParam 어노테이션으로 파라미터 이름으로 전달된 데이터를 변수에 직접 넣어준다.
//	파라미터가 많아지면 불편하고 @RequestParam 어노테이션으로 지정한 파라미터에 데이터가 넘어오지
//	않으면 에러가 발생된다.
	public String formTest2(@RequestParam("id") String id, @RequestParam("name") String name, Model model) {
		System.out.println("HomeController 클래스의 formTest2() 메소드 실행");
		
		model.addAttribute("id", id);
		model.addAttribute("name", name);
		
		return "formTest2";
	}
	
	@RequestMapping("/formTest3")
//	커맨드 객체를 사용하면 쉽고 편리하게 많은 데이터를 받아서 처리할 수 있다.
//	커맨드 객체 자체를 Model 인터페이스 객체에 저장해서 viewpage로 전달한다.
	public String formTest3(Member member, Model model) {
		System.out.println("HomeController 클래스의 formTest3() 메소드 실행");
		System.out.println(member);
		return "formTest3";
	}
	
	@RequestMapping("/formTest4/{id}/{name}")
//	컨트롤러에 요청하는 패스(경로) 자체에 데이터를 받아서 처리할 수 있다.
//	패스에 지정되서 넘어오는 데이터를 받으려면 @PathVariable 어노테이션을 사용한다.
	public String formTest4(@PathVariable String id, @PathVariable String name, Model model) {
		System.out.println("HomeController 클래스의 formTest4() 메소드 실행");
		
		model.addAttribute("id", id);
		model.addAttribute("name", name);
		
		return "formTest4";
	}
	
}

















