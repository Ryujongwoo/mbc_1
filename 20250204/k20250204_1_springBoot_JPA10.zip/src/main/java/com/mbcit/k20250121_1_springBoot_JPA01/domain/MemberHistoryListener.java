package com.mbcit.k20250121_1_springBoot_JPA01.domain;

import javax.persistence.PostPersist;
import javax.persistence.PostUpdate;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;

import org.springframework.beans.factory.annotation.Autowired;

import com.mbcit.k20250121_1_springBoot_JPA01.repository.MemberHistoryRepository;
import com.mbcit.k20250121_1_springBoot_JPA01.support.BeanUtils;

public class MemberHistoryListener {

	private MemberHistoryRepository memberHistoryRepository;
	
//	@PrePersist
//	@PreUpdate
//	insert, update sql 명령 실행 후 자동으로 실행되도록 @PrePersist 어노테이션을 @PostPersist로
//	@PreUpdate 어노테이션을 @PostUpdate로 수정한다.
	@PostPersist
	@PostUpdate
	public void prePersistAndPreUpdate(Object object) {
		System.out.println("MemberHistoryListener 리스너의 prePersistAndPreUpdate() 메소드 실행됨");
		memberHistoryRepository = BeanUtils.getBean(MemberHistoryRepository.class);
		System.out.println("memberHistoryRepository: " + memberHistoryRepository);
		
		Member member = (Member) object;
		MemberHistory memberHistory = new MemberHistory();
		memberHistory.setMemberId(member.getId());
		memberHistory.setName(member.getName());
		memberHistory.setEmail(member.getEmail());
		
//		N:1 연관 관계를 설정하기 위해 추가한 MemberHistory 엔티티 객체(member)에 Member 엔티티
//		객체를 넣어준다.
		memberHistory.setMember(member);
		
		memberHistoryRepository.save(memberHistory);
	}
	
}












