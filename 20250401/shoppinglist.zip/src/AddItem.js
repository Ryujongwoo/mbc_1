import { Button, Dialog, DialogActions, DialogContent, DialogTitle, TextField } from "@mui/material";
import React, { useState } from "react";

// AddItem 컴포넌트는 App 컴포넌트에서 호출될 때 쇼핑 목록을 추가하는 함수를 prop으로 받는다.
function AddItem(props) {

  // 모달 대화상자는 처음에는 닫혀잏어야 하므로 open 상태는 false로 초기화 한다.
  const [open, setOpen] = useState(false);
  // open이라는 상태와 모달 대화상자를 여는 함수와 닫는 함수를 선언한다.
  // handleOpen 함수는 open 상태를 true로 변경한다.
  const handleOpen = () => setOpen(true);
  // handleClose 함수는 open 상태를 false로 변경한다.
  const handleClose = () => setOpen(false);

  // product와 amount를 기억하는 상태를 선언한다.
  const [item, setItem] = useState({product: '', amount: ''});
  // TextField에 값을 입력하면 item 상태값을 수정하는 함수를 선언한다.
  const handleChange = event => setItem({...item, [event.target.name]: event.target.value});
  
  const addItem = function () {
    // TextField에 입력된 값을 prop으로 넘겨받은 함수를 실행해서 쇼핑 목록에 추가한다.
    props.addItem(item);
    // TextField에 입력된 값을 지운다.
    setItem({product: '', amount: ''});
    // 모달 대화상자를 닫는다.
    handleClose();
  }

  return (
    <div>
      <Button onClick={handleOpen} variant="outlined">Add Item</Button>
      <Dialog open={open} onClose={handleClose}>
        <DialogTitle>New Item</DialogTitle>
        <DialogContent>
          <TextField fullWidth label="Product" margin="dense" name="product"
            value={item.product} onChange={handleChange}/>
          <TextField fullWidth label="Amount" margin="dense" name="amount"
            value={item.amount} onChange={handleChange}/>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleClose}>Cancel</Button>
          <Button onClick={addItem}>Add</Button>
        </DialogActions>
      </Dialog>
    </div>
  )
}

export default AddItem;
