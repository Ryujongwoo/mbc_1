package com.mbcit.springDI_xml_namespace;

public class Family {

	private String papaname;
	private String maminame;
	private String sistername;
	private String brothername;
	
	public Family() { }
	public Family(String papaname, String maminame) {
		this.papaname = papaname;
		this.maminame = maminame;
	}
	
	public String getPapaname() {
		return papaname;
	}
	public void setPapaname(String papaname) {
		this.papaname = papaname;
	}
	public String getMaminame() {
		return maminame;
	}
	public void setMaminame(String maminame) {
		this.maminame = maminame;
	}
	public String getSistername() {
		return sistername;
	}
	public void setSistername(String sistername) {
		this.sistername = sistername;
	}
	public String getBrothername() {
		return brothername;
	}
	public void setBrothername(String brothername) {
		this.brothername = brothername;
	}
	
	@Override
	public String toString() {
		return "Family [papaname=" + papaname + ", maminame=" + maminame + ", sistername=" + sistername
				+ ", brothername=" + brothername + "]";
	}
	
}
