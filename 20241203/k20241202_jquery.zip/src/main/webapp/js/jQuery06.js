$(() => {
//	id 속성 값이 errorMsg로 지정된 span 태그(에러 메시지)를 숨긴다.
	$('#errorMsg').hide();
//	id 속성 값이 userID로 지정된 텍스트 상자에 포커스를 위치시킨다.
	$('#userID').focus();
	
	$('#single').submit(function () {
		alert('submit 버튼을 클리했습니다.');
	});
});



