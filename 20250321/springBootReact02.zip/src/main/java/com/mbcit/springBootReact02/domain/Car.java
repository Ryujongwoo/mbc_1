package com.mbcit.springBootReact02.domain;

import javax.persistence.Column;
//	springBoot 3.x 버전은 패키지 이름이 javax 대신 jakarta가 사용된다.
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

//	엔티티 클래스를 만들려면 @Entity 어노테이션을 지정해야 한다.
@Entity
public class Car {

//	엔티티 클래스는 기본키로 사용되는 고유한 id를 반드시 포함해야 한다.
//	기본키는 @Id 어노테이션으로 정의한다.
	@Id
//	@GeneratedValue 어노테이션은 id 자동 증가 방식을 지정한다.
//	AUTO는 JPA 공급자가 특정 데이터베이스에 가장 적합한 전략을 선택한다.
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;
	private String brand;
	private String model;
	private String color;
	private String registerNumber;
//	데이터베이스 열의 이름은 기본적으로 클래스 명명 규칙에 따라 지정된다.
//	다른 명명 규칙 적용하려면 @Column 어노테이션을 사용하면 된다.
//	@Column 어노테이션으로 열의 길이와 null 허용 여부를 지정할 수 있다.
//	이 정의에서 데이터베이스에 있는 열의 이름은 explanation이고, 열의 길이는 512 바이트 이며,
//	null 값을 허용하지 않는다.
//	@Column(name = "explanation", nullable = false, length = 512)
//	private String description;
//	JPA와 사전에 약속된 이름을 필드 이름으로 사용하고 싶은 경우에도 @Column 어노테이션을 사용한다.
//	이때, name 속성값으로 지정하는 필드 이름은 백틱(`)을 사용해서 묶어주면 된다.
	@Column(name = "`year`")
	private int year;
	private int price;
	
//	관계 설정을 위한 필드(외래키) 정의
//	외래키가 있어야하는 Car 엔티티 클래스에서는 @ManyToOne 어노테이션으로 관계를 정의해야 한다.
//	모든 연관관계에는 FetchType.LAZY를 사용하는 것이 좋다.
//	ToMany 관계에서는 FetchType.LAZY가 기본값으로 사용되므로 정의할 필요가 없지만 ToOne 관계에서는
//	정의해야 한다.
//	FetchType은 데이터베이스에서 데이터를 검색하는 전략을 정의한다.
//	지정 가능한 값은 즉시 검색을 의미하는 EAGER 또는 지연 검색을 의미하는 LAZY일 수 있다.
//	지연 검색은 데이터베이스에서 소유자를 검색하면 필요할 때 해당 소유자와 연관된 모든 자동차를
//	검색한다는 뜻이다. 반면에 즉시 검색은 해당 소유자의 모든 자동차를 즉시 검색한다.
	@ManyToOne(fetch = FetchType.LAZY)
//	@JoinColumn 어노테이션의 name 속성에는 대상 엔티티를 매핑하기 위해 조인할 컬럼 이름을 지정하는
//	것이 아니고 대상 엔티티와 매핑할 외래키(자기 필드명) 이름을 지정한다.
//	조인할 컬럼 이름(외래키가 참조하는 대상 테이블의 컬럼명)은 referencedColumnName 속성을 사용한다.
	@JoinColumn(name = "owner")
	private Owner owner; // 외래키
	
	public Car() { }
	public Car(String brand, String model, String color, String registerNumber, int year, int price,
			Owner owner) {
		this.brand = brand;
		this.model = model;
		this.color = color;
		this.registerNumber = registerNumber;
		this.year = year;
		this.price = price;
		this.owner = owner;
	}
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getBrand() {
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public String getRegisterNumber() {
		return registerNumber;
	}
	public void setRegisterNumber(String registerNumber) {
		this.registerNumber = registerNumber;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	
//	관계 설정을 위해 정의한 필드에 대한 getter와 setter를 추가한다.
	public Owner getOwner() {
		return owner;
	}
	public void setOwner(Owner owner) {
		this.owner = owner;
	}
	
//	관계 설정을 위해 정의한 필드가 추가된 toString() 메소드를 다시 Override 한다.
	@Override
	public String toString() {
		return "Car [id=" + id + ", brand=" + brand + ", model=" + model + ", color=" + color + ", registerNumber="
				+ registerNumber + ", year=" + year + ", price=" + price + ", owner=" + owner.getLastname() + "]";
	}
	
}













