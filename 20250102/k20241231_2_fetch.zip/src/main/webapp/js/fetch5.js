function fetchAJAX(pagename) {
	fetch(pagename)
		.then(response => {
			if (response.status == 200) {
				response.text()
					.then(data => document.querySelectorAll('div')[0].innerHTML = data)
			} else {
				alert('요청 실패!!!')
			}
		})
}

//	페이지가 로드되거나 새로고침 될 때 해시가 없으면 summary 파일에 저장된 내용을 표시하고
//	해시가 있으면 지정된 파일의 내용을 표시한다.

//	javascript
/*
onload = () => {
//	location.hash: 클릭한 하이퍼링크에 붙여준 해시를 얻어온다.
//	console.log('location.hash: ' + location.hash)
	if (!location.hash) { // 해시가 있는가?
		fetchAJAX('summary')
	} else {
		fetchAJAX(location.hash.substring(2))
	}
}
*/

// jQuery
$(() => {
	if (!location.hash) {
		fetchAJAX('summary')
	} else {
		fetchAJAX(location.hash.substring(2))
	}
	
//	list 파일의 내용을 읽어서 <ol id="list"> ~ </ol> 사이에 넣어주는 fetch
	/*
	fetch('list')
		.then(response => {
			if (response.status == 200) {
				response.text()
					.then(text => $('#list').html(text))
			} else {
				alert('요청 실패!!!')
			}
		})
	*/
	
//	then() 함수 내부에 then() 함수가 또 나오는 기법을 nested라 한다.
//	fetch('list').then(response => response.text().then(text => $('#list').html(text)))

//	then() 함수가 리턴한 결과를 then() 함수 외부에서 다른 then() 함수가 받아서 처리하는 기법을 chaining이라 한다.
	fetch('list')
		.then(response => response.text())
		.then(text => $('#list').html(text))

//	list2 파일의 내용을 읽어서 <ol id="list"> ~ </ol> 사이에 넣어주는 fetch => nested
	/*
	fetch('list2')
		.then(response => {
			// console.log(response.text())
			response.text()
				.then(text => {
					// console.log(text)
					// split() 함수를 이용해서 ','를 경계로 문자열을 분리해서 배열로 리턴한다.
					let obj = text.split(',')
					// console.log(obj)
					// <ol> 태그 내부에 넣어줄 태그 목록을 만든다.
					// <li><a href="#!1" onclick="fetchAJAX('1')">1절 가사</a></li>
					let items = ''
					for (let i = 1; i <= obj.length; i++) {
						// let item = '<li><a href="#!' + i + '" onclick="fetchAJAX(\'' + i + '\')">' + obj[i - 1] + '</a></li>'
						let item = `<li><a href="#!${i}" onclick="fetchAJAX('${i}')">${obj[i - 1]}</a></li>`
						// console.log(item)
						items += item
					}
					$('#list2').html(items)
				})
		})
	*/
	/*
	fetch('list2')
		.then(response => {
			response.text()
				.then(text => {
					let obj = text.split(',')
					let items = ''
					for (let i = 1; i <= obj.length; i++) {
						let item = `<li><a href="#!${i}" onclick="fetchAJAX('${i}')">${obj[i - 1]}</a></li>`
						items += item
					}
					$('#list2').html(items)
				})
		})
	*/
	
//	list2 파일의 내용을 읽어서 <ol id="list"> ~ </ol> 사이에 넣어주는 fetch => chaining
	/*
	fetch('list2')
		.then(response => {
			return response.text()
		})
		.then(text => {
			let obj = text.split(',')
			let items = ''
			for (let i = 1; i <= obj.length; i++) {
				let item = `<li><a href="#!${i}" onclick="fetchAJAX('${i}')">${obj[i - 1]}</a></li>`
				items += item
			}
			$('#list2').html(items)
		})
	*/
	fetch('list2')
		.then(response => response.text())
		.then(text => {
			let obj = text.split(',')
			let items = ''
			for (let i = 1; i <= obj.length; i++) {
				let item = `<li><a href="#!${i}" onclick="fetchAJAX('${i}')">${obj[i - 1]}</a></li>`
				items += item
			}
			$('#list2').html(items)
		})
})






















