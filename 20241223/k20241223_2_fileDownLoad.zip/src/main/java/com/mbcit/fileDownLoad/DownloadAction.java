package com.mbcit.fileDownLoad;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//	브라우저 주소 창에 contextPath(프로젝트 이름) 뒤에 @WebServlet 어노테이션의 인수로 지정된 
//	요청(/DownloadAction)이 들어오면 즉, "/k20241223_2_fileDownLoad" 뒤에 "/DownloadAction"가 붙어서
//	"/k20241223_2_fileDownLoad/DownloadAction" 처럼 요청되면 @WebServlet("/DownloadAction") 어노테이션이
//	붙어있는 클래스의 doGet() 또는 doPost() 메소드가 자동으로 실행된다.
@WebServlet("/DownloadAction")
public class DownloadAction extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public DownloadAction() {
		super();
	}

//	서블릿이 get 방식으로 요청될 때 자동으로 실행되는 메소드
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		System.out.println("DownloadAction 서블릿의 doGet() 메소드 실행");
	}

//	서블릿이 post 방식으로 요청될 때 자동으로 실행되는 메소드
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		System.out.println("DownloadAction 서블릿의 doPost() 메소드 실행");
	}

}
