//	onload 이벤트에서 함수를 할당한다.
//	현재 페이지의 모든 내용이 브라우저에 렌더링된 후 onload 이벤트가 실행된다.
onload = function () {
//	alert('꺄~~~~~~~~~~~~~');
//	<button> 태그를 찾아서 onclick 이벤트에 함수를 할당한다.
//	이벤트에서 함수를 할당하기 때문에 함수 이름뒤에 ()를 입력하면 자동 실행 함수로 인식해서 페이지가 렌더링된 후
//	자동으로 실행되기 때문에 자동으로 실행되면 안되는 함수는 함수 이름뒤에 ()를 입력하지 않는다.
	document.getElementsByTagName('button')[0].onclick = testDate1;
	document.getElementsByTagName('button')[1].onclick = testDate2;
	document.getElementsByTagName('button')[2].onclick = testDate3;
	document.getElementsByTagName('button')[3].onclick = testDate4;
	document.getElementsByTagName('button')[4].onclick = testDate5;
}

function testDate1() {
//	alert('testDate1() 함수가 실행됩니다.');
//	현재 컴퓨터 시스템의 날짜와 시간을 가져온다.
	let date = new Date();
	console.log(date);
	
	let today = document.getElementsByClassName('today');
	today[0].innerHTML = date; // Thu Nov 28 2024 14:29:27 GMT+0900 (한국 표준시)
	today[1].innerHTML = date.toDateString(); // Thu Nov 28 2024
	today[2].innerHTML = date.toLocaleString(); // 2024. 11. 28. 오후 2:32:25
	today[3].innerHTML = date.toLocaleDateString(); // 2024. 11. 28.
	today[4].innerHTML = date.toLocaleTimeString(); // 오후 2:33:03
}

function testDate2() {
	let date = new Date();
	
//	let year = date.getYear() + 1900; // 년, 얻어올 때는 1900을 더해야 한다.
	let year = date.getFullYear(); // 년, 얻어올 때 1900을 더할 필요없다.
	let month = date.getMonth() + 1; // 월, 얻어올 때는 1을 더해야 한다.
	let day = date.getDate(); // 일
	let week = date.getDay(); // 요일, 일요일(0), 월요일(1), ..., 금요일(5), 토요일(6)
	let hour = date.getHours(); // 시
	let minute = date.getMinutes() // 분
	let second = date.getSeconds(); // 초
	let milliSecond = date.getMilliseconds(); // 밀리초
	
	
	let weekDay = ['일', '월', '화', '수', '목', '금', '토'];
	let now = `${year}.${month}.${day}(${weekDay[week]}) ${hour}:${minute}:${second}.${milliSecond}`;
	console.log(now);
	
	let today = document.getElementsByClassName('today');
	today[5].innerHTML = now;
}

function testDate3() {
	let year = 2025;
	let month = 4;
	let day = 8;
	
	let specific = document.getElementsByClassName('specific');
	
//	Date 객체를 만들 때 인수로 년, 월, 일, 시, 분, 초를 넣어주면 날짜 및 시간 데이터를 만들 수 있다.
//	Date(년, 월, 일)
	let date = new Date(year, month - 1, day); // 월을 넣어줄 때는 1을 빼서 넣어준다.
	console.log(date);
	specific[0].innerHTML = date;
	
	date = new Date(year, month - 1, day, 18, 1);
	console.log(date);
	specific[1].innerHTML = date;
	
	date = new Date(year, month - 1, day, 18, 1, 10);
	console.log(date);
	specific[2].innerHTML = date;
}

function testDate4() {
//	지정 날짜를 얻어온다.
	let date = new Date(document.getElementById('date').value);
	console.log(date);
	console.log(typeof date);
	
//	경과 날짜를 얻어온다.
	let dateInput = parseInt(document.getElementById('dateInput').value);
	console.log(dateInput);
	console.log(typeof dateInput);
	
//	setDate(): 날짜를 수정한다.
	console.log(date.getDate());
	console.log(date.getDate() + dateInput);
	date.setDate(date.getDate() + dateInput);
	console.log(date.toLocaleDateString());
	
	document.getElementsByClassName('result')[0].innerHTML = 
		'지정 날짜에서 경과 날짜가 지난 날짜는 ' + date.toLocaleDateString() + ' 입니다.';
}

function testDate5() {
//	수로 날짜를 얻어온다.
	let date2 = new Date(document.getElementById('date2').value);

//	지정 날짜를 얻어온다.
	let dateInput2 = new Date(document.getElementById('dateInput2').value);
	
//	수료 날짜에서 지정 날짜를 뺀다.
	let result = date2 - dateInput2;
//	날짜/시간 데이터를 연산하면 연산 결과는 밀리초 단위로 계산된다.
	console.log(result / 1000); // 초 단위
	console.log(result / 1000 / 60); // 분 단위
	console.log(result / 1000 / 60 / 60); // 시간 단위
	console.log(result / 1000 / 60 / 60 / 24); // 일 단위
	
	document.getElementsByClassName('result')[1].innerHTML = 'D-Day: ' + result / (24 * 60 * 60 * 1000);
}

