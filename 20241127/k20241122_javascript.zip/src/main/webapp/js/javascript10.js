//	배열에 저장된 모든 데이터의 합계 계산
const numbers = [1, 2, 3, 4, 5];

let sum = 0;
for (let i = 0; i < numbers.length; i++) {
	sum += numbers[i];
}
console.log(sum);

sum = 0;
for (let n of numbers) {
	sum += n;
}
console.log(sum);

sum = 0;
for (let i in numbers) {
	sum += numbers[i];
}
console.log(sum);
console.log('1. =================================');

sum = 0;
numbers.forEach(function (n) {
	sum += n;
});
console.log(sum);

sum = 0;
numbers.forEach(n => sum += n);
console.log(sum);
console.log('2. =================================');

//	배열이름.reduce(함수[, accumulator의 초기치])
//	최초 실행시 accumulator의 초기치를 첫 번째 인수로 지정한 함수의 accumulator에 저장한 후 인수로 지정된 함수를
//	실행하고 그 다음에는 실행한 함수의 return 값을 다음에 실행할 함수의 accumulator에 저장한 후 배열의 끝까지
//	반복한다.

//	reduce 함수의 인수로 지정하는 함수의 형식
//	function 함수이름(accumulator[, currentValue, currentIndex, array]) { // 일반 함수
//		실행할 문장;
//		...;
//		return 값; // 현재 return 값이 다음 실행의 accumulator 초기값이 된다.
//	}

//	reduce 함수의 accumulator 초기치를 생략하면 배열의 0번째 인덱스의 값이 초기치로 자동 지정되고 배열의 1번째
//	인덱스 부터 끝까지 반복하고 accumulator의 초기치를 지정하면 배열의 0번째 인덱스 부터 끝까지 반복한다.

//	(accumulator[, currentValue, currentIndex, array]) => { // 화살표 함수
//		실행할 문장;
//		...;
//		return 값; // 현재 return 값이 다음 실행의 accumulator 초기값이 된다.
//	}

//	accumulator: 필수 입력, 연산 결과가 저장될 기억장소
//	currentValue: 생략 가능, reduce 함수를 실행하는 배열에 저장된 값이 차례대로 넘어와 저장되는 변수
//	currentIndex: 생략 가능, currentValue로 넘어오는 값의 인덱스가 저장되는 변수
//	array: 생략 가능, reduce 함수를 실행하는 배열 전체가 넘어와서 저장되는 배열

function total(accumulator, currentValue, currentIndex, array) {
	console.log(accumulator, currentValue, currentIndex, array);
	return accumulator + currentValue;
}

sum = numbers.reduce(total, 0);
console.log(sum);

sum = numbers.reduce(function (accumulator, currentValue) {
	return accumulator + currentValue;
}, 0);
console.log(sum);

sum = numbers.reduce((accumulator, currentValue) => accumulator + currentValue, 0);
console.log(sum);
console.log('3. =================================');

//	배열에 저장된 데이터 중에서 10보다 큰 데이터의 개수
const number2 = [1, 2, 3, 4, 5, 10, 20, 30, 40, 50, 60];

let count = 0;
for (let i = 0; i < number2.length; i++) {
	if (number2[i] > 10) {
		count++;
	}
}
console.log(count);

count = 0;
for (let n of number2) {
	if (n > 10) {
		count++;
	}
}
console.log(count);

count = 0;
for (let i in number2) {
	if (number2[i] > 10) {
		count++;
	}
}
console.log(count);
console.log('4. =================================');

count = 0;
function func(n) {
	if (n > 10) {
		count++;
	}
}
number2.forEach(func)
console.log(count);

count = 0;
number2.forEach(function (n) {
	if (n > 10) {
		count++;
	}
});
console.log(count);

count = 0;
number2.forEach(n => {
	if (n > 10) {
		count++;
	}
});
console.log(count);
console.log('5. =================================');

function func2(n) {
	return n > 10;
}
count = number2.filter(func2).length;
console.log(count);

count = number2.filter(function (n) {
	return n > 10;
}).length;
console.log(count);

count = number2.filter(n => n > 10).length;
console.log(count);
console.log('6. =================================');

function tenOverCount(accumulator, currentValue) {
	if (currentValue > 10) {
		// 조건을 만족하면 10보다 큰 경우이므로 현재 accumulator 값을 1증가시켜서 다음으로 넘겨준다.
		return ++accumulator;
	} else {
		// 조건을 만족하지 않으면 10보다 작은 경우이므로 현재 accumulator 값을 그대로 다음으로 넘겨준다.
		return accumulator;
	}
}
count = number2.reduce(tenOverCount, 0);
console.log(count);

count = number2.reduce(function (accumulator, currentValue) {
	if (currentValue > 10) {
		return ++accumulator;
	} else {
		return accumulator;
	}
}, 0);
console.log(count);

//	3항 연산자를 사용하면 1줄로 코딩할 수 있다.
count = number2.reduce((accumulator, currentValue) => currentValue > 10 ? ++accumulator : accumulator, 0);
console.log(count);
console.log('7. =================================');

//	배열에 저장된 문자의 개수를 센다. => {a: 4, b: 1, c: 2, d: 1, e: 1} => 자바스크립트 객체

const alphas = ['a', 'a', 'a', 'b', 'c', 'c', 'd', 'e', 'a'];

function alphaCount(acc, value) {
//	console.log(acc, value);
	if (acc[value] != undefined) { // acc라는 객체에 value라는 key가 있는가?
		// acc라는 객체에 value라는 key가 존재하므로 문자의 개수를 1증가 시킨다.
		acc[value]++;
	} else {
		// acc라는 객체에 value라는 key가 존재하지 않기 때문에 value라는 key의 값을 1로 초기화 시킨다.
		acc[value] = 1;
	}
	return acc;
}

count = alphas.reduce(alphaCount, {}); // accumulator를 빈 객체({})로 초기화 시킨 후 함수가 시작된다.
console.log(count);

count = alphas.reduce(function (acc, value) {
	if (acc[value] != undefined) {
		acc[value]++;
	} else {
		acc[value] = 1;
	}
	return acc;
}, {});
console.log(count);

count = alphas.reduce((acc, value) => {
	acc[value] != undefined ? acc[value]++ : acc[value] = 1;
	return acc;
}, {});
console.log(count);
console.log('8. =================================');

