package com.mbcit.springDI_java_in_xml;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

public class MainClass {

	public static void main(String[] args) {
		
		// xml
//		String configLocation = "classpath:/applicationCTX.xml";
//		AbstractApplicationContext ctx = new GenericXmlApplicationContext(configLocation);
//		Student student = ctx.getBean("student", Student.class);
//		System.out.println(student);
//		Student student2 = ctx.getBean("student2", Student.class);
//		System.out.println(student2);
		
		// java
		AnnotationConfigApplicationContext ctx2 = 
				new AnnotationConfigApplicationContext(ApplicationConfig.class);
		Student student = ctx2.getBean("student", Student.class);
		System.out.println(student);
		Student student2 = ctx2.getBean("student2", Student.class);
		System.out.println(student2);
		
	}
	
}












