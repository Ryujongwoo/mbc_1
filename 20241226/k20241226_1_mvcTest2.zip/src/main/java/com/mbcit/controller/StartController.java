package com.mbcit.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//	@WebServlet 어노테이션의 인수로 특정 요청을 써주면 그 요청이 들어왔을 때 컨트롤러 클래스의 메소드가
//	get 방식의 요청이 들어오면 doGet() 메소드가 post 방식의 요청이 들어오면 doPost() 메소드가 자동으로 
//	실행된다.
//	브라우저 주소 창에 contextPath("/k20241226_1_mvcTest2" => 프로젝트 이름) 뒤에 @WebServlet 어노테이션의
//	인수로 지정된 요청("/StartController")이 들어오면 @WebServlet("/StartController") 어노테이션이 붙어있는
//	클래스(컨트롤러)의 doGet() 또는 doPost() 메소드가 자동으로 실행된다.
@WebServlet("/")
public class StartController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public StartController() {
		super();
	}

//	get 방식의 요청이 들어올 때 자동으로 실행되는 메소드
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String viewpage = "/WEB-INF/welcome.jsp";
		RequestDispatcher dispatcher = request.getRequestDispatcher(viewpage);
		dispatcher.forward(request, response);
	}

//	post 방식의 요청이 들어올 때 자동으로 실행되는 메소드
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
	}

}
