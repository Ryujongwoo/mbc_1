package com.mbcit.myCalendar;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;

import org.jsoup.Connection.Method;
import org.jsoup.Connection.Response;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class CrawlingTest {

	public static void main(String[] args) {
		
//		월별 양력과 음력을 크롤링 한다.
//		1 ~ 12월의 양력 날짜에 대응되는 음력 날짜를 기억할 ArrayList를 선언한다.
		ArrayList<LunarDate> lunarList = new ArrayList<LunarDate>();
		String targetSite = "";
		int year = (new Date()).getYear() + 1900; // 오늘 날짜에서 년만 얻어온다. 올해
//		System.out.println(year);
		
//		올해에 대한 1 ~ 12의 양력에 대응되는 음력을 크롤링해서 얻어온다.
		for (int i = 1; i <= 1; i++) {
//			GET 방식 요청
//			targetSite = String.format(
//				"https://astro.kasi.re.kr/life/pageView/5?search_year=%04d&search_month=%02d&search_check=G", 
//				year, i);
//			System.out.println(targetSite);
			
//			크롤링한 데이터를 기억할 org.jsoup.nodes 패키지의 Document 클래스 객체를 선언한다.
			Document document = null;
			
			try {
//				org.jsoup 패키지의 Jsoup 클래스의 connect() 메소드로 크롤링할 타겟 사이트에 접속하고
//				get() 메소드로 타겟 사이트의 정보를 얻어온다.
//				GET 방식 요청
//				document = Jsoup.connect(targetSite).get();
//				System.out.println(document);
				
//				POST 방식
//				post 방식으로 요청하려면 org.jsoup.Connection 패키지의 Response 인터페이스 객체를 사용한다.
				Response response = Jsoup.connect("https://astro.kasi.re.kr/life/pageView/5")
						.userAgent("Mozilla/7.0")
						.method(Method.POST)
						.data("search_year", String.format("%04d", year))
						.data("search_month", String.format("%02d", i))
						.data("search_check", "G")
						.followRedirects(true)
						.execute();
				document = response.parse();
				
//				Document 클래스 객체에 저장된 타겟 사이트의 정보 중에서 날짜 단위(<tr> 태그>)로 얻어온다.
//				org.jsoup.select 패키지의 Elements 클래스 객체에서 Document 클래스 객체로 읽어들인 내용에서
//				select() 메소드를 사용해서 필요한 정보를 얻어온다.
				Elements elements = document.select("tbody > tr");
//				System.out.println(elements);
				
//				Elements 클래스 객체에는 크롤링된 전체 데이터가 저장되어 있으므로 org.jsoup.nodes 패키지의
//				Element 클래스 객체를 이용해서 Elements 클래스 객체에 저장된 데이터를 1건씩 처리한다.
				for (Element element : elements) {
//					System.out.println(element);
//					날짜 단위(<tr>)로 얻어온 정보에서 양력, 음력 데이터(<td>)를 얻어온다.
					Elements ele = element.select("td");
//					System.out.println(ele);
					
//					text() 메소드로 태그 내부의 문자열만 얻어온다.
//					System.out.println("양력: " + ele.get(0).text());
//					System.out.println("음력: " + ele.get(1).text());
//					System.out.println("간지: " + ele.get(2).text());
//					System.out.println("요일: " + ele.get(3).text());
//					System.out.println("율리우스력: " + ele.get(4).text());
//					System.out.println("=================================================================");
					
					String sola = ele.get(0).text();
					String lunar = ele.get(1).text();
					System.out.println(String.format("양력 %s은 음력으로 %s 입니다.", sola, lunar));
//					크롤링 끝
				}
			} catch (IOException e) {
				e.printStackTrace();
				System.out.println("크롤링할 사이트의 주소가 올바르지 않거나 문제가 있습니다.");
			}
		}
		
	}
	
}

















