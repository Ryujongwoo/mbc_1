package com.mbcit.k20250120_2_springBoot_Mybatis_SimpleBBS;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class K202501202SpringBootMybatisSimpleBbsApplication {

	public static void main(String[] args) {
		SpringApplication.run(K202501202SpringBootMybatisSimpleBbsApplication.class, args);
	}

}
