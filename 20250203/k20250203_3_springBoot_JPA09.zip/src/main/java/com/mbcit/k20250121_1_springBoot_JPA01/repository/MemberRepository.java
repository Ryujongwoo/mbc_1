package com.mbcit.k20250121_1_springBoot_JPA01.repository;

import java.util.List;
import java.util.Map;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.mbcit.k20250121_1_springBoot_JPA01.domain.Member;

public interface MemberRepository extends JpaRepository<Member, Long> {

	@Query(value = "select * from member2 limit 1;", nativeQuery = true)
	Map<String, Object> findRecord();

//	JpaRepository 인터페이스 지원하지 않는 쿼리 메소드를 정의한다.
//	findById() 메소드와 유사하게 다른 필드를 검색하는 메소드를 만들려면 Id 대신 다른 필드의 이름이
//	맨 뒤에 사용되는 추상 메소드를 만들어서 사용하면 된다.
//	중복되는 이름이 없을 경우 리턴되는 객체가 1개 이므로 Member를 리턴 타입으로 사용한다.
//	Member findByName(String name);
//	중복되는 이름이 있을 경우 리턴되는 객체가 여러개 이므로 List<Member>를 리턴 타입으로 사용한다.
	List<Member> findByName(String name);
	
//	모든 접두어를 다 사용할 수 있는 것은 아니지만 접두어만 다르게 해서 같은 기능을 실행하는
//	메소드를 만들어 사용할 수 있다.
	List<Member> findByEmail(String email);
	List<Member> getByEmail(String email);
	List<Member> queryByEmail(String email);
	List<Member> readByEmail(String email);
	List<Member> searchByEmail(String email);
	List<Member> streamByEmail(String email);
	
//	Top, First를 사용해서 메소드를 만들어 사용하면 limit가 사용되는 쿼리가 실행된다.
//	Top, First 뒤에 limit에 사용될 숫자를 지정한다. 숫자를 생략하면 1이 기본값으로 사용된다.
	List<Member> findTopByName(String name);
	List<Member> findTop2ByName(String name);
	List<Member> findFirst2ByName(String name);
	
//	Top, First 붙여서 작성한 메소드와 반대 기능을 실행하려고 Bottom, Last 사용해서 메소드를
//	만들면 Top, First는 JPA가 지원하지만 Bottom, Last는 지원하지 않기 때문에 Bottom, Last는
//	무시되서 findByName(String name) 메소드와 같은 전체 검색 기능이 실행된다.
	List<Member> findBottom2ByName(String name);
	List<Member> findLast2ByName(String name);
	
//	쿼리 메소드 활용(and, or, >, >=, <, <=, between)
//	and, or 조건
	List<Member> findByNameAndEmail(String name, String email);
	List<Member> findByEmailAndName(String email, String name);
	List<Member> findByNameOrEmail(String name, String email);
	List<Member> findByEmailOrName(String email, String name);
	
//	>(초과, After, GreaterThan), <(미만, Before, LessThan) 조건
	List<Member> findByIdAfter(Long id);
	List<Member> findByIdGreaterThan(Long id);
	List<Member> findByIdBefore(Long id);
	List<Member> findByIdLessThan(Long id);
	
//	>=(이상, GreaterThanEqual), <=(이하, LessThanEqual) 조건
	List<Member> findByIdGreaterThanEqual(Long id);
	List<Member> findByIdLessThanEqual(Long id);
	
//	between 조건(~이상이고 ~이하인)
	List<Member> findByIdGreaterThanEqualAndIdLessThanEqual(Long id1, Long id2);
	List<Member> findByIdBetween(Long id1, Long id2);
	
	List<Member> findByIdGreaterThanAndIdLessThan(Long id1, Long id2);
	List<Member> findByIdAfterAndIdBefore(Long id1, Long id2);
	List<Member> findByIdGreaterThanAndIdBefore(Long id1, Long id2);
	List<Member> findByIdAfterAndIdLessThan(Long id1, Long id2);
	
//	쿼리 메소드 활용(null, not null, in, not in, like)
//	null, not null
	List<Member> findByCreateDateIsNull();
	List<Member> findByCreateDateIsNotNull();
	
//	in, not in
	List<Member> findByNameIn(List<String> names);
	List<Member> findByNameNotIn(List<String> names);
	
//	like
//	Like를 사용하면 "%"를 사용해서 인수에 전달한다.
	List<Member> findByNameLike(String name);
	
//	StartingWith, EndingWith, Contains를 사용하면 인수에 "%"를 사용하지 않는다.
	List<Member> findByNameStartingWith(String name); // 시작하는
	List<Member> findByNameEndingWith(String name); // 끝나는
	List<Member> findByNameContains(String name); // 포함하는
	
//	정렬
//	전체 데이터를 정렬한다.
	List<Member> findAllByOrderByNameAsc(); // 이름의 오름차순
	List<Member> findAllByOrderByEmailDesc(); // 이메일의 오름차순
	
//	조건을 만족하는 데이터만 선택해서 정렬한다.
	List<Member> findByNameOrderByEmailAsc(String name);
	List<Member> findByNameOrderByIdDesc(String name);
	
//	Top, First로 limit를 지정해서 상위 데이터를 얻어올 수 있게된다.
	List<Member> findTop3AllByOrderByNameAsc();
	List<Member> findTop2ByNameOrderByIdDesc(String name);
	
//	1차 정렬 기준이 같으면 2차 정렬 기준을 지정해서 정렬한다.
//	이름의 내림차순 정렬, 이름이 같으면 이메일의 오름차순 정렬
	List<Member> findAllByOrderByNameDescEmailAsc();
//	이메일의 오름차순 정렬, 이메일이 같으면 id의 내림차순 정렬
	List<Member> findAllByOrderByEmailAscIdDesc();
//	이름의 내림차순 정렬, 이름이 같으면 이메일의 오름차순 정렬, 이메일도 같으면 id의 내림차순 정렬
	List<Member> findAllByOrderByNameDescEmailAscIdDesc();
	
//	Sort 객체를 사용해서 정렬한다. org.springframework.data.domain.Sort
	List<Member> findAll(Sort sort);
	
//	페이징
//	org.springframework.data.domain.Page, org.springframework.data.domain.Pageable
	Page<Member> findAll(Pageable pageable);
	Page<Member> findByName(String name, Pageable pageable);
	
}

















