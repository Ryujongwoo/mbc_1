CREATE TABLE "CARD" (
    "CONSUMERID" VARCHAR2(200 BYTE) NOT NULL, 
	"AMOUNT" VARCHAR2(200 BYTE) NOT NULL
);

CREATE TABLE "TICKET" (
    "CONSUMERID" VARCHAR2(200 BYTE) NOT NULL, 
	"COUNTNUM" VARCHAR2(200 BYTE) NOT NULL,
    CONSTRAINT "CK_TICKET_COUNTNUM" CHECK (countnum < 5) ENABLE
);

select * from card;
select * from ticket;

delete from card;
delete from ticket;

insert into ticket (consumerid, countnum) values ('1111', '4');
insert into ticket (consumerid, countnum) values ('2222', '5');
