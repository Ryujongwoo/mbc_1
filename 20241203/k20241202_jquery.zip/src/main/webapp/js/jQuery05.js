$(() => {
//	input 태그 중에서 type 속성의 속성 값이 text인 모든 요소를 선택해서 배경색 변경하기
//	javascript
	/*
//	let inputs = document.getElementsByTagName('input');
	let inputs = document.querySelectorAll('input');
//	console.log(inputs.length);
	for (let input of inputs) {
		// getAttribute() 함수는 인수로 지정된 속성의 속성 값을 얻어올 수 있다.
		// console.log(input.getAttribute('type'));
		if (input.getAttribute('type') === 'text') {
			input.style.backgroundColor = 'yellowgreen';
		}
	}
	*/
	/*
	let inputs = document.querySelectorAll('input[type="text"]');
	console.log(inputs.length);
	for (let input of inputs) {
		input.style.backgroundColor = 'hotpink';
	}
	*/
	
//	jQuery
//	$('input[type=text]').css('backgroundColor', 'tomato');
	$('input:text').css('backgroundColor', 'dodgerblue');
	
//	select 태그의 id 속성 값이 email인 요소에서 change 이벤트가 발생되면 선택된 option의 value 값을
//	id 속성 값이 addr인 텍스트 상자에 넣어준다.
	
//	javascript
	/*
	let email = document.getElementById('email');
	// console.log(email);
	email.onchange = () => {
		if (email.selectedIndex == 0) {
			document.getElementById('addr').value = '';
			document.getElementById('addr').focus();
		} else {
			let emailValue = email.options[email.selectedIndex].value;
			// console.log(emailValue);
			document.getElementById('addr').value = emailValue;
		}
	}
	*/
	
//	jQuery
	/*
	$('#email').change(() => {
		// index(): 선택된 요소의 인덱스를 얻어온다.
		if ($('#email > option:selected').index() == 0) {
			$('#addr').val('');
			$('#addr').focus();
		} else {
			let emailValue = $('#email > option:selected').val();
			// console.log(emailValue);
			$('#addr').val(emailValue);
		}
	});
	*/
	
//	$(this)는 무조건 1개의 요소만 선택될 때 선택된 요소를 의미한다.
//	콤보 상자는 1번에 무조건 1개만 선택되기 때문에 $('#email > option:selected')와 $(this)는 같은 의미로
//	사용된다.
//	$(this)는 화살표 함수에서 사용할 수 없다. .''ㅠ.ㅠ''.
	$('#email').change(function () {
		// console.log($(this).val().indexOf('직접입력'));
		if ($(this).val().indexOf('직접입력') >= 0) {
			$('#addr').val('');
			$('#addr').focus();
		} else {
			let emailValue = $(this).val();
			$('#addr').val(emailValue);
		}
	});
	
//	체크 박스를 체크(클릭)하면 체크된 목록을 콘솔에 출력한다. 
//	javascript
	/*
//	let hobby1 = document.getElementsByName('hobbies')[0];
	let hobby1 = document.querySelectorAll('[name="hobbies"')[0];
//	console.log(hobby1);
	let hobby2 = document.querySelectorAll('[name="hobbies"')[1];
	let hobby3 = document.querySelectorAll('[name="hobbies"')[2];
	
	hobby1.onclick = () => {
		// console.log('hobby1에서 onclick 이벤트 실행됨');
		let hobbies = document.getElementsByName('hobbies');
//		let msg = '';
//		for (let hobby of hobbies) {
//			if (hobby.checked) {
//				msg += hobby.value + ' '
//			}
//		}
//		console.log(msg.length == 0 ? '취미 없음' : msg);

		let msg = [];
		for (let hobby of hobbies) {
			if (hobby.checked) {
				msg.push(hobby.value);
			}
		}
		console.log(msg.length == 0 ? '취미 없음' : msg.join(', '));
	}
	
	hobby2.onclick = () => {
		let hobbies = document.getElementsByName('hobbies');
		let msg = [];
		for (let hobby of hobbies) {
			if (hobby.checked) {
				msg.push(hobby.value);
			}
		}
		console.log(msg.length == 0 ? '취미 없음' : msg.join(', '));
	}
	
	hobby3.onclick = () => {
		let hobbies = document.getElementsByName('hobbies');
		let msg = [];
		for (let hobby of hobbies) {
			if (hobby.checked) {
				msg.push(hobby.value);
			}
		}
		console.log(msg.length == 0 ? '취미 없음' : msg.join(', '));
	}
	
	hobby1.onclick = () => hobbyCheck();
	hobby2.onclick = () => hobbyCheck();
	hobby3.onclick = () => hobbyCheck();
	*/
	/*
	let hobbies = document.querySelectorAll('[name="hobbies"]');
	for (let hobby of hobbies) {
		hobby.onclick = function () {
			// let hobbies = document.getElementsByName('hobbies');
			let msg = [];
			for (let hobby of hobbies) {
				if (hobby.checked) {
					msg.push(hobby.value);
				}
			}
			console.log(msg.length == 0 ? '취미 없음' : msg.join(', '));
		}
	}
	*/
	/*
	let hobbies = document.querySelectorAll('[name="hobbies"]');
	for (let hobby of hobbies) {
		hobby.onclick = () => hobbyCheck();
	}
	*/
	
//	each(): 선택된 요소들의 인덱스와 요소 자체를 리턴하며 인수로 지정된 함수를 반복해서 실행한다.
//	each() 함수는 인수로 지정된 함수로 인수 2개를 넘긴다. 1번째 인수는 인덱스이고 2번째 인수는 객체이다.
	
//	jQuery
	/*
	$('input:checkbox[name=hobbies]').click(function () {
		let msg = [];
		$('input:checkbox[name=hobbies]:checked').each(function (index, obj) {
			// console.log(`index: ${index}, obj: ${obj.value}`);
			msg.push($('input:checkbox[name=hobbies]:checked').eq(index).val());
		});
		console.log(msg.length == 0 ? '취미 없음' : msg.join(', '));
	});
	*/
	/*
	$('input:checkbox[name=hobbies]').click(() => {
		let msg = [];
		$('input:checkbox[name=hobbies]:checked')
			.each(index => msg.push($('input:checkbox[name=hobbies]:checked').eq(index).val()));
		console.log(msg.length == 0 ? '취미 없음' : msg.join(', '));
	});
	*/
	/*
	$('input:checkbox[name=hobbies]').click(function () {
		let msg = [];
		// 인수의 순서상 변수가 나와야 하는데 그 인수를 사용하지 않을 경우 뒤의 인수가 필요 없으면 인수를 사용하지
		// 않으면 되고 앞의 인수가 필요 없으면 '_'로 처리해도 된다.
		$('input:checkbox[name=hobbies]:checked').each(function (index, obj) {
			msg.push(obj.value);
		});
		console.log(msg.length == 0 ? '취미 없음' : msg.join(', '));
	});
	*/
	$('input:checkbox[name=hobbies]').click(() => {
		let msg = [];
		$('input:checkbox[name=hobbies]:checked').each((_, obj) => msg.push(obj.value));
		console.log(msg.length == 0 ? '취미 없음' : msg.join(', '));
	});
});

function hobbyCheck() {
//	javascript
	let hobbies = document.getElementsByName('hobbies');
	let msg = [];
	for (let hobby of hobbies) {
		if (hobby.checked) {
			msg.push(hobby.value);
		}
	}
	console.log(msg.length == 0 ? '취미 없음' : msg.join(', '));
}

