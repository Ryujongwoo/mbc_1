package com.mbcit.k20250121_1_springBoot_JPA01.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.mbcit.k20250121_1_springBoot_JPA01.domain.Score;

public interface ScoreRepository extends JpaRepository<Score, Long> {

//	JPQL
//	JPA를 이용하는 방식이므로 Score와 같이 엔티티 객체 이름을 사용해야 한다.
	@Query(value = "select score from Score score where java >= ?1 and spring >= ?2")
	public List<Score> findByScore(int java, int spring);
	
	@Query(value = "select score from Score score where java >= :java and spring >= :spring")
	public List<Score> findByScoreParam(@Param("java") int java, @Param("spring") int spring);
	
//	nativeQuery
//	RDBMS에서 사용하는 방식이므로 score와 같이 테이블 이름을 사용해야 한다.
	@Query(value = "select * from score where java >= 75 and spring >= 80", nativeQuery = true)
	public List<Score> findByNative();
	
//	JPA가 실행하지 못하는 명령도 실행할 수 있다.
	@Query(value = "show tables", nativeQuery = true)
	public List<String> showTables();
	
}
