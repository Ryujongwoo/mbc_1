import { useEffect } from 'react';

// 리액트에서 hook를 사용자가 직접 작성할 수 있다.
// hook는 자바스크립트 함수이며, 이름이 use로 시작해야 한다.
function useTitle(title) {
  // title 인수가 변경될 때 마다 제목을 업데이트하도록 useEffect hook를 이용한다.
  useEffect(function () {
    document.title = title
  }, [title]);
}

// 사용자 정의 hook도 다른 js 파일에서 사용하려면 반드시 export를 시켜야 한다.
export default useTitle;
