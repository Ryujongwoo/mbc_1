package com.mbcit.springAOP_xml;

//	공통 기능 메소드를 모아놓은 클래스
public class LogAop {

//	before
	public void before() {
		System.out.println("LogAop 클래스의 공통 기능 before() 메소드");
	}
	
//	after-returning
	public void afterReturning() {
		System.out.println("LogAop 클래스의 공통 기능 afterReturning() 메소드");
	}
	
//	after-throwing
	public void afterThrowing() {
		System.out.println("LogAop 클래스의 공통 기능 afterThrowing() 메소드");
	}
	
//	after
	public void after() {
		System.out.println("LogAop 클래스의 공통 기능 after() 메소드");
	}
	
//	around
	
}
