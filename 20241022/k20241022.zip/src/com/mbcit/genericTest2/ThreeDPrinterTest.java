package com.mbcit.genericTest2;

public class ThreeDPrinterTest {

	public static void main(String[] args) {
		
		GenericPrinter<Plastic> genericPrinter = new GenericPrinter<Plastic>();
		Plastic plastic = new Plastic();
		genericPrinter.setMaterial(plastic);
		System.out.println(genericPrinter);
		plastic = genericPrinter.getMaterial();
		
		GenericPrinter<Powder> genericPrinter2 = new GenericPrinter<Powder>();
		Powder powder = new Powder();
		genericPrinter2.setMaterial(powder);
		System.out.println(genericPrinter2);
		powder = genericPrinter2.getMaterial();
		
//		Water 클래스는 Material 인터페이스를 구현받아 선언된 클래스가 아니므로 GenericPrinter 클래스의
//		generic으로 데이터 타입을 전달할 수 없다.
//		GenericPrinter<Water> genericPrinter3 = new GenericPrinter<Water>(); // 에러
		
	}
	
}





















