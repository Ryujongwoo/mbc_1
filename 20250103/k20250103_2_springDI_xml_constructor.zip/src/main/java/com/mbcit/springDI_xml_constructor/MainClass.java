package com.mbcit.springDI_xml_constructor;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

public class MainClass {

	public static void main(String[] args) {
		
		/*
		Student student = new Student();
		student.setName("홍길동");
		student.setAge(13);
		student.setGradeNum(6);
		student.setClassNum(13);
		
		StudentInfo studentInfo = new StudentInfo();
		studentInfo.setStudent(student);
		studentInfo.getStudentInfo();
		
		Student student2 = new Student("임꺽정", 11, 4, 3);
		StudentInfo studentInfo2 = new StudentInfo(student2);
		studentInfo2.getStudentInfo();
		*/
		
		AbstractApplicationContext ctx = new GenericXmlApplicationContext("classpath:/applicationCTX.xml");
		StudentInfo studentInfo = ctx.getBean("studentInfo", StudentInfo.class);
		studentInfo.getStudentInfo();
		
		StudentInfo studentInfo2 = ctx.getBean("studentInfo2", StudentInfo.class);
		studentInfo2.getStudentInfo();
		
	}
	
}
