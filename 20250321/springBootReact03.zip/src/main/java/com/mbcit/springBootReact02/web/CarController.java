package com.mbcit.springBootReact02.web;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mbcit.springBootReact02.domain.Car;
import com.mbcit.springBootReact02.domain.CarRepository;

//	@RestController 어노테이션은 이 클래스가 RESTful 웹 서비스의 컨트롤러가 되도록 지정한다.
@RestController
public class CarController {

//	데이터베이스에서 자동차를 반환할 수 있게 하려면 CarRepository를 컨트롤러에 주입해야 한다.
	@Autowired
	private CarRepository carRepository;
	
//	컨트롤러 클래스에 새 메소드를 추가하고 @RequestMapping 어노테이션을 지정한다.
//	@RequestMapping 어노테이션은 메소드가 매핑되는 엔드포인트를 정의한다. 사용자가 /cars 엔드포인트로 이동하면 
//	getCars() 메소드가 실행된다.
//	@RequestMapping 어노테이션은 모든 HTTP 방식의 요청(GET, POST, PATCH, PUT, DELETE)을 처리한다.
//	@RequestMapping 어노테이션이 허용할 HTTP 방식을 지정하려면 @RequestMapping(value = "/cars", method = GET)
//	형식을 이용하면 된다. 이 경우 /cars 엔드포인트에서 GET 요청만 처리한다.
//	@GetMapping 어노테이션을 이용하면 GET 요청만 getCars() 메소드로 매핑된다.
//	이처럼 각기 다른 HTTP 방식을 위한 @PostMapping, @PatchMapping, @DeleteMapping 어노테이션이 있다.
	@RequestMapping("/cars")
	public Iterable<Car> getCars() {
		System.out.println("CarController 클래스의 getCars() 메소드 실행");
		return carRepository.findAll();
	}
	
//	spring data rest는 spring data 프로젝트의 일부이며, spring으로 쉽고 빠르게 RESTful 웹 서비스를 구현할 수 
//	있게 해준다.
//	spring data rest를 이용하려면 pom.xml 파일에 아래의 dependency를 추가해야 한다.
//	<dependency>
//		<groupId>org.springframework.boot</groupId>
//		<artifactId>spring-boot-starter-data-rest</artifactId>
//	</dependency>
	
}


















