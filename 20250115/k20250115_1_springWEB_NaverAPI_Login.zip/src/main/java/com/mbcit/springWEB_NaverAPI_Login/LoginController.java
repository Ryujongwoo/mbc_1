package com.mbcit.springWEB_NaverAPI_Login;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.github.scribejava.core.model.OAuth2AccessToken;
import com.mbcit.springWEB_NaverAPI_Login.oauth.NaverLogin;

@Controller
public class LoginController {
	
	private static final Logger logger = LoggerFactory.getLogger(LoginController.class);

//	네이버 로그인 API를 사용하는 메소드가 작성된 클래스(NaverLogin) 객체를 선언하고 초기화 한다.
	@Autowired
	private NaverLogin naverLogin;

//	@Autowired
//	public void setNaverLogin(NaverLogin naverLogin) {
//		logger.info("naverLogin: {}", naverLogin);
//		this.naverLogin = naverLogin;
//	}
	
//	로그인한 사용자 정보를 기억할 변수를 선언한다.
	private String apiResult;
	
//	로그인 버튼이 있는 페이지를 요청하는 메소드
	@RequestMapping("/login")
	public String login(HttpServletRequest request, Model model, HttpSession session) {
		logger.info("LoginController 클래스의 login() 메소드 실행");
		// 네이버 아이디로 인증 URL을 생성하기 위해서 NaverLogin 클래스의 getAuthorizationUrl()
		// 메소드를 실행한다.
		String naverAuthUrl = naverLogin.getAuthorizationUrl(session);
		logger.info("네이버 로그인 인증 URL: {}", naverAuthUrl);
		model.addAttribute("url", naverAuthUrl);
		return "login";
	}
	
//	네이버 로그인 성공시 callback을 요청하는 메소드
	@RequestMapping("/callback")
	public String callback(/* HttpServletRequest request, */Model model, HttpSession session,
			@RequestParam String code, @RequestParam String state) throws IOException, ParseException {
		logger.info("LoginController 클래스의 callback() 메소드 실행");
		// String code = request.getParameter("code");
		// String state = request.getParameter("state");
		logger.info("code: {}", code);
		logger.info("state: {}", state);
		
		// 로그인한 사용자의 AccessToken을 얻어오는 NaverLogin 클래스의 getAccessToken()
		// 메소드를 실행한다.
		OAuth2AccessToken accessToken = naverLogin.getAccessToken(session, code, state);
		logger.info("accessToken: {}", accessToken);
		
		// 로그인한 사용자 정보를 얻어오는 NaverLogin 클래스의 getUserProfile() 메소드를 실행한다.
		// 얻어오는 데이터는 json 형태로 얻어온다.
		apiResult = naverLogin.getUserProfile(accessToken);
		logger.info("apiResult: {}", apiResult);
		
		// json 형태로 얻어온 사용자 정보를 파싱한다.
		JSONParser jsonParser = new JSONParser();
		JSONObject jsonObject = (JSONObject) jsonParser.parse(apiResult);
		logger.info("jsonObject: {}", jsonObject);
		logger.info("jsonObject: {}", jsonObject.get("response"));
		
		JSONObject response = (JSONObject) jsonObject.get("response");
		logger.info("birthday: {}", response.get("birthday"));
		logger.info("mobile: {}", response.get("mobile"));
		logger.info("name: {}", response.get("name"));
		logger.info("id: {}", response.get("id"));
		logger.info("email: {}", response.get("email"));
		
		// 파싱한 값을 세션에 저장한다.
		session.setAttribute("response", response); // 로그인 되었으므로 세션을 생성한다.
		model.addAttribute("apiResult", apiResult);
		
		return "naverSuccess";
	}
	
//	로그아웃 메소드
	@RequestMapping("/logout")
	public String logout(HttpServletRequest request, Model model, HttpSession session) {
		logger.info("LoginController 클래스의 logout() 메소드 실행");
		session.invalidate(); // 로그아웃 되었으므로 세션을 종료한다.
		return "redirect:login";
	}
	
}














