package com.mbcit.springBootReact02;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.http.MediaType;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.stereotype.Component;

//	인증 예외를 처리하는 클래스
//	잘못된 사용자나 틀린 비밀번호로 로그인하려고 하면 403 상태가 반환된다.
//	인증 예외 처리를 위해 제공되는 AuthenticationEntryPoint 인터페이스를 구현받아 만든다.
@Component
public class AuthEntryPoint implements AuthenticationEntryPoint {

	@Override
	public void commence(HttpServletRequest request, HttpServletResponse response,
			AuthenticationException authException) throws IOException, ServletException {
		response.setStatus(HttpServletResponse.SC_UNAUTHORIZED); // 401
		response.setContentType(MediaType.APPLICATION_JSON_VALUE);
		PrintWriter printWriter = response.getWriter();
		printWriter.println("Error: " + authException.getMessage());
	}
	
}











