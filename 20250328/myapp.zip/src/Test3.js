import React, { useState } from 'react';
import useTitle from './useTitle';

function Subject() {
  const [count, setCount] = useState(0);

  // useTitle hook로 count 상태 값을 문서 제목에 표시한다.
  // Subject 컴포넌트가 렌더링될 때 마다 useTitle hook가 호출되고 현재 count 상태 값이
  // 문서 제목에 출력된다.
  useTitle(`You clicked ${count} times`);

  return (
    <div align="center">
      <h1>Subject</h1>
      <p>Count = {count}</p>
      <button type='button' onClick={() => setCount(count + 1)}>Title</button>
    </div>
  )
}

export default Subject;