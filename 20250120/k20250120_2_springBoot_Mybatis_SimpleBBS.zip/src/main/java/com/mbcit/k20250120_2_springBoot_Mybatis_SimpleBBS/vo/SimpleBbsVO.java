package com.mbcit.k20250120_2_springBoot_Mybatis_SimpleBBS.vo;

import lombok.Data;

@Data
public class SimpleBbsVO {

	private int idx;
	private String name;
	private String title;
	private String content;
	
}
