-- GenerationType 값에 상관없이 insert sql 명령 실행
insert into member (id, name, email, create_date, update_date) 
values (1, '홍길동', 'hong@mbcit.com', now(), now());
insert into member (id, name, email, create_date, update_date) 
values (2, '임꺽정', 'lim@mbcit.com', now(), now());
insert into member (id, name, email, create_date, update_date) 
values (3, '장길산', 'jang@mbcit.com', now(), now());
insert into member (id, name, email, create_date, update_date) 
values (4, '일지매', 'il@mbcit.com', now(), now());
insert into member (id, name, email, create_date, update_date) 
values (5, '홍길동', 'gildong@mbcit.com', now(), now());
insert into member (id, name, email, create_date, update_date) 
values (6, '홍길동', 'hong@mbcit.com', now(), now());
