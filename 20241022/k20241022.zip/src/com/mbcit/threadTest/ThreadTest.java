package com.mbcit.threadTest;

public class ThreadTest {

	public static void main(String[] args) {
		
//		<< Thread 클래스를 상속받아 구현된 멀티 스레드 실행 방법 >>
//		1. Thread 클래스를 상속받아 멀티 스레드를 구현한 클래스의 객체를 만든다.
		DigitThread digit = new DigitThread();
//		2. Thread 클래스를 상속받아 작성된 클래스 객체에서 start() 메소드로 멀티 스레드를 실행한다.
		digit.start();
		
//		아래와 같이 run() 메소드를 override 해서 구현했다고 run() 메소드를 실행하면 run()이라는
//		일반 메소드를 실행한다.
//		digit.run();
		
//		<< Runnable 인터페이스를 구션받아 구현된 멀티 스레드 실행 방법 >>
//		1. Runnable 인터페이스를 구현받아 멀티 스레드를 구현한 클래스의 객체를 만든다.
		AlphaThread alpha = new AlphaThread();
//		2. Runnable 인터페이스는 run()이라는 추상 메소드만 들어있고 스레드를 실제로 실행하는 기능이
//		   구현돼있지 안기때문에 스레드를 실행하기 위해서는 Thread 클래스를 이용해야 한다.
//		   Thread 클래스 객체를 생성하는데 생성자의 인수로 Runnable 인터페이스를 구현받아 멀티
//		   스레드를 구현한 클래스 객체를 넘겨준다.
		Thread thread = new Thread(alpha);
//		3. Thread 클래스 객체에서 start() 메소드로 멀티 스레드를 실행한다.
		thread.start();
		
//		'A' ~ 'Z'를 0.2초 간격으로 출력한다.
//		for (int i = 0; i < 26; i++) {
//			System.out.print((char) (i + 65));
//			try {
//				Thread.sleep(200);
//			} catch (InterruptedException e) {
//				e.printStackTrace();
//			}
//		}
		for (char ch = 'A'; ch <= 'Z'; ch++) {
			System.out.print(ch);
			try {
				Thread.sleep(200);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		
	}
	
}
