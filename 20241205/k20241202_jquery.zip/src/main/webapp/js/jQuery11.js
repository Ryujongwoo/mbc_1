/*
animate(): 여러 css 스타일을 이용해서 사용자 정의 이펙트를 정의할 수 있다.
$('선택자').animate(
	// {스타일}, // 필수, 이펙트 구성할 css 스타일 속성을 지정한다.
	// 재생시간, // 선택, 이펙트가 지속될 시간을 밀리초 단위로 지정한다.
	// '속도함수', // 선택, 이펙트의 시간당 속도를 지정한다.
	// 콜백함수() // 선택, 이펙트 동작이 완료된 후 실행할 함수를 지정한다.
);

//	속도 함수
//	swing: 기본값, 시작, 끝 부분은 천천히 움직이고 중간 부분은 빠르게 움직인다.
//	linear: 시작, 중간, 끝 구분없이 일정한 속도로 움직인다.
*/

$('h2').click(function () {
	$('p').show();
	$('p').each(function (index) {
		$(this).animate(
			{ // 스타일
				'top': 144 + index * 50 + 'px'
			},
			500, // 재생 시간
			'linear', // 속도 함수
			function () { // 콜백 함수
				console.log(`${index} 번째 p 태그에 지정된 animate() 끝`);
			}
		);
	});
});

//	클릭한 p 태그의 배경색을 변경하고 각각의 이펙트를 실행한다.
/*
$('p:eq(0)').click(function () {
	$('p:eq(0)').css('backgroundColor', 'hotpink');
	$('#img').hide();
});
$('p:eq(1)').click(function () {
	$('p:eq(1)').css('backgroundColor', 'hotpink');
	$('#img').show();
});
$('p:eq(2)').click(function () {
	$('p:eq(2)').css('backgroundColor', 'hotpink');
	$('#img').toggle();
});
*/

/*
$('p').click(function () {
//	클릭한 p 태그의 배경색을 변경한다.
	$(this).css('backgroundColor', 'hotpink');
//	클릭한 p 태그를 제외한 나머지 형제들(siblings)을 선택해서 배경색을 흰색으로 변경한다.
	$(this).siblings('p').css('backgroundColor', 'white');

//	:contains(): 인수로 지정된 문자열을 포함하는 객체를 선택한다.
//	console.log($(this).is('p:contains(hide)'));
//	if ($(this).is('p:contains(hide)')) {
//		$('#img').hide();
//	} else if ($(this).is('p:contains(show)')) {
//		$('#img').show();
//	} else if ($(this).is('p:contains(toggle)')) {
//		$('#img').toggle();
//	}

	let commend = $(this).html();
	console.log(commend);
//	if (commend == 'hide') {
//		$('#img').hide();
//	} else if (commend == 'show') {
//		$('#img').show();
//	} else if (commend == 'toggle') {
//		$('#img').toggle();
//	}

	switch (commend) {
		case 'hide':
			$('#img').hide();
			break;
		case 'show':
			$('#img').show();
			break;
		case 'toggle':
			$('#img').toggle();
			break;
	}
});
*/

//	$('선택자').이벤트함수(실행할함수)
//	bind(): jQuery 이벤트에 이벤트가 발생되면 실행할 함수를 연결한다.
//	$('선택자').bind('이벤트이름', 실행할함수)

$('p').bind('click', function () {
	$(this).css('backgroundColor', 'hotpink');
	$(this).siblings('p').css('backgroundColor', 'white');
	
	switch ($(this).html()) {
		case 'hide':
			$('#img').hide();
			break;
		case 'show':
			$('#img').show();
			break;
		case 'toggle':
			$('#img').toggle();
			break;
		case 'slideUp':
			$('#img').slideUp();
			break;
		case 'slideDown':
			$('#img').slideDown();
			break;
		case 'slideToggle':
			$('#img').slideToggle();
			break;
		case 'fadeOut':
			$('#img').fadeOut();
			break;
		case 'fadeIn':
			$('#img').fadeIn();
			break;
		case 'fadeToggle':
			$('#img').fadeToggle();
			break;
		case 'fadeTo':
			
			// fadeTo(재생시간, 투명도): fade 효과에서 사용하는 opacity 속성 값을 직접 지정한다.
			// fadeTo()가 실행되서 투명도가 변경되면 변경된 투명도가 계속 유지되서 표시된다.
		
			$('#img').fadeTo(1000, 0.2);
			break;
		case 'animate':
			$('#img').animate(
				{
					'width': '300px',
					'top': '300px',
					'left': '600px'
				},
				1000,
				'linear',
				function () {
					console.log('애니메이션 끝~~~~~');
				}
			);
			break;
	}
});

