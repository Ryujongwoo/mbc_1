package com.mbcit.springBootReact01.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class HomeController {

	@RequestMapping("/hello")
//	viewpage가 없는 상태에서 return 하는 내용을 브라우저에 출력하려면 @ResponseBody 어노테이션을
//	붙여주면 된다.
	public @ResponseBody String hello() {
		return "hello";
	}
	
}
