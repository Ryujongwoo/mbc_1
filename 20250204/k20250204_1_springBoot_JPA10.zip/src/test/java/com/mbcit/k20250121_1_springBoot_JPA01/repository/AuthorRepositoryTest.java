package com.mbcit.k20250121_1_springBoot_JPA01.repository;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import javax.transaction.Transactional;

import org.assertj.core.util.Lists;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.mbcit.k20250121_1_springBoot_JPA01.domain.Author;
import com.mbcit.k20250121_1_springBoot_JPA01.domain.Book;
import com.mbcit.k20250121_1_springBoot_JPA01.domain.Publisher;
import com.mbcit.k20250121_1_springBoot_JPA01.domain.Relation;

@SpringBootTest
class AuthorRepositoryTest {

	@Autowired
	private AuthorRepository authorRepository;
	@Autowired
	private BookRepository bookRepository;
	
	@Autowired
	private RelationRepository relationRepository;
	
	@Test
	@Transactional
	void manyToManyTest() {
		System.out.println("AuthorRepositoryTest 클래스의 manyToManyTest() 메소드 실행");
		
		Book book1 = givenBook("java");
		Book book2 = givenBook("jsp");
		Book book3 = givenBook("spring");
		Book book4 = givenBook("springBoot");
		
		Author author1 = givenAuthor("홍길동");
		Author author2 = givenAuthor("임꺽정");
		
//		N:M 연관 관계를 맺는다.
//		book1.setAuthors(Lists.newArrayList(author1));
//		book2.setAuthors(Lists.newArrayList(author2));
//		book3.setAuthors(Lists.newArrayList(author1, author2));
//		book4.setAuthors(Lists.newArrayList(author1, author2));
		
		book1.addAuthor(author1);
		book2.addAuthor(author2);
		book3.addAuthor(author1, author2);
		book4.addAuthor(author1, author2);
		
//		author1.setBooks(Lists.newArrayList(book1, book3, book4));
//		author2.setBooks(Lists.newArrayList(book2, book3, book4));
		
		author1.addBook(book1, book3, book4);
		author2.addBook(book2, book3, book4);
		
//		spring의 저자를 출력한다.
		List<Author> authors = bookRepository.findAll().get(2).getAuthors();
		authors.forEach(System.out::println);
		
//		홍길동이 저술한 도서 목록을 출력한다.
		List<Book> books = authorRepository.findAll().get(0).getBooks();
		books.forEach(System.out::println);
	}
	
//	책 정보를 저장하는 메소드
	private Book givenBook(String name) {
		Book book = new Book();
		book.setName(name);
		return bookRepository.save(book);
	}
	
//	저자 정보를 저장하는 메소드
	private Author givenAuthor(String name) {
		Author author = new Author();
		author.setName(name);
		return authorRepository.save(author);
	}
	
	@Test
	@Transactional
	void manyToManyTest2() {
		System.out.println("AuthorRepositoryTest 클래스의 manyToManyTest2() 메소드 실행");

		Book book1 = givenBook("java");
		Book book2 = givenBook("jsp");
		Book book3 = givenBook("spring");
		Book book4 = givenBook("springBoot");
		
		Author author1 = givenAuthor("홍길동");
		Author author2 = givenAuthor("임꺽정");

//		N:M 연관 관계를 맺는다.
		Relation relation1 = givenRelation(book1, author1);
		Relation relation2 = givenRelation(book2, author2);
		Relation relation3 = givenRelation(book3, author1);
		Relation relation4 = givenRelation(book3, author2);
		Relation relation5 = givenRelation(book4, author1);
		Relation relation6 = givenRelation(book4, author2);
		
		book1.addRelation(relation1);
		book2.addRelation(relation2);
		book3.addRelation(relation3, relation4);
		book4.addRelation(relation5, relation6);
		
		author1.addRelation(relation1, relation3, relation5);
		author2.addRelation(relation2, relation4, relation6);
		
//		도서 정보와 저자 정보를 저장한다.
		bookRepository.saveAll(Lists.newArrayList(book1, book2, book3, book4));
		authorRepository.saveAll(Lists.newArrayList(author1, author2));
		
//		spring의 저자를 출력한다.
		List<Relation> relations1 = bookRepository.findAll().get(2).getRelations();
		for (Relation relation : relations1) {
			System.out.println(relation.getAuthor());
		}
		
//		홍길동이 저술한 도서 목록을 출력한다.
		List<Relation> relations2 = authorRepository.findAll().get(0).getRelations();
		for (Relation relation : relations2) {
			System.out.println(relation.getBook());
		}
	}
	
//	 도서 정보와 저자 정보를 저장하는 메소드
	private Relation givenRelation(Book book, Author author) {
		Relation relation = new Relation();
		relation.setBook(book);
		relation.setAuthor(author);
		return relationRepository.save(relation);
	}
	
}








