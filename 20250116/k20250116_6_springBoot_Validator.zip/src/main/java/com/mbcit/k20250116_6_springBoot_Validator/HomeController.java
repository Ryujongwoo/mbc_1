package com.mbcit.k20250116_6_springBoot_Validator;

import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
public class HomeController {

	@RequestMapping("/")
	public @ResponseBody String home() {
		log.info("HomeController 클래스의 home() 메소드 실행");
		return "Validator 테스트";
	}
	
	@RequestMapping("/insertForm")
	public String insertForm() {
		log.info("HomeController 클래스의 insertForm() 메소드 실행");
		return "insertForm";
	}
	
	@RequestMapping("/create")
//	@ModelAttribute 어노테이션으로 viewpage로 전달되는 커맨드 객체 이름을 변경할 수 있다.
	public String create(@ModelAttribute("vo") ContentVO contentVO, BindingResult bindingResult) {
		log.info("HomeController 클래스의 create() 메소드 실행");
		log.info("{}", contentVO);
	
//		유효성 검사를 위해 작성한 객체를 선언하고 유효성 검사를 실행한다.
		ContentValidator contentValidator = new ContentValidator();
		contentValidator.validate(contentVO, bindingResult);
		
//		유효성 검사시 에러가 발생했다면 입력 화면으로 돌려보낸다.
		String viewpage = "createDone";
		if (bindingResult.hasErrors()) {
			viewpage = "insertForm";
		}
		
		return viewpage;
	}
	
}






