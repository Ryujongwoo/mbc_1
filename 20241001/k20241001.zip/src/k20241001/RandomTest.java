package k20241001;

import java.util.Random;

public class RandomTest {

	public static void main(String[] args) {
		
//		Math.random(): 0이상이고 1미만인 무작위 수(난수)를 발생시킨다.
		System.out.println(Math.random());
//		random() 메소드 실행 결과에 얻어낼 난수 크기를 곱한다.
		System.out.println(Math.random() * 6);
//		얻어낼 난수 크기를 곱한 결과를 캐스팅 해서 정수화 한다.
		System.out.println((int) (Math.random() * 6));
//		난수를 1부터 발생시키려면 캐스팅 결과에 1을 더한다.
		System.out.println((int) (Math.random() * 6) + 1);
		
//		Random 클래스
		Random random = new Random();
		System.out.println(random.nextDouble());
		System.out.println(random.nextInt(6));
		
//		Random 클래스 객체를 만들 때 seed 값을 지정하면 매번 같은 배열의 난수를 발생시킬 수 있다.
		Random random2 = new Random(1000);
		System.out.println(random2.nextDouble());
		System.out.println(random2.nextInt(6));
		
	}
	
}
