package com.mbcit.springBootReact02.service;

import java.security.Key;

import javax.crypto.SecretKey;
import javax.servlet.http.HttpServletRequest;

import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;

import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;

//	JWT를 생성하고 검증하는 클래스
@Component
public class JwtService {

//	클래스 시작 부분에 3개의 상수를 정의해야 한다.
//	JWT 토큰의 만료 시간을 밀리초 단위로 정의한다.
	public static final long EXPIRATIONTIME = 86400000; // 1일을 밀리초로 계산한 값
//	JWT 토큰의 접두사를 정의한다.
	public static final String PREFIX = "Bearer";
//	JWT 토큰의 비밀 키를 정의한다.
//	java.security.Key, io.jsonwebtoken.security.Keys, io.jsonwebtoken.SignatureAlgorithm
//	비밀 키는 jjwt 라이브러리의 secretKeyFor() 메소드로 생성한다.
//	시연 용도로는 이것으로 충분하지만 운영 환경에서는 애플리케이션의 구성에서 비밀 키를 읽어야 한다.
	public static final Key KEY = Keys.secretKeyFor(SignatureAlgorithm.HS256);
//	javax.crypto.SecretKey
//	public static final SecretKey KEY = Keys.secretKeyFor(SignatureAlgorithm.HS256);
	
//	서명된 JWT 토큰을 생성하고 반환한다.
	public String getToken(String username) {
		System.out.println("JwtService 클래스의 getToken() 메소드 실행");
		String token = "";
		return token;
	}
	
//	요청 권한 부여 헤더(Authorization)에서 토근을 가져와 토큰을 확인하고 사용자 이름을 얻는다.
	public String getAuthUser(HttpServletRequest request) {
		System.out.println("JwtService 클래스의 getAuthUser() 메소드 실행");
//		org.springframework.http.HttpHeaders
		String token = request.getHeader(HttpHeaders.AUTHORIZATION);
		return null;
	}
	
}












