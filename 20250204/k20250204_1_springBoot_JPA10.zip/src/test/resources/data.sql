insert into score(name, java, spring) values ('홍길동', 100, 90);
insert into score(name, java, spring) values ('임꺽정', 70, 80);
insert into score(name, java, spring) values ('장길산', 75, 82);
insert into score(name, java, spring) values ('일지매', 88, 79);




