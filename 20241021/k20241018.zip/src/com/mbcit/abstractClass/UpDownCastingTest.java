package com.mbcit.abstractClass;

// 부모 클래스
class Base {
	
//	package 접근 권한은 같은 package에서는 public 처럼 사용되고 다른 package에서는
//	private 처럼 사용된다.
	String name; // 접근 권한 지정자를 생략했으므로 package 권한을 의미한다.
	
	void say() {
		System.out.println(name + "님 안녕하세요");
	}
	
}

//	자식 클래스
class Sub extends Base {
	
	int age;

	@Override
	void say() {
		System.out.println(name + "님은 " + age + "살 입니다.");
	}
	
}

public class UpDownCastingTest {

	public static void main(String[] args) {
		
//		부모 클래스 타입에 부모 클래스 타입의 객체를 만들어 넣어주면 아무 문제없이 처리된다.
		Base base = new Base();
		base.name = "홍길동";
		base.say();
		System.out.println("====================================");
		
//		자식 클래스 타입에 자식 클래스 타입의 객체를 만들어 넣어주면 아무 문제없이 처리된다.
		Sub sub = new Sub();
		sub.name = "임꺽정";
		sub.age = 20;
		sub.say();
		System.out.println("====================================");
		
//		결론 => 부모 클래스가 자식 클래스를 제어할 수 있지만 자식 클래스는 부모 클래스를 제어할 수 없다.
		
//		부모 클래스 타입에 자식 클래스 타입의 객체를 만들어 넣어주면 아무 문제없이 처리된다.
//		Base b = new Sub(); // UpCasting
//		b.say();
		
//		자식 클래스 타입에 부모 클래스 타입의 객체를 넣어주면 에러가 발생된다.
//		Sub s = new Base(); // 에러
//		자식 클래스 타입에 부모 클래스 타입의 객체를 넣어줄 때 형변환하면 문법적인 에러는 발생하지 않지만
//		프로그램을 실행하면 ClassCastException이 발생된다.
//		Sub s = (Sub) new Base(); // 예외발생
		
//		UpCasting: 부모 클래스 타입의 객체에 자식 클래스 타입의 객체를 대입한다.
		Base b = sub; // UpCasting
//		b는 부모 클래스 타입의 객체지만 자식 클래스 타입의 객체를 대입했으므로 say() 메소드를 실행하면
//		부모 클래스의 say() 메소드가 아닌 자식 클래스의 say() 메소드가 실행된다.
		b.say();
		
//		DownCasting: 부모 클래스 타입으로 UpCasting된 자식 클래스 객체를 다시 자식 클래스 타입으로 
//		변환하는 것을 말한다.
		Sub s = (Sub) b; // DownCasting
		s.say();
		
//		instanceof 연산자는 어떤 객체가 instanceof 뒤에 지정한 클래스 타입으로 안전하게 형변환이 가능한지
//		검사하는 연산자이다.
		if (b instanceof Sub) {
			System.out.println("형변환 가능");
		} else {
			System.out.println("형변환 불가능");
		}
		
		try {
			Sub ss = (Sub) b;
			System.out.println("형변환 가능");
		} catch (ClassCastException e) {
			System.out.println("형변환 불가능");
		}
		
	}
	
}

























