package com.mbcit.k20250121_1_springBoot_JPA01.domain;

import java.time.LocalDateTime;

//	@PrePersist, @PreUpdate 어노테이션을 붙여서 선언한 엔티티 이벤트 메소드로 실행하던 멤버 초기화를
//	엔티티 리스터로 하기 위해 엔티티 이벤트로 초기화 하던 필드의 setter 메소드를 추상 메소드로 가지는
//	인터페이스를 선언한다.
//	이렇게 선언한 인터페이스는 이벤트 리스너를 사용할 클래스에 구현해서 사용한다.
public interface Auditable {

//	LocalDateTime getCreateDate();
//	LocalDateTime getUpdateDate();
	void setCreateDate(LocalDateTime createDate);
	void setUpdateDate(LocalDateTime updateDate);
	
}
