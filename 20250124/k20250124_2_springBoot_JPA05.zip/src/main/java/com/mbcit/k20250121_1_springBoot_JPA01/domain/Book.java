package com.mbcit.k20250121_1_springBoot_JPA01.domain;

import java.time.LocalDateTime;

import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;

import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Data
@Entity
@EntityListeners(value = MyEntityListener.class)
public class Book implements Auditable {

	@Id
	@GeneratedValue
	private Long id;
	
	private String name;
	private String author;
	private LocalDateTime createDate;
	private LocalDateTime updateDate;
	
//	엔티티 리스너를 이용해서 @PrePersist, @PreUpdate 엔티티 이벤트를 구현할것이므로 기존에 사용하던
//	엔티티 이벤트 메소드는 제거한다.
//	@PrePersist // 엔티티 이벤트
//	public void prePersist() {
//		System.out.println("Book 엔티티의 prePersist() 메소드 실행됨");
//		createDate = LocalDateTime.now();
//		updateDate = LocalDateTime.now();
//	}
	
//	@PreUpdate // 엔티티 이벤트
//	public void preUpdate() {
//		System.out.println("Book 엔티티의 preUpdate() 메소드 실행됨");
//		updateDate = LocalDateTime.now();
//	}
	
}












