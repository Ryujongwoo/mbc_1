package com.mbcit.register;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/RegisterCheck")
public class RegisterCheck extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public RegisterCheck() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// System.out.println("RegisterCheck 컨트롤러의 doGet() 메소드 실행");
		actionDo(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// System.out.println("RegisterCheck 컨트롤러의 doPost() 메소드 실행");
		actionDo(request, response);
	}
	
	protected void actionDo(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		System.out.println("RegisterCheck 컨트롤러의 actionDo() 메소드 실행");
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html; charset=UTF-8");
		
		String id = request.getParameter("id").trim();
		// System.out.println(id);
		int result = new RegisterDAO().registerCheck(id);
		
		/*
		if (result == 1) {
			request.getSession().setAttribute("messageType", "오류 메시지: ");
			request.getSession().setAttribute("messageContent", "중복 검사할 id를 입력하세요.");
		} else if (result == 2) {
			request.getSession().setAttribute("messageType", "오류 메시지: ");
			request.getSession().setAttribute("messageContent", "이미 사용 중인 아이디입니다.");
		} else {
			request.getSession().setAttribute("messageType", "성공 메시지: ");
			request.getSession().setAttribute("messageContent", "사용 가능한 아이디입니다.");
		}
		response.sendRedirect("index.jsp");
		*/  // ①
		
		response.getWriter().write(result + "");
	}

}














