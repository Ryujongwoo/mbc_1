package com.mbcit.genericTest2;

//	3D 프린터 재료 - Plastic
public class Plastic implements Material {
//	public class Plastic extends Material {

	@Override
	public String toString() {
		return "Plastic";
	}

}
