package com.mbcit.synchronizedMethodTest;

public class Student extends Thread {

//	부모(Thread) 클래스의 스레드 이름(도서를 대여하는 학생 이름)을 인수로 넘겨받는 생성자를
//	호출해서 스레드가 생성될 때 스레드의 이름을 지정한다.
	public Student() { }
	public Student(String name) {
		super(name);
	}
	
	@Override
	public void run() {
		
		try {
			String book = LibraryMain.library.lendBook(); // 도서 대여
			sleep(2500); // 대여 기간
			LibraryMain.library.returnBook(book); // 도서 반납
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
	}
	
}
