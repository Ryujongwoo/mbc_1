package com.mbcit.k20250121_1_springBoot_JPA01.domain;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@NoArgsConstructor
@Data
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
@Entity
public class Review extends BaseEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private String title;
	private String content;
	private float score;
//	private Long bookId;
//	private Long memberId;
	
//	book_id와 member_id를 매핑하기 위해서 연관 관계를 설정한다.
//	Review 엔티티와 Member 엔티티는 N:1 관계 이므로 @ManyToOne 어노테이션으로 설정한다.
	@ManyToOne
	private Member member;
//	Review 엔티티와 Book 엔티티는 N:1 관계 이므로 @ManyToOne 어노테이션으로 설정한다.
	@ManyToOne
	private Book book;
	
}













