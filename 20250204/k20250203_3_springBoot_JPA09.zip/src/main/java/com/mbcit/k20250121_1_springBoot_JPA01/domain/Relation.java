package com.mbcit.k20250121_1_springBoot_JPA01.domain;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@NoArgsConstructor
@Data
@Entity
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class Relation extends BaseEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

//	Relation 엔티티와 Book 엔티티는 N:1 관계이므로 @ManyToOne 어노테이션을 사용해서 N:1 관계로 설정한다.
	@ManyToOne
	private Book book;
	
//	Relation 엔티티와 Author 엔티티는 N:1 관계이므로 @ManyToOne 어노테이션을 사용해서 N:1 관계로 설정한다.
	@ManyToOne
	private Author author;
	
}












