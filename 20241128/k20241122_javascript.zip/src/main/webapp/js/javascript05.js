//	자바스크립트 객체
const dog = {
//	key: value
	name: '강아지',
	age: 2
}

console.log(dog);
console.log(dog.name);
console.log(dog.age);

//	dog = 'abc'; 상수에는 값을 할당할 수 없으므로 에러가 발생된다.
//	const로 선언한 객체를 구성하는 멤버의 값을 변경할 때는 에러가 발생되지 않는다.
dog.name = '고양이';
console.log(dog);
console.log('============================');

const ironMan = {
	name: '토니 스타크',
	actor: '로버트 다우니 주니어',
	alias: '아이언맨'
}
console.log(ironMan);

captionAmerica = {
	name: '스티븐 로저스',
	actor: '크리스 에반스',
	alias: '캡틴아메리카'
}
console.log(captionAmerica);
console.log('============================');

function print(hero) {
	console.log(`${hero.alias}(${hero.name}) 역할을 맡은 배우는 ${hero.actor} 입니다.`);
}
print(ironMan);

const print2 = hero => console.log(`${hero.alias}(${hero.name}) 역할을 맡은 배우는 ${hero.actor} 입니다.`);

print2(captionAmerica);
console.log('============================');

//	객체 비구조화 할당 => 객체 구조 분해
function heroPrint(hero) {
//	인수 hero로 받은 객체 내부의 값을 외부로 꺼내온다.
//	객체 비구조화 할당을 통해서 객체 내부의 값을 꺼내서 저장할 변수 이름은 객체에서 사용한 key와 반드시 같은
//	이름을 사용해야 한다. => key와 다른 이름을 사용하면 undefined가 저장된다.
//	형식: const {변수명, ...} = 객체이름
	const {name1, actor, alias} = hero;
	console.log(`${alias}(${name1}) 역할을 맡은 배우는 ${actor} 입니다.`);
}
heroPrint(ironMan);
heroPrint(captionAmerica);
console.log('============================');

//	객체를 함수의 인수로 받을 때 객체 비구조화 할당을 바로 사용할 수 있다. 
function heroPrint2({name, actor, alias}) {
//	const {name, actor, alias} = hero;
	console.log(`${alias}(${name}) 역할을 맡은 배우는 ${actor} 입니다.`);
}
heroPrint2(ironMan);
heroPrint2(captionAmerica);
console.log('============================');

//	객체 비구조화 할당은 함수 외부에서도 사용할 수 있다.
let {name, actor, alias} = ironMan;
console.log(name);
console.log(actor);
console.log(alias);

