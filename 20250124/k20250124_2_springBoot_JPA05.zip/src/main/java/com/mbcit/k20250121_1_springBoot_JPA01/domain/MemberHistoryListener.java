package com.mbcit.k20250121_1_springBoot_JPA01.domain;

import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;

import org.springframework.beans.factory.annotation.Autowired;

import com.mbcit.k20250121_1_springBoot_JPA01.repository.MemberHistoryRepository;
import com.mbcit.k20250121_1_springBoot_JPA01.support.BeanUtils;

//	Member 엔티티에 데이터가 입력되거나 수정되면 입력 및 수정 내역을 MemberHistory 엔티티에
//	저장하는 기능을 실행하는 리스너
public class MemberHistoryListener {

//	엔티티 리스너는 @Autowired에 의해서 자동으로 bean을 주입받지 못한다.
	@Autowired
	private MemberHistoryRepository memberHistoryRepository;
	
//	insert, update 명령이 실행되기 전에 실행하는 내용이 같다면 @PrePersist, @PreUpdate 어노테이션을
//	따로 사용해서 메소드를 만들 필요가 없고 @PrePersist, @PreUpdate 어노테이션을 모두 사용해서 
//	메소드를 만들면 insert, update 명령이 실행되기 전에 같은 내용이 실행된다.
	@PrePersist
	@PreUpdate
	public void prePersistAndPreUpdate(Object object) {
		System.out.println("MemberHistoryListener 리스너의 prePersistAndPreUpdate() 메소드 실행됨");
//		@Autowired를 사용하면 자동으로 bean을 주입받지 못하기 때문에 null이 출력된다.
		System.out.println("memberHistoryRepository: " + memberHistoryRepository);
		
//		엔티티 리스너는 @Autowired에 의해서 자동으로 bean을 주입받지 못하기 때문에 bean을 주입받기 위해서
//		만든 BeanUtils 클래스 객체를 사용해서 bean을 주입받는다.
//		BeanUtils 클래스의 getBean() 메소드를 실행해서 MemberHistoryRepository의 bean을 주입한다.
		memberHistoryRepository = BeanUtils.getBean(MemberHistoryRepository.class);
		System.out.println("memberHistoryRepository: " + memberHistoryRepository);
		
		Member member = (Member) object;
		MemberHistory memberHistory = new MemberHistory();
		memberHistory.setMemberId(member.getId());
		memberHistory.setName(member.getName());
		memberHistory.setEmail(member.getEmail());
		memberHistoryRepository.save(memberHistory);
	}
	
}












