$('#emp_search').click(function () {
	let empid = $('#empid').val();
	if (!isNaN(empid) && empid.trim().length === 3) {
		
		$.ajax({
			url: 'emplist.xml',
			method: 'GET',
			dataType: 'xml',
			success: data => {
				let empInfo = $(data).find('EMPLOYEE_ID:contains(' + empid + ')').parent();
				if ($(empInfo).is('ROW')) {
					// 데이터가 출력될 테이블이 있을 때
					// $('table input').each(index => $('table input').eq(index).val($(empInfo).children().eq(index).text()));
					
					// body 태그 내부에 table을 만들고 xml 파일에서 읽어온 데이터를 넣어주는 함수를 실행한다.
					$('body').append(makeTable(empInfo));
				} else {
					alert(empid + '번은 존재하지 않는 사원번호 입니다.');
					$('#empid').val('');
					$('#empid').focus();
				}
			},
			error: error => {
				alert('요청 실패');
				console.log(error.status + ': ' + error.statusText);
			}
		});
	} else {
		alert('정확한 사원 번호를 입력하세요');
		$('#empid').val('');
		$('#empid').focus();
	}
});

//	테이블을 만들고 xml 파일에서 얻어온 데이터를 테이블에 넣어서 리턴하는 함수
function makeTable(empInfo) {
//	console.log(empInfo.html());
//	테이블을 만든다.
	let $table = $('<table border="1">'); // <table border="1"></table>
	
//	테이블에 추가할 첫 행(머리글 행)을 만들어 테이블에 추가한다.
	/*
//	테이블에 추가할 행을 만든다.
	let $tr = $('<tr>'); // <tr></tr>
//	xml 파일에서 읽어온 사원번호에 해당되는 데이터(ROW 태그의 자식 요소)의 개수만큼 반복하며 행에 열을 추가한다.
	for (let i = 0; i < empInfo.children().length; i++) {
		// 행에 추가할 열을 만든다.
		let $th = $('<th>'); // <th></th>
		// 열에 사원 정보를 넣어준다.
		// console.log(empInfo.children().eq(i).prop('tagName'));
		$th.html(empInfo.children().eq(i).prop('tagName')); // <th>EMPLOYEE_ID</th>
		// 열을 행에 추가한다.
		$tr.append($th);
	}
//	테이블에 행을 추가한다.
	$table.append($tr);
	*/
	
	let tr = `
		<tr>
			<th>사원번호</th>
			<th>이름</th>
			<th>이메일</th>
			<th>내선번호</th>
			<th>입사일</th>
		</tr>
	`;
	$table.append(tr);
	
//	테이블에 추가할 데이터 행을 만들어서 테이블에 추가한다.
	/*
	let $tr = $('<tr>');
	for (let i = 0; i < empInfo.children().length; i++) {
		let $td = $('<td>');
		$td.html(empInfo.children().eq(i).text());
		$tr.append($td);
	}
	$table.append($tr);
	*/
	
	tr = `
		<tr>
			<th>${empInfo.children().eq(0).text()}</th>
			<th>${empInfo.children().eq(1).text()}</th>
			<th>${empInfo.children().eq(2).text()}</th>
			<th>${empInfo.children().eq(3).text()}</th>
			<th>${empInfo.children().eq(4).text()}</th>
		</tr>
	`;
	$table.append(tr);
	
//	테이블을 리턴시킨다.
	return $table;
}
























