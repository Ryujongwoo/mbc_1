import { Button, Snackbar, Stack, TextField } from "@mui/material";
import React, { useState } from "react";
import { SERVER_URL } from "../constants";
import CarList from "./CarList";

function Login() {

  // username과 password를 기억할 user라는 상태를 만들고 공백으로 초기화 한다.
  const [user, setUser] = useState({ username: '', password: '' });
  // 인증 상태를 기억할 auth라는 상태를 만들고 false로 초기화 한다.
  const [auth, setAuth] = useState(false);

  // TextField에 입력한 값으로 user 상태를 변경하는 함수를 만든다.
  const handleChange = event => {
    setUser({...user, [event.target.name]: event.target.value});
  }

  // Snackbar 컴포넌트 표시 여부를 기억할 open 이라는 상태를 만들고 false로 초기화 한다.
  const [open, setOpen] = useState(false);

  // 로그인 처리를 하는 함수를 만든다.
  const login = function () {
    // 로그인을 하기 위해서는 body에 user 상태를 포함하고 POST 방식으로 /login 엔드포인트를
    // 호출해야 한다.
    fetch(SERVER_URL + 'login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(user)
    })
    .then(response => {
      // 로그인을 성공하면 Authorization 헤더 정보를 받는다. 실패하면 null 이다.
      // console.log(response.headers.get('Authorization'));
      const jwtToken = response.headers.get('Authorization');
      if (jwtToken !== null) {
        // 로그인이 성공하면 Authorization 헤더 정보를 세션에 넣어준다.
        // 세션은 페이지 세션이 끝나면 자동으로 삭제된다.
        sessionStorage.setItem('jwt', jwtToken);
        // 로그인이 성공하면 로그인 상태를 기억하는 auth 상태를 true로 변경한다.
        setAuth(true);
      } else {
        // 로그인이 실패하면 Snackber 컴포넌트를 표시여부를 기억하는 open 상태를 true로 수정한다.
        setOpen(true);
      }
    })
    .catch(error => console.log(error))
  }

  // 로그인 여부를 기억하는 상태인 auth에 따른 조건부 렌더링을 실행한다.
  if (auth) {
    // auth 상태가 true(로그인 상태)면 CarList 컴포넌트를 렌더링한다.
    return <CarList/>
  } else {
    // auth 상태가 false(로그인 상태가 아니)면 Login 컴포넌트를 렌더링한다.
    return (
      <div>
        {/* 로그아웃 상태일 때 화면에 출력될 내용 */}
        <Stack spacing={2} mt={5} alignItems="center">
          <TextField name="username" label="Username" onChange={handleChange} value={user.username} />
          <TextField name="password" label="Password" onChange={handleChange} value={user.password} />
          <Button variant="outlined" color="primary" onClick={login}>Login</Button>
        </Stack>
        <Snackbar
          open={open} 
          autoHideDuration={3000} 
          onClose={() => {
            setOpen(false);
            setUser({username: '', password: ''});
          }}
          message='로그인 실패: 사용자 이름과 비밀번호를 확인하세요'
        />
      </div>
    );
  }

}

export default Login;