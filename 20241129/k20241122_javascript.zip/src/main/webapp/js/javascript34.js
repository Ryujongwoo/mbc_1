function searchParent() {
	let child = document.getElementsByTagName('p')[0];
	console.log(child);
//	nodeName은 탐색된 요소의 태그 이름을 얻어온다.
	console.log(child.nodeName);
	
//	parentNode는 탐색된 요소의 부모 요소를 탐색한다.
	let parent = child.parentNode;
	console.log(parent);
	parent.style.backgroundColor = 'hotpink';
	console.log(parent.nodeName);
}

function searchChild() {
	let parent = document.querySelectorAll('div')[0];
	console.log(parent);
	
//	children은 탐색된 요소의 자식 요소를 탐색한다. => 태그만 탐색한다.
	let child1 = parent.children;
	console.log(child1);
	console.log(child1[0]); // p
	console.log(child1[1]); // p
	console.log(child1[2]); // p
	
	child1[0].style.backgroundColor = 'skyblue';
	child1[1].style.backgroundColor = 'dodgerblue';
	child1[2].style.backgroundColor = 'tomato';
	
//	childNodes는 탐색된 요소의 자식 요소를 탐색한다. => 태그 및 텍스트도 탐색한다.
	let child2 = parent.childNodes;
	console.log(child2);
	console.log(child2[0]); // 텍스트1
	console.log(child2[1]); // p
	console.log(child2[2]); // 텍스트2
	console.log(child2[3]); // p
	console.log(child2[4]); // 텍스트3
	console.log(child2[5]); // p
	console.log(child2[6]); // 텍스트4
	
//	일반 텍스트에는 스타일을 적용할 수 없다.
//	child2[0].style.color = 'red';
	child2[1].style.color = 'red';
	child2[3].style.color = 'green';
	child2[5].style.color = 'blue';
}

function searchTest() {
	let test1 = document.getElementsByTagName('p')[3];
	console.log(test1);
	let div = test1.parentNode;
	console.log(div);
	div.style.backgroundColor = 'hotpink';
	
	let test4 = document.querySelectorAll('div')[3];
	console.log(test4);
	let childs = test4.childNodes;
	console.log(childs);
	console.log(childs[3]);
	childs[3].style.fontSize = '30px';
}

