package com.mbcit.springBootReact02;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import com.mbcit.springBootReact02.service.UserDetailServiceImpl;

//	스프링 시큐리티가 작동하는 방법을 구성하려면 WebSecurityConfigurerAdapter 클래스를 상속받아
//	새 클래스를 추가해야 한다.
//	WebSecurityConfigurerAdapter 클래스는 springBoot 2.7에서 지원이 중단되었다.
//	@Configuration, @EnableWebSecurity 어노테이션으로 이 클래스에서 기본 웹 보안 구성을 비활성화하고
//	자체 구성을 정의할 수 있다.
@Configuration
@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter {

	@Autowired
	private UserDetailServiceImpl userDetailServiceImpl;
	
//	필터 클래스를 스프링 시큐리티 구성에 추가하기 위해서 AuthenticationFilter 클래스의 인스턴스를
//	주입한다.
	@Autowired
	private AuthenticationFilter authenticationFilter;
	
//	인증 예외 처리 클래스를 스프링 시큐리티 구성에 추가하기 위해서 AuthEntryPoint 클래스의 
//	인스턴스를 주입한다.
	@Autowired
	private AuthEntryPoint authEntryPoint;
	
//	애플리케이션의 보호되는 엔드포인트와 보호되지 않는 엔드포인트 configure(HttpSecurity http)
//	메소드로 정의할 수 있다.
//	스프링 시큐리티의 configure() 메소드는 보호되는 경로와 그렇치 않은 경로를 정의한다.
	@Override
	protected void configure(HttpSecurity http) throws Exception {
//		"/login" 엔드포인트에 대한 POST 요청은 인증 없이도 허용되야하지만 다른 모든 엔드포인트에
//		대한 POST 요청은 인증이 필요하도록 설정한다.
		http.csrf().disable().cors().and()
			.sessionManagement()
			.sessionCreationPolicy(SessionCreationPolicy.STATELESS).and()
			.authorizeHttpRequests()
			.antMatchers(HttpMethod.POST, "/login").permitAll()
			.anyRequest().authenticated().and()
			.exceptionHandling().authenticationEntryPoint(authEntryPoint).and()
			.addFilterBefore(authenticationFilter, UsernamePasswordAuthenticationFilter.class);
	}

	/*
//	userDetailsService() 메소드를 Override해서 인메모리 사용자를 애플리케이션에 추가할 수 있다.
//	애플리케이션 개발 과정에서는 인메모리 사용자를 이용해도 되지만 실제 애플리케이션에서는
//	사용자를 데이터베이스에 저장해야 한다.
	@Bean
	@Override
	protected UserDetailsService userDetailsService() {
//		withDefaultPasswordEncoder() 메소드는 시연 목적에만 적합하며 실제 운영 단계에서는 안전
//		문제로 적합하지 않다.
		UserDetails user = User.withDefaultPasswordEncoder()
				.username("user") // 사용자 이름
				.password("password") // 비밀 번호
				.roles("USER") // 사용자 권한
				.build();
		return new InMemoryUserDetailsManager(user);
	}
	*/
	
//	인메모리 사용자를 만들어주는 userDetailsService() 메소드를 비활성화하고 데이터베이스에서
//	사용자를 활성화하는 메소드를 추가한다.
	@Autowired
	public void configureGlobal(AuthenticationManagerBuilder auth) throws Exception {
//		암호는 일반 텍스트로 데이터베이스에 저장하면 안되므로 BCryptPasswordEncoder 클래스를 이용하여
//		bcrypt 알고리즘으로 인코딩한다.
		auth.userDetailsService(userDetailServiceImpl).passwordEncoder(new BCryptPasswordEncoder());
	}
	
//	LoginController에 AuthenticationManager를 주입했으므로 다음 코드를 추가한다.
	@Bean
	public AuthenticationManager getAuthenticationManager() throws Exception {
		return authenticationManager();
	}
	
//	클래스에 전역 CORS 필터를 추가한다.
//	org.springframework.web.cors.CorsConfigurationSource
//	org.springframework.web.cors.UrlBasedCorsConfigurationSource
	@Bean
	public CorsConfigurationSource corsConfigurationSource() {
		UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
		CorsConfiguration configuration = new CorsConfiguration();
//		허용되는 출처를 지정한다.
		configuration.setAllowedOrigins(Arrays.asList("*")); // 모든 출처를 허용한다.
//		출처를 명시적으로 정의하려면 다음과 같이 설정하면 된다.(react의 port는 3000번)
//		configuration.setAllowedOrigins(Arrays.asList("http://localhost:3000")); // react만 허용한다.
//		허용되는 요청 방식을 지정한다.
		configuration.setAllowedMethods(Arrays.asList("*"));
//		헤더 목록을 지정한다.
		configuration.setAllowedHeaders(Arrays.asList("*"));
		configuration.setAllowCredentials(false);
		configuration.applyPermitDefaultValues();
		
		source.registerCorsConfiguration("/**", configuration);
		return source;
	}
	
}

















