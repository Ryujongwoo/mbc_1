package com.mbcit.abstractClass;

import java.util.ArrayList;
import java.util.List;

abstract class Animal {
	
	public abstract void move();
	public void eating() { }
	
}

//	Human 클래스는 Animal 클래스를 상속받아 만든다.
class Human extends Animal {

	@Override
	public void move() {
		System.out.println("사람은 두 발로 걷습니다.");
	}
	
	public void readBook() {
		System.out.println("사람이 책을 읽습니다.");
	}
	
}

//	Tiger 클래스는 Animal 클래스를 상속받아 만든다.
class Tiger extends Animal {

	@Override
	public void move() {
		System.out.println("호랑이는 네 발로 걷습니다.");
	}
	
	public void hunting() {
		System.out.println("호랑이가 사냥을 합니다.");
	}
	
}

//	Eagle 클래스는 Animal 클래스를 상속받아 만든다.
class Eagle extends Animal {

	@Override
	public void move() {
		System.out.println("대머리 독수리가 하늘을 날아갑니다.");
	}
	
	public void flying() {
		System.out.println("하늘을 날다보니 대머리가 되었답니다.");
	}
	
}

public class PolymorphismTest2 {

	public static void main(String[] args) {
		
//		PolymorphismTest 클래스에서는 아래와 같이 실행했었다.
		Animal[] animals = {new Human(), new Tiger(), new Eagle()};
		animals[0].move();
		animals[1].move();
		animals[2].move();
		System.out.println("====================================");
		
//		UpCasting: 자식 => 부모
		Animal hanimal = new Human();
		Animal tanimal = new Tiger();
		Animal eanimal = new Eagle();
		
//		main() 메소드는 static으로 선언된 메소드이기 때문에 static으로 선언된 메소드에만
//		접근할 수 있으므로 moveAnimal() 메소드는 반드시 static으로 선언해야 한다.
//		아래와 같이 main() 메소드에서 직접 실행하는 메소드들은 반드시 static으로 선언한다.
		moveAnimal(hanimal);
		moveAnimal(tanimal);
		moveAnimal(eanimal);
		System.out.println("====================================");
		
//		현재 클래스 자신의 객체를 생성해서 메소드를 실행하면 static으로 선언하지 않은
//		메소드로 실행할 수 있다.
		PolymorphismTest2 polymorphismTest2 = new PolymorphismTest2();
		polymorphismTest2.moveAnimal2(hanimal);
		polymorphismTest2.moveAnimal2(tanimal);
		polymorphismTest2.moveAnimal2(eanimal);
		System.out.println("====================================");
		
		ArrayList<Animal> animalsList = new ArrayList<Animal>();
//		List<Animal> animalsList = new ArrayList<Animal>();
		animalsList.add(hanimal);
		animalsList.add(tanimal);
		animalsList.add(eanimal);
		
		for (Animal animal : animalsList) {
			animal.move();
		}
		System.out.println("====================================");
		
		for (int i = 0; i < animalsList.size(); i++) {
			Animal animal = animalsList.get(i);
//			DownCasting: UpCasting된 클래스를 다시 원래 타입으로 형변환시킨다.
//			instanceof 연산자를 이용해서 형변환이 가능한지 확인 후 DownCasting을 실행한다.
			if (animal instanceof Human) {
				Human human = (Human) animal; // DownCasting, 부모에 저장된 자식 => 자식
				human.readBook();
			} else if (animal instanceof Tiger) {
				Tiger tiger = (Tiger) animal;
				tiger.hunting();
			} else if (animal instanceof Eagle) {
				Eagle eagle = (Eagle) animal;
				eagle.flying();
			} else {
				System.out.println("DownCasting 불가능");
			}
		}
		
	}

	private static void moveAnimal(Animal animal) {
		animal.move();
	}
	
	private void moveAnimal2(Animal animal) {
		animal.move();
	}
	
}



















