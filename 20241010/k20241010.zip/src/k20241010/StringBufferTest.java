package k20241010;

public class StringBufferTest {

	public static void main(String[] args) {
		
		String java = new String("java");
		System.out.println(java);
//		identityHashCode(): 문자열이 메모리에 생성된 주소를 보여준다.
		System.out.println(System.identityHashCode(java));
		
		String java2 = new String("java");
		System.out.println(java2);
		System.out.println(System.identityHashCode(java2));
		
		java = java + java2;
		System.out.println(java);
//		문자열을 연결하면 기존 문자열에 연결되는 것이 아니고 새로운 문자열 객체가 생성된다.
		System.out.println(System.identityHashCode(java));
		
//		concat(): "+" 연산자를 사용한것처럼 문자열을 연결한다.
		java = java.concat(java2);
		System.out.println(java);
		System.out.println(System.identityHashCode(java));
		
		String str = "";
		long start = System.currentTimeMillis(); // 시작 시간
		for (int i = 0; i < 100000; i++) {
			str += "꽝";
		}
		System.out.println("실행 시간: " + (System.currentTimeMillis() - start));
		System.out.println("'+' 연산자로 꽝 10만번 연결하기");
		System.out.println("==================================================");
		
		String html = new String("html");
//		StringBuilder는 String 처럼 문자열을 매번 새로 만들지 않고 내부적으로 char 배열로 변경한다.
		StringBuilder builder = new StringBuilder(html);
		System.out.println(builder);
		System.out.println(System.identityHashCode(builder));
		
		StringBuilder str2 = new StringBuilder("");
		start = System.currentTimeMillis();
		for (int i = 0; i < 100000; i++) {
//			StringBuilder는 문자열을 연결할때 "+"를 사용하지 않고 append() 메소드를 사용한다.
			str2.append("꽝");
		}
		System.out.println("StringBuilder 실행 시간: " + (System.currentTimeMillis() - start));
		System.out.println("StringBuilder를 이용해서 꽝 10만번 연결하기");
		System.out.println("==================================================");
		
//		StringBuffer는 멀티 스레드 프로그램에서 동기화(순서를 정한다)를 보장하므로 멀티 스레드 프로그램은
//		StringBuffer를 사용하고 싱글(단일) 스레드 프로그램은 StringBuilder를 사용하는 것을 권장한다.
		
		StringBuffer str3 = new StringBuffer("");
		start = System.currentTimeMillis();
		for (int i = 0; i < 100000; i++) {
//			StringBuffer는 문자열을 연결할때 "+"를 사용하지 않고 append() 메소드를 사용한다.
			str3.append("꽝");
		}
		System.out.println("StringBuffer 실행 시간: " + (System.currentTimeMillis() - start));
		System.out.println("StringBuffer를 이용해서 꽝 10만번 연결하기");
		System.out.println("==================================================");
		
//		text block => JDK 13에서 추가
//		문자열을 """와 """ 사이에 입력하면 \n을 사용하지 않고 엔터키로 줄바꿈되는 여러줄 문자열을
//		만들어 사용할 수 있다.
		String strBlock = """
				개울가에
				올챙이 한마리
				꼬물꼬물 헤엄치다
				앞다리가 쑤욱
				뒷다리가 쏘옥
				팔딱팔딱 메뚜기됐네
				""";
		System.out.println(strBlock);
		
	}
	
}
















