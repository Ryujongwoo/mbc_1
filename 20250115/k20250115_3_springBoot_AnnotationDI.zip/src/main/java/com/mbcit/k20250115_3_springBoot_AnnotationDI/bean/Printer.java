package com.mbcit.k20250115_3_springBoot_AnnotationDI.bean;

public interface Printer {

	public abstract void print(String message);
	
}
