package com.mbcit.k20250116_5_springBoot_Lombok;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.extern.slf4j.Slf4j;

//	lombok 어노테이션
//	@NoArgsConstructor: 기본 생성자 자동 생성
//	@AllArgsConstructor: 모든 멤버를 초기화 시키는 생성자 자동 생성
//	@RequiredArgsConstructor:  @NonNull 어노테이션을 붙여준 멤버를 초기화 시키는 생성자 자동 생성
//	@Getter: 클래스에 붙여주면 모든 멤버의 멤버에 붙여주면 그 멤버만 getter 자동 생성
//	@Setter: 클래스에 붙여주면 모든 멤버의 멤버에 붙여주면 그 멤버만 setter 자동 생성
//	@ToString:  toString() 메소드를 override
//	@EqualsAndHashCode: equals(), hashCode() 메소드 override
//	@Data: @Getter, @Setter, @ToString, @EqualsAndHashCode 어노테이션을 모두 붙여준다.
//	@Slf4j: lombok이 지원하는 로그를 사용
@NoArgsConstructor
@AllArgsConstructor
@RequiredArgsConstructor
//	@Getter
//	@Setter
//	@ToString
//	@EqualsAndHashCode
@Data
@Slf4j
public class Member {

//	@NonNull 어노테이션을 붙여준 필드는 null 값을 가질 수 없다.
	@NonNull
	private String id;
//	@ToString.Exclude 어노테이션을 붙여준 필드는 toString() 메소드에서 사용하지 않는다.
	@ToString.Exclude
	private String name;
	
}









