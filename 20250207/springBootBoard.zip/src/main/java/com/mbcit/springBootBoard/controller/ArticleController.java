package com.mbcit.springBootBoard.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.mbcit.springBootBoard.dto.ArticleForm;
import com.mbcit.springBootBoard.entity.Article;
import com.mbcit.springBootBoard.repository.ArticleRepository;

import lombok.extern.slf4j.Slf4j;

@Controller
@Slf4j
public class ArticleController {

//	article 테이블에 JPA를 이용해서 sql 명령을 실행해야 하므로 ArticleRepository 인터페이스 객체를
//	선언하고 @Autowired 어노테이션을 이용해서 초기화 한다.
//	@Autowired 어노테이션은 springBoot가 미리 생성해놓은 bean(객체)을 가져다 자동으로 초기화 시킨다.
	@Autowired
	private ArticleRepository articleRepository;
	
//	데이터를 입력하는 폼을 띄우는 요청
	@GetMapping("/articles/new")
	public String newArticleForm() {
//		@Slf4j 어노테이션 로그 레벨, 로그는 반드시 문자열로 지정한다.
//		log.trace("가장 디테일한 로그");
//		log.warn("경고 로그");
//		log.info("정보성 로그");
//		log.debug("디버깅용 로그");
//		log.error("에러 로그");
		log.info("ArticleController의 newArticleForm() 메소드 실행");
		return "articles/new";
	}
	
//	폼에 입력한 데이터를 테이블에 저장하는 요청
	@PostMapping("/articles/create")
//	form에서 넘어오는 데이터는 커맨드 객체로 받으면 편리하다.
	public String createArticle(/* HttpServletRequest request, */ArticleForm articleForm, Model model) {
		log.info("ArticleController의 createArticle() 메소드 실행");
//		log.info("title: " + request.getParameter("title"));
//		log.info("content: " + request.getParameter("content"));
//		model.addAttribute("title", request.getParameter("title"));
//		model.addAttribute("content", request.getParameter("content"));
		log.info("articleForm: " + articleForm);
//		log.info("articleRepository: " + articleRepository);
		
//		new.mustache의 form에 입력한 데이터를 넘겨받은 커맨드 객체(ArticleForm)의 데이터를 테이블(article)에
//		저장해야 하므로 Article 엔티티로 변환한다.
		Article article = articleForm.toEntity();
		log.info("article: " + article);
		
//		ArticleRepository 인터페이스 객체에서 article 테이블에 데이터를 저장하기 위해서 save() 메소드를
//		실행한다.
//		save() 메소드는 id에 저장된 데이터가 null이면 insert sql 명령을 실행하고 null이 아니면 update sql
//		명령을 실행한다.
//		save() 메소드는 insert나 update sql 명령 실행 결과를 리턴한다.
		Article saved = articleRepository.save(article);
		log.info("saved: " + saved);
		
//		return "goodbye";
		return "articles/new";
	}
	
}















