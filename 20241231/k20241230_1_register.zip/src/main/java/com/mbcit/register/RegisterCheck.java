package com.mbcit.register;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/RegisterCheck")
public class RegisterCheck extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public RegisterCheck() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		actionDo(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		actionDo(request, response);
	}
	
	protected void actionDo(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		System.out.println("RegisterCheck 컨트롤러의 actionDo() 메소드 실행");
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html; charset=UTF-8");
		
		String id = request.getParameter("id").trim();
		// System.out.println(id);
		
		// 회원 가입하려는 id가 테이블에 존재하는가 판단하는 메소드를 실행한다.
		int result = new RegisterDAO().registerCheck(id);
		// System.out.println(result);
		
		if (result == 1) {
			// 중복 검사할 id를 입력하지 않고 중복 체크 버튼을 클릭한 경우
			request.getSession().setAttribute("messageType", "오류 메시지: ");
			request.getSession().setAttribute("messageContent", "중복 검사할 id를 입력하세요.");
		} else if (result == 2) {
			// 사용 중인 아이디일 경우
			request.getSession().setAttribute("messageType", "오류 메시지: ");
			request.getSession().setAttribute("messageContent", "이미 사용 중인 아이디입니다.");
		} else {
			// 사용 가능한 아이디일 경우
			request.getSession().setAttribute("messageType", "성공 메시지: ");
			request.getSession().setAttribute("messageContent", "사용 가능한 아이디입니다.");
		}
		response.sendRedirect("index.jsp");
	}

}














