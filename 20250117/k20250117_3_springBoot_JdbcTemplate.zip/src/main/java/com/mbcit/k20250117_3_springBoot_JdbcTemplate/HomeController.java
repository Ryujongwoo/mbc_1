package com.mbcit.k20250117_3_springBoot_JdbcTemplate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
public class HomeController {

	@Autowired
	private MyUserDAO dao;
	
	@RequestMapping("/")
	public @ResponseBody String home() {
		log.info("dao: {}", dao);
		return "JdbcTemplate 테스트";
	}
	
//	@RequestMapping 어노테이션의 value 속성은 브라우저에서 들어오는 요청을 지정한다.
//	method 속성은 RequestMethod.GET을 적어주면 GET 방식 요청에만 응답하고 RequestMethod.POST를
//	적어주면 POST 방식의 요청에만 응답한다.
//	method 속성을 생략하면 GET, POST 방식 구분없이 모든 요청에 응답한다.
//	method 속성을 생략하면 value 속성도 생략하고 브라우저에서 들어오는 요청만 지정한다.
	@RequestMapping(value = "/userList", method = RequestMethod.GET)
	public String userList(Model model) {
		log.info("HomeController 클래스의 userList() 메소드 실행");
		model.addAttribute("userList", dao.list());
		return "userList";
	}
	
}
















