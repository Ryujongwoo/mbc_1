package com.mbcit.k20250121_1_springBoot_JPA01.domain;

import java.time.LocalDateTime;

import javax.persistence.EntityListeners;
import javax.persistence.MappedSuperclass;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import lombok.Data;

@Data
//	@EntityListeners(value = {MyEntityListener.class})
@EntityListeners(value = {AuditingEntityListener.class})
@MappedSuperclass
public class BaseEntity implements Auditable {

	@CreatedDate
	private LocalDateTime createDate;
	@LastModifiedDate
	private LocalDateTime updateDate;
	
}







