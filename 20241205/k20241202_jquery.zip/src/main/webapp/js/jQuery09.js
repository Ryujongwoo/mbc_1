$(() => {
//	0번째 p 태그의 자식 요소 span 태그를 선택한다.
//	$('p:eq(0) > span').css('backgroundColor', 'green');
	$('p:eq(0)').add('span:eq(0)').css('backgroundColor', 'hotpink');
	
//	div 태그의 모든 자식 요소를 선택한다.
	$('div').children().css('color', 'dodgerblue');
	$('div').children().click(function () {
		if ($(this).is('span')) {
			$(this).css('color', 'red');
		} else if ($(this).is('b')) {
			$(this).css('color', 'blue');
		} else if ($(this).is('p')) {
			$(this).css('color', 'lime');
		}
	});
});

