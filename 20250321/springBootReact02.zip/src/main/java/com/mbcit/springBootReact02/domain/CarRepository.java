package com.mbcit.springBootReact02.domain;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

//	springBoot JPA는 CRUD(Create, Read, Update, Delete) 작업만을 CrudRepository 인터페이스가 있다.
//	이 인터페이스는 엔티티 클래스에 CRUD 기능을 제공한다.
//	CrudRepository의 제네릭 T에는 JPA 메소드가 실행될 엔티티 클래스 이름을 쓴다.
//	CrudRepository의 제네릭 ID에는 엔티티 클래스에서 @Id 어노테이션을 붙여서 선언한 필드의 타입을 쓴다.
public interface CarRepository extends CrudRepository<Car, Long> {
	
//	쿼리 접두사는 여러가지가 있지만 findBy로 시작하고 뒤에는 검색할 필드 이름이 나오면 된다.
//	brand로 자동차 검색
	public List<Car> findByBrand(String brand);
//	color로 자동차 검색
	public List<Car> findByColor(String color);
//	year로 자동차 검색
	public List<Car> findByYear(int year);
	
//	검색할 필드 이름 다음에 And나 Or를 붙여서 여러 필드를 지정할 수 있다.
//	brand와 model로 자동차 검색
	public List<Car> findByBrandAndModel(String brand, String model);
//	brand나 color로 자동차 검색
	public List<Car> findByBrandOrColor(String brand, String color);
	
//	쿼리를 정렬하려면 쿼리 메소드에 OrderBy를 사용한다.
//	brand나 color로 자동차를 검색하고 price로 정렬
	public List<Car> findByBrandOrColorOrderByPrice(String brand, String color);
	
//	@Query 어노테이션을 이용하면 SQL문으로 쿼리를 만들 수 있다.
//	SQL문을 이용해 brand로 자동차 검색
	@Query("select c from Car c where c.brand = ?1")
	public List<Car> brandEqual(String brand);
	
//	@Query 어노테이션에는 like 같은 고급 식을 지정할 수 있다.
	@Query("select c from Car c where c.brand like %?1%")
	public List<Car> brandImport(String brand);
	
}












