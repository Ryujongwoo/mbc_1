package com.mbcit.k20250115_3_springBoot_AnnotationDI;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

//	@SpringBootApplication 어노테이션은 다음과 같은 세 가지 기능을 수행한다.
//	@Configuration: bean을 생성할 때 singleton으로 한 번만 생성한다.
//	@EnableAutoConfiguration: springBoot Application Context를 만들 때 자동으로 설정하는 기능을 켠다.
//	@ComponentScan: 지정한 위치 이하에 있는 @Component 어노테이션과 @Configuration 어노테이션이 붙으
//	클래스를 스캔해서 bean으로 등록한다.
@SpringBootApplication
public class K202501153SpringBootAnnotationDiApplication {

	public static void main(String[] args) {
//		내장 톰캣을 실행한 다음, 자동으로 web application을 생성한다.
		SpringApplication.run(K202501153SpringBootAnnotationDiApplication.class, args);
	}

}
