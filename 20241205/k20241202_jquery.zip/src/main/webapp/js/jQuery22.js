$('#emp_search').click(function () {
//	조회할 사원번호를 얻어온다.
	let empid = $('#empid').val();
//	console.log(empid);
//	입력한 사원번호가 3자리 숫자인가 검사한다.
//	isNaN(): 인수로 지정된 값이 숫자가 아니면 true, 숫자면 false를 리턴한다.
//	console.log(isNaN(empid));
	if (!isNaN(empid) && empid.trim().length === 3) {
		
		// jQuery Ajax =========================================================================
		$.ajax({
			url: 'emplist.xml', // 호출할 페이지의 주소(요청) 또는 읽어올 xml 파일명
			method: 'GET', // 서버에 요청하는 방식, 무조건 대문자로 사용한다.
			dataType: 'xml', // 전송받을 데이터 타입(xml, json, html, script)
			// success는 Ajax 요청이 성공했을 때 실행할 콜백 함수를 코딩한다.
			success: data => {
				// alert('요청 성공');
				// console.log(data);
				
				// 서버가 응답한 내용에서 입력한 사원번호를 찾는다.
				// empid = $(data).find('EMPLOYEE_ID:contains(' + empid + ')').text();
				// console.log(empid);
				
				// 입력한 사원번호에 해당되는 데이터를 출력해야 하기 때문에 검색한 사원번호의 부모 요소를
				// 선택한다.
				let empInfo = $(data).find('EMPLOYEE_ID:contains(' + empid + ')').parent();
				// console.log(empInfo);
				// console.log(empInfo.html());
				
				// 검색한 사원번호에 해당되는 데이터가 있으면 테이블에 출력한다.
				// 검색한 사원의 부모는 <ROW> 태크이므로 검색된 내용 중에 'ROW'가 있으면 테이블에 데이터를 
				// 출력하고 없으면 에러 메시지를 출력한다.
				if ($(empInfo).is('ROW')) {
					
					// $('#idx').val($(empInfo).children().eq(0).text());
					// $('#name').val($(empInfo).children().eq(1).text());
					// $('#email').val($(empInfo).children().eq(2).text());
					// $('#phone').val($(empInfo).children().eq(3).text());
					// $('#hire').val($(empInfo).children().eq(4).text());
					
					// table 태그의 자손인 모든 input를 선택해서 input 태그의 개수 만큼 반복하며 xml 파일에서 
					// 읽어온 데이터를 table에 채워 넣는다.
					$('table input').each(function (index, obj) {
						let search = $(empInfo).children().eq(index).text();
						// console.log(index, obj, search);
						// obj.value = search;
						// $(this).val(search);
						$('table input').eq(index).val(search);
					});
				} else {
					alert(empid + '번은 존재하지 않는 사원번호 입니다.');
					$('#empid').val('');
					$('#empid').focus();
				}
			},
			// error는 Ajax 요청이 실패했을 때 실행할 콜백 함수를 코딩한다.
			error: error => {
				alert('요청 실패');
				console.log(error.status + ': ' + error.statusText);
			}
		});
		// =====================================================================================
	} else {
		alert('정확한 사원 번호를 입력하세요');
		$('#empid').val('');
		$('#empid').focus();
	}
});

