package com.mbcit.springBootReact02.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.mbcit.springBootReact02.domain.Car;
import com.mbcit.springBootReact02.domain.CarRepository;

@Controller
public class HomeController {

	@Autowired
	private CarRepository carRepository;
	
	@RequestMapping("/")
	public @ResponseBody String home() {
		List<Car> results = carRepository.findByBrand("현대");
		for (Car car : results) {
			System.out.println("findByBrand: " + car);
		}
		System.out.println("==============================================================");
		
		results = carRepository.findByColor("파랑");
		for (Car car : results) {
			System.out.println("findByColor: " + car);
		}
		System.out.println("==============================================================");
		
		results = carRepository.findByYear(2024);
		for (Car car : results) {
			System.out.println("findByYear: " + car);
		}
		System.out.println("==============================================================");
		
		results = carRepository.findByBrandAndModel("기아", "모닝");
		for (Car car : results) {
			System.out.println("findByBrandAndModel: " + car);
		}
		System.out.println("==============================================================");
		
		results = carRepository.findByBrandOrColor("쉐보레", "검정");
		for (Car car : results) {
			System.out.println("findByBrandOrColor: " + car);
		}
		System.out.println("==============================================================");
		
		results = carRepository.findByBrandOrColorOrderByPrice("쉐보레", "검정");
		for (Car car : results) {
			System.out.println("findByBrandOrColorOrderByPrice: " + car);
		}
		System.out.println("==============================================================");
		
		results = carRepository.brandEqual("쉐보레");
		for (Car car : results) {
			System.out.println("brandEqual: " + car);
		}
		System.out.println("==============================================================");
		
		results = carRepository.brandImport("대");
		for (Car car : results) {
			System.out.println("brandImport: " + car);
		}
		System.out.println("==============================================================");
		
		return "CRUD Test";
	}
	
}












