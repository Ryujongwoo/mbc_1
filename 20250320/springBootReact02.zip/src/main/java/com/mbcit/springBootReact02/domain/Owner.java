package com.mbcit.springBootReact02.domain;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Owner {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long ownerid;
	private String firstname;
	private String lastname;
	
//	관계 설정을 위한 필드 정의
//	외래키가 참조하는 기본키가 있는 Owner 엔티티 클래스에서는 @OneToMany 어노테이션으로 관계를
//	정의해야 한다.
//	@OneToMany 어노테이션에는 두 개의 특성이 있다.
//	mappedBy = "owner" 설정은 Car 클래스에 있는 owner 필드가 이 관계의 외래키임을 지정한다.
//	mappedBy를 지정하지 않으면 다대다 관계 설정에 사용되는 중간 테이블이 생성된다.
//	cascade 특성은 삭제 또는 업데이트 시 연속 효과가 적용되는 방법을 지정한다.
//	이 특성을 ALL로 설정하면 모든 작업이 연쇄적으로 적용된다. 예를 들어, 소유자를 삭제하면 소유자와
//	관계를 맺고있는 모든 자동차도 같이 삭제된다.
	@OneToMany(mappedBy = "owner", cascade = CascadeType.ALL)
	private List<Car> cars;
	
	public Owner() { }
	public Owner(String firstname, String lastname) {
		this.firstname = firstname;
		this.lastname = lastname;
	}
	
	public Long getOwnerid() {
		return ownerid;
	}
	public void setOwnerid(Long ownerid) {
		this.ownerid = ownerid;
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	
//	관계 설정을 위해 정의한 필드에 대한 getter와 setter를 추가한다.
	public List<Car> getCars() {
		return cars;
	}
	public void setCars(List<Car> cars) {
		this.cars = cars;
	}
	
//	관계 설정을 위해 정의한 필드가 추가된 toString() 메소드를 다시 Override 한다.
	@Override
	public String toString() {
		return "Owner [ownerid=" + ownerid + ", firstname=" + firstname + ", lastname=" + lastname + ", cars=" + cars
				+ "]";
	}
	
}
