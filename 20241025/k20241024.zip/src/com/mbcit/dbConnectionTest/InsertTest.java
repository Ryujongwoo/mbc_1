package com.mbcit.dbConnectionTest;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class InsertTest {

	public static void main(String[] args) {
		
//		memo 테이블에 저장할 데이터를 키보드로 입력받는다.
		Scanner scanner = new Scanner(System.in);
		System.out.print("이름: ");
		String name = scanner.nextLine().trim();
		System.out.print("비밀번호: ");
		String password = scanner.nextLine().trim();
		System.out.print("메모: ");
		String memo = scanner.nextLine().trim();
		
//		데이터베이스 작업에 사용할 객체를 선언한다.
		Connection conn = null;
		Statement stmt = null;
		PreparedStatement pstmt = null;
		
//		MySQL에 연결한다.
		conn = DBUtil.getMySQLConnection();
		if (conn != null) {
//			MySQL에 정상적으로 연결되었으므로 스캐너로 입력받은 데이터를 memo 테이블에 저장한다.
//			System.out.println("연결 성공: " + conn);
			
			try {
				/*
//				Statement를 사용해서 입력받은 데이터를 memo 테이블에 저장한다.
				
//				실행할 sql 명령을 만든다.
//				테이블에 저장할 문자열 데이터는 작은따옴표로 묶어야 하고 명령 끝에 ";"은 입력하면 안된다.
//				String sql = "insert into memo(name, password, memo) values ('" + name + "', '" + password + "', '" + memo + "')";
				String sql = String.format("insert into memo(name, password, memo) values ('%s', '%s', '%s')", name, password, memo);
//				System.out.println(sql);
				
//				Statement를 이용해서 sql 명령을 실행할 준비를 한다.
				stmt = conn.createStatement();
				
//				sql 명령을 실행한다.
//				executeUpdate(): 테이블 내용이 변경되는 sql 명령을 실행한다. => insert, delete, update
//				executeQuery(): 테이블 내용이 변경되지 않는 sql 명령을 실행한다. => select
				stmt.executeUpdate(sql);
				*/
				
//				PreparedStatement를 사용해서 입력받은 데이터를 memo 테이블에 저장한다.
				
//				실행할 sql 명령을 만든다.
//				변수에 저장된 데이터가 대입될 자리에 "?"를 입력하고 나중에 "?"에 데이터를 대입한다.
				String sql = "insert into memo(name, password, memo) values (?, ?, ?)";
				
//				PreparedStatement를 이용해서 sql 명령을 임시로 실행한다.
				pstmt = conn.prepareStatement(sql);
				
//				"?"에 데이터를 넣어준다.
				pstmt.setString(1, name);
				pstmt.setString(2, password);
				pstmt.setString(3, memo);
				
//				"?"가 채워진 sql 명령을 실제로 실행한다.
				pstmt.executeUpdate();
				
				System.out.println("저장완료!!!");
				DBUtil.close(conn);
			} catch (SQLException e) {
				System.out.println("연결실패!!!");
			}
			
		}
		
	}
	
}

















