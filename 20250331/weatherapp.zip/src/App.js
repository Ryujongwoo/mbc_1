import React, { useState } from 'react';
import './App.css';

function App() {

// 사용할 응답 데이터에 필요한 상태를 추가한다.
// 온도, 날씨, 날씨 아이콘을 표시하기 위한 상태값 3개와 로딩 상태를 나타내는 상태를 추가한다.
  const [temp, setTemp] = useState(''); // 온도
  const [desc, setDesc] = useState(''); // 날씨
  const [icon, setIcon] = useState(''); // 날씨 아이콘
  const [ready, setReady] = useState(''); // 로딩 상태

  // useEffect() 함수의 두 번째 인수가 생략되면 모든 상태에 의존적이기 때문에 렌더링 될 때마다 무조건 실행된다.
  // useEffect() 함수의 두 번째 인수로 빈 배열이 지정되면 의존성이 없기 때문에 최초로 렌더링 될 때만 실행된다.
  // useEffect() 함수의 두 번째 인수로 state를 지정하면 지정한 state에 의존적이기 때문에 최초로 렌더링 될 때와
  // 두 번째 인수로 지정한 state의 값이 변경될 때 실행된다.
  // App 컴포넌트가 최초로 렌더링될 때 open weather map API를 호출해서 얻어온 정보를 temp, desc, icon, ready state에
  // 저장한다.
  React.useEffect(
    function () {
      fetch('https://api.openweathermap.org/data/2.5/weather?q=Yangju&units=metric&APPID=fa93a1a474f326e908543ed7b9005723')
      .then(result => result.json())
      .then(jsonreturn => {
          // console.log(jsonreturn);
          // console.log(jsonreturn.main);
          // console.log(jsonreturn.main.temp); // 온도
          // console.log(jsonreturn.weather[0].main); // 날씨
          // console.log(jsonreturn.weather[0].icon); // 날씨 아이콘
          setTemp(jsonreturn.main.temp);
          setDesc(jsonreturn.weather[0].main);
          setIcon(jsonreturn.weather[0].icon);
          setReady(true);
        }
      )
      .catch(error => console.log(error))
    }, []);

  if (ready) {
    return (
      <div className="App">
        <p>온도: {temp}</p>
        <p>
          날씨: {desc}
          <img src={`https://openweathermap.org/img/wn/${icon}@2x.png`} alt="날씨 아이콘" width={20}/>  
        </p>
      </div>
    );
  } else {
    return (
      <div className="App">Loading...</div>
    );
  }
}

export default App;
