package com.mbcit.k20250121_1_springBoot_JPA01.domain;

public enum Gender {

	BABY,
	MALE, // 0
	FEMALE // 1
	
}
