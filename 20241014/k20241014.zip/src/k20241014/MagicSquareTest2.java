package k20241014;

import java.util.Scanner;

public class MagicSquareTest2 {

	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		int row = 0;
		while (true) {
			System.out.print("행렬의 차수를 3이상의 홀수로 입력하세요: ");
			row = scanner.nextInt();
			if (row >= 3 && row % 2 == 1) {
				break;
			}
			System.out.println("3이상인 홀수를 입력하세요.");
		}
		
		int[][] a = new int[row][row];
		int i = 0, j = row / 2;
		
		for (int k = 1; k <= Math.pow(row, 2); k++) {
			a[i][j] = k;
			if (k % row == 0) {
				i++;
			} else {
				if (--i < 0) {
					i = row - 1;
				}
				if (++j > row - 1) {
					j = 0;
				}
			}
		}
		
		for (i = 0; i < a.length; i++) {
			for (j = 0; j < a[i].length; j++) {
				System.out.printf("%3d ", a[i][j]);
			}
			System.out.println();
		}
		
	}
	
}
