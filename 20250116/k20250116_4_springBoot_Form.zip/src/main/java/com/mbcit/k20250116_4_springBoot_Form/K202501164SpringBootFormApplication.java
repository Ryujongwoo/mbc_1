package com.mbcit.k20250116_4_springBoot_Form;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class K202501164SpringBootFormApplication {

	public static void main(String[] args) {
		SpringApplication.run(K202501164SpringBootFormApplication.class, args);
	}

}
