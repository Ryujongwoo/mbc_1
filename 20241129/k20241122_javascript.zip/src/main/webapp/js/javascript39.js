onload = () => {
	let a = document.querySelectorAll('a');
	let img = document.querySelectorAll('img')[0];
	let count = 3;
	
	a[0].onclick = () => {
		if (--count < 1) {
			count = 5;
		}
		img.setAttribute('src', './images/img0' + count + '.jpg');
	}

	a[1].onclick = () => {
//		if (++count > 4) {
//			count = 1;
//		}
		count = ++count > 5 ? 1 : count;
		img.setAttribute('src', `./images/img0${count}.jpg`);
	}
}

